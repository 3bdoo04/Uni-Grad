"""Create a practical six-page rehearsal guide from the actual slide notes."""
from pathlib import Path
from xml.sax.saxutils import escape
import json
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

r=Path(__file__).parent
out=r/'output'
slides=json.loads((r/'slide-content-and-notes.json').read_text())
for name,file in [('Carlito','Carlito-Regular.ttf'),('CarlitoB','Carlito-Bold.ttf'),('CarlitoI','Carlito-Italic.ttf'),('CarlitoBI','Carlito-BoldItalic.ttf')]:
    pdfmetrics.registerFont(TTFont(name,str(r/'fonts'/file)))
pdfmetrics.registerFontFamily('Carlito',normal='Carlito',bold='CarlitoB',italic='CarlitoI',boldItalic='CarlitoBI')
navy=colors.HexColor('#062B49');green=colors.HexColor('#549848');mint=colors.HexColor('#F1F7EE');gray=colors.HexColor('#566672')
styles=getSampleStyleSheet()
styles.add(ParagraphStyle('TitleX',fontName='CarlitoB',fontSize=24,leading=28,textColor=navy,spaceAfter=14))
styles.add(ParagraphStyle('HeadX',fontName='CarlitoB',fontSize=14,leading=17,textColor=navy,spaceBefore=9,spaceAfter=5))
styles.add(ParagraphStyle('BodyX',fontName='Carlito',fontSize=11,leading=14,spaceAfter=7,textColor=navy))
styles.add(ParagraphStyle('SmallX',fontName='Carlito',fontSize=10,leading=12,spaceAfter=5,textColor=gray))
styles.add(ParagraphStyle('CellX',fontName='Carlito',fontSize=10,leading=12,textColor=navy))
styles.add(ParagraphStyle('WhiteX',fontName='CarlitoB',fontSize=10,leading=12,textColor=colors.white))
styles.add(ParagraphStyle('CueHead',fontName='CarlitoB',fontSize=12,leading=15,textColor=navy,spaceBefore=6,spaceAfter=3))
styles.add(ParagraphStyle('CueBody',fontName='Carlito',fontSize=10.5,leading=13,textColor=navy,spaceAfter=4))
styles.add(ParagraphStyle('CueSmall',fontName='Carlito',fontSize=9.5,leading=12,textColor=gray,spaceAfter=4))
styles.add(ParagraphStyle('QAHead',fontName='CarlitoB',fontSize=11.5,leading=13.5,textColor=navy,spaceBefore=5,spaceAfter=3))
styles.add(ParagraphStyle('QABody',fontName='Carlito',fontSize=10.5,leading=13,textColor=navy,spaceAfter=5))

def p(text,style='BodyX'):
    return Paragraph(escape(text).replace('\n','<br/>'),styles[style])

def rich(text,style='BodyX'):
    return Paragraph(text,styles[style])

def heading(text):
    story.append(p(text,'TitleX'))

def body(text):
    story.append(p(text))

def h(text):
    story.append(p(text,'HeadX'))

def table(rows,widths):
    cells=[]
    for i,row in enumerate(rows):
        cells.append([p(str(x),'WhiteX' if i==0 else 'CellX') for x in row])
    t=Table(cells,colWidths=widths,hAlign='LEFT',repeatRows=1)
    t.setStyle(TableStyle([
        ('BACKGROUND',(0,0),(-1,0),navy),('VALIGN',(0,0),(-1,-1),'TOP'),
        ('ROWBACKGROUNDS',(0,1),(-1,-1),[mint,colors.white]),
        ('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),
        ('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),
        ('LINEBELOW',(0,0),(-1,0),.8,green),('LINEBELOW',(0,1),(-1,-1),.3,colors.HexColor('#D5DFD2'))]))
    story.append(t)
    story.append(Spacer(1,10))

def mmss(seconds):return f'{seconds//60:02d}:{seconds%60:02d}'

def footer(canvas,doc):
    canvas.setStrokeColor(green);canvas.setLineWidth(1);canvas.line(42,43,A4[0]-42,43)
    canvas.setFont('Carlito',9);canvas.setFillColor(gray)
    canvas.drawString(42,29,'Uni-Grad | Midterm rehearsal guide | Suggested timing and speaking assignments')
    canvas.drawRightString(A4[0]-42,29,str(doc.page))

story=[]
heading('15-minute rehearsal guide')
body('Prepared narrative: 12:45. Reserved questions and transitions: 2:15. The combined plan is exactly 15:00; rehearse with a visible timer.')
body('Suggested speaking split: Omar 6:15; Abdelrahman 6:30. Handoffs occur after slide 6 and after slide 13. Speaker assignments are proposed and can be swapped.')
rows=[['Slide','Topic','Speaker','Time window','Duration']]
short=['Title','Problem & aim','Four objectives','Industrial partner','DispatchMAS','TriAgent','Block diagram','Flowchart','Specifications','Contributions','Testing','Cost estimate','Timetable','Challenges','Conclusion','Questions']
for rec,title in zip(slides[:16],short):
    rows.append([rec['slide'],title,rec['speaker'],mmss(rec['start_seconds'])+'–'+mmss(rec['end_seconds']),mmss(rec['seconds'])])
table(rows,[42,156,91,130,92])
body('The main PowerPoint and PDF contain 16 slides and end with “Thank you / Any questions?”. Four supporting slides are provided in a separate Appendix PowerPoint and PDF. Open that file only for a relevant question.')
story.append(p('Start a timer at the first spoken sentence. Reach slide 7 by 04:55, slide 14 by 11:25, and the question slide by 12:45. Do not narrate the backup slides as an extra section.','SmallX'))
story.append(PageBreak())

heading('Content and source checks')
h('Eight objectives become four — no objectives dropped')
table([
    ['Slide objective','Thesis pair','What remains covered'],
    ['Bilingual voice service','1 + 8','Two-way calls; <1.5 s meaningful-reply target; median/p95; English, Egyptian Arabic, mixed/noisy calls; usage and cost.'],
    ['Reliable incident record','2 + 7','Symptoms, callback and location facts; corrections; omissions and contradictions; interrupted-call recovery; stale-result rejection.'],
    ['Triage, guidance & location','3 + 4','Reviewed preliminary urgency and first-aid sources; urgency errors and escalation; caller-confirmed or unresolved location.'],
    ['Approved dispatch support','5 + 6','Simulated vehicle availability, travel time and equipment; staff decision; approved receiver requests; receipts, retries, failures and duplicates.'],
],[145,66,300])
h('Two studies selected for depth')
body('DispatchMAS: closest to emergency caller–dispatcher interaction and protocol-guided questioning. Publication year: 2026, as printed in the supplied paper. The paper does not print an exact publication day/month; its accepted date and PDF creation timestamp are not treated as the publication date.')
body('TriAgent: relevant to selective task execution, incomplete information, retrieval, safety review and traceable records. Published 18 June 2026, printed on its first page.')
h('Numbers to explain correctly')
body('DispatchMAS: 100 synthetic calls from 50 adult records; 94% correct potential auxiliary-agent contact was a simulated, mocked-contact judgment. It is not a measured delivery rate to a working ambulance or hospital endpoint.')
body('TriAgent: 1,000 retrospective cases; 65.7% urgency accuracy and 85.0% critical-case recall. Gains include a trained classifier and structured inputs. Median runtimes of 64 s and 186 s describe case processing, not spoken-reply latency.')
body('Our <1.5 s is a target, not a result. No measured project accuracy, savings, mortality reduction, or real ambulance-dispatch outcome is claimed. The cost slide uses official prices checked on 24 November 2026, with estimated usage and unused Google monthly free caps; it is not a supplier quote or measured operating cost.')
story.append(PageBreak())

for start,stop in [(0,8),(8,16)]:
    heading('Slide-by-slide delivery cues' if start==0 else 'Delivery cues and closing')
    body('Use these as cues, not text to read aloud. Longer spoken outlines and source checks are embedded in the PowerPoint speaker notes.')
    for rec in slides[start:stop]:
        title=f"{rec['slide']:02d}  {short[rec['slide']-1]} — {rec['speaker']} — {mmss(rec['start_seconds'])}–{mmss(rec['end_seconds'])}"
        bits=[p(title,'CueHead'),p(rec['cue'],'CueBody')]
        if rec['transition']:
            bits.append(p('Transition: '+rec['transition'],'CueSmall'))
        story.append(KeepTogether(bits))
    story.append(PageBreak())

heading('Questions to rehearse together')
qa=[
('Why three agents and a Python controller?','Three roles separate conversation, preliminary assessment/guidance, and coordination. Ordinary Python software maintains state and enforces approval and notification rules. Agent count alone is not claimed to improve performance.'),
('Is this a diagnostic or autonomous ambulance service?','No definitive diagnosis or medication prescribing is in scope. Urgency is preliminary; guidance needs qualified review. Staff can take over and must approve dispatch requests. Ambulance resources are simulated.'),
('What happens when a caller corrects an address?','The incident is updated, relevant work is rerun, and results tied to outdated information are rejected. The earlier statement remains available for review.'),
('Can you automatically obtain GPS from an ordinary call?','No. Collect an address or landmark, or use an optional location-sharing link with caller permission where supported. Confirm it with the caller and retain unresolved details.'),
('What does the 1.5-second target measure?','End of the caller’s turn to the first meaningful audible reply. A filler acknowledgment does not qualify. Report preparation and delivery use separate clocks; report median and 95th percentile.'),
('Does a delivery receipt prove that an ambulance departed?','No. Approval, sending, receiver acceptance, simulated assignment and departure are separate states and timestamps. Retry the same request ID and alert staff when delivery remains failed or unconfirmed.'),
('Will you compare three agents with one agent?','A separate implemented single-agent baseline is not in the current committed scope. We plan component/integration and simulated-call evaluation. Published baselines provide context under different test conditions.'),
('Is an industrial partner secured?','The thesis reports outreach, not a confirmed partnership. Requirements input, a test telephone route, and qualified medical review remain prerequisites.'),
('What does the $17.78 estimate cover?','A month with 100 five-minute US test calls, model usage across three roles, live transcription, speech generation, both telephone/gateway legs, geocoding and route-matrix usage. Official prices were checked on 24 November 2026. The total assumes unused Google free caps and existing equipment/internet; without those caps, the same quantities at first paid tiers are about $26.78 before tax. An Egyptian hospital route needs a separate quote.'),
('Have you published either reviewed paper?','No such project publication is reported in the thesis. DispatchMAS and TriAgent are prior research by their named authors, included for literature review.'),
]
for q,a in qa:
    story.append(KeepTogether([p(q,'QAHead'),p(a,'QABody')]))
story.append(PageBreak())

heading('Use both rubrics — keep scores separate')
h('Midterm presentation evaluation: 10 marks')
table([
    ['Criterion','Max','Where the presentation supports it'],
    ['Slide design & visual quality','2','Original template retained; concise cards, native diagrams, readable type, verified logo order and charts.'],
    ['Organization & flow','1','Problem → objectives → research → design → evaluation → plan → conclusion. Handoffs and transitions are in notes.'],
    ['Explanation & communication','3','Spoken outlines explain metrics and limitations; slides use short text. Define terms and avoid reading paragraphs.'],
    ['Oral delivery & confidence','1','Delivery cues prompt pauses, clear emphasis, diagram tracing and audience contact. Actual delivery needs rehearsal.'],
    ['Time management','1','12:45 main narrative, 2:15 reserved, nearly even speaking time, and a separate four-slide appendix.'],
    ['Q&A communication','2','Prepared questions, source checks and focused backup slides support accurate, direct answers.'],
],[139,34,338])
h('Common presentation rubric: quality levels 4 / 3 / 2 / 0')
body('Content: cover the actual project stage and required topics. Visuals: readable text and graphics that explain the message. Presentation skills: audible, confident delivery and sustained audience attention. Organization: a logical sequence. Handling questions: demonstrate understanding and elaborate accurately. These are a separate quality scale; their scoring is not added to the midterm’s 10-mark scheme.')
h('Before presenting')
body('1. Run the complete talk with a timer and the real slide display.\n2. Agree the two handoff sentences and who leads each answer.\n3. Check the four logos and author names on the projection screen.\n4. Say “proposed”, “simulated”, and “target” where appropriate.\n5. End the narrative by 12:45; open the separate appendix only for a question.')
story.append(p('Content source: latest approved 44-page thesis on main, commit 798e161; the two supplied paper PDFs; CSE554 Midterm Evaluation Form and Rubric; and the shared Presentation Rubric. The user has approved this presentation revision for publication on main. The thesis is unchanged.','SmallX'))

doc=SimpleDocTemplate(str(out/'Uni-Grad - Rehearsal Guide.pdf'),pagesize=A4,
                      rightMargin=42,leftMargin=42,topMargin=38,bottomMargin=57,
                      title='Uni-Grad — Midterm rehearsal guide',author='Uni-Grad project team')
doc.build(story,onFirstPage=footer,onLaterPages=footer)

lines=['# Midterm rehearsal guide','','Prepared narrative: **12:45**. Reserved Q&A: **2:15**. Total plan: **15:00**.',
       'Suggested speaking split: Omar 6:15; Abdelrahman 6:30. Main slides 1–16; separate appendix slides 1–4.','',
       '| Slide | Topic | Suggested speaker | Window |','|---|---|---|---|']
for rec,title in zip(slides[:16],short):
    lines.append(f"| {rec['slide']} | {title} | {rec['speaker']} | {mmss(rec['start_seconds'])}–{mmss(rec['end_seconds'])} |")
lines+=['','## Objective pairing','','1+8: bilingual voice and cost; 2+7: reliable incident record; 3+4: triage/guidance/location; 5+6: resources and approved notification.','',
        '## Speaking notes','']
for rec in slides[:16]:
    lines += [f"### {rec['slide']}. {rec['title']}",'',rec['script'],'','Delivery cue: '+rec['cue'],'','Transition: '+rec['transition'],'']
lines+=['## Q&A preparation','']
for q,a in qa:lines += ['### '+q,'',a,'']
(out/'Uni-Grad - Rehearsal Guide.md').write_text('\n'.join(line.rstrip() for line in lines).rstrip()+'\n')
print('Created rehearsal guide PDF and Markdown from the actual slide timing and notes.')
