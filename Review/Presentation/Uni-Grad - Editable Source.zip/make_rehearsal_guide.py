"""Create a practical rehearsal guide from the actual slide notes."""
from pathlib import Path
from xml.sax.saxutils import escape
import json
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

r=Path(__file__).parent
out=r/'output'
slides=json.loads((r/'slide-content-and-notes.json').read_text())
for name,file in [('Carlito','Carlito-Regular.ttf'),('CarlitoB','Carlito-Bold.ttf'),('CarlitoI','Carlito-Italic.ttf'),('CarlitoBI','Carlito-BoldItalic.ttf')]:
    pdfmetrics.registerFont(TTFont(name,str(r/'fonts'/file)))
pdfmetrics.registerFontFamily('Carlito',normal='Carlito',bold='CarlitoB',italic='CarlitoI',boldItalic='CarlitoBI')
navy=colors.HexColor('#062B49');green=colors.HexColor('#549848');mint=colors.HexColor('#F1F7EE');gray=colors.HexColor('#566672')
styles=getSampleStyleSheet()
styles.add(ParagraphStyle('TitleX',fontName='CarlitoB',fontSize=24,leading=28,textColor=navy,spaceAfter=14))
styles.add(ParagraphStyle('HeadX',fontName='CarlitoB',fontSize=14,leading=17,textColor=navy,spaceBefore=9,spaceAfter=5))
styles.add(ParagraphStyle('BodyX',fontName='Carlito',fontSize=11,leading=14,spaceAfter=7,textColor=navy))
styles.add(ParagraphStyle('SmallX',fontName='Carlito',fontSize=10,leading=12,spaceAfter=5,textColor=gray))
styles.add(ParagraphStyle('CellX',fontName='Carlito',fontSize=10,leading=12,textColor=navy))
styles.add(ParagraphStyle('WhiteX',fontName='CarlitoB',fontSize=10,leading=12,textColor=colors.white))
styles.add(ParagraphStyle('CueHead',fontName='CarlitoB',fontSize=12,leading=15,textColor=navy,spaceBefore=6,spaceAfter=3))
styles.add(ParagraphStyle('CueBody',fontName='Carlito',fontSize=10.5,leading=13,textColor=navy,spaceAfter=4))
styles.add(ParagraphStyle('CueSmall',fontName='Carlito',fontSize=9.5,leading=12,textColor=gray,spaceAfter=4))
styles.add(ParagraphStyle('QAHead',fontName='CarlitoB',fontSize=11.5,leading=13.5,textColor=navy,spaceBefore=5,spaceAfter=3))
styles.add(ParagraphStyle('QABody',fontName='Carlito',fontSize=10.5,leading=13,textColor=navy,spaceAfter=5))

def p(text,style='BodyX'):
    return Paragraph(escape(text).replace('\n','<br/>'),styles[style])

def rich(text,style='BodyX'):
    return Paragraph(text,styles[style])

def heading(text):
    story.append(p(text,'TitleX'))

def body(text):
    story.append(p(text))

def h(text):
    story.append(p(text,'HeadX'))

def table(rows,widths):
    cells=[]
    for i,row in enumerate(rows):
        cells.append([p(str(x),'WhiteX' if i==0 else 'CellX') for x in row])
    t=Table(cells,colWidths=widths,hAlign='LEFT',repeatRows=1)
    t.setStyle(TableStyle([
        ('BACKGROUND',(0,0),(-1,0),navy),('VALIGN',(0,0),(-1,-1),'TOP'),
        ('ROWBACKGROUNDS',(0,1),(-1,-1),[mint,colors.white]),
        ('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),
        ('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),
        ('LINEBELOW',(0,0),(-1,0),.8,green),('LINEBELOW',(0,1),(-1,-1),.3,colors.HexColor('#D5DFD2'))]))
    story.append(t)
    story.append(Spacer(1,10))

def mmss(seconds):return f'{seconds//60:02d}:{seconds%60:02d}'

def footer(canvas,doc):
    canvas.setStrokeColor(green);canvas.setLineWidth(1);canvas.line(42,43,A4[0]-42,43)
    canvas.setFont('Carlito',9);canvas.setFillColor(gray)
    canvas.drawString(42,29,'Uni-Grad | Midterm rehearsal guide | Suggested timing and speaking assignments')
    canvas.drawRightString(A4[0]-42,29,str(doc.page))

story=[]
heading('15-minute rehearsal guide')
body('Prepared narrative: 12:45. Reserved questions and transitions: 2:15. The combined plan is exactly 15:00; rehearse with a visible timer.')
body('Suggested speaking split: Omar 6:15; Abdelrahman 6:30. Handoffs occur after slide 6 and after slide 14. Speaker assignments are proposed and can be swapped.')
rows=[['Slide','Topic','Speaker','Time window','Duration']]
short=['Title','Problem definition','Aim & four objectives','Industrial partner','DispatchMAS','TriAgent','Block diagram','Flowchart','Animated call example','Specifications','Contributions','Testing','Cost estimate','Timetable','Challenges','Conclusion','References','Questions']
for rec,title in zip(slides[:18],short):
    rows.append([rec['slide'],title,rec['speaker'],mmss(rec['start_seconds'])+'–'+mmss(rec['end_seconds']),mmss(rec['seconds'])])
table(rows,[42,156,91,130,92])
body('The normal slide show and main PDF contain 18 visible slides: references are slide 17 and “Thank you / Any questions?” is slide 18. The PowerPoint also retains Industrial standards as hidden slide 19, skipped during normal playback. A separate four-slide appendix contains standards, evaluation definitions, agent roles and references for questions.')
story.append(p('Start a timer at the first spoken sentence. Reach slide 7 by 04:55, slide 15 by 11:25, and the question slide by 12:45. Do not narrate the backup slides as an extra section.','SmallX'))
story.append(PageBreak())

heading('Content and source checks')
h('Eight objectives become four — no objectives dropped')
table([
    ['Slide objective','Thesis pair','What remains covered'],
    ['Bilingual voice service','1 + 8','Two-way calls; <1.5 s meaningful-reply target; median/p95; English, Egyptian Arabic, mixed/noisy calls; usage and cost.'],
    ['Reliable incident record','2 + 7','Symptoms, callback and location facts; corrections; omissions and contradictions; interrupted-call recovery; outdated-result rejection.'],
    ['Urgency, guidance & location','3 + 4','Reviewed preliminary urgency and first-aid sources; urgency errors and escalation; caller-confirmed or unresolved location.'],
    ['Approved dispatch support','5 + 6','Simulated vehicle availability, travel time and equipment; staff decision; approved receiver requests; receipts, retries, failures and duplicates.'],
],[145,66,300])
h('Two studies selected for depth')
body('DispatchMAS shares our emergency-call functions: agents collect symptoms through questions and give medical guidance before ambulance arrival. Publication year: 2026, as printed in the supplied paper. The paper does not print an exact publication day/month; its accepted date and PDF creation timestamp are not treated as the publication date.')
body('TriAgent shares our medical assessment task: coordinated specialist roles interpret incomplete patient information and recommend urgency. Its Orchestrator Agent selects specialist modules; these assess urgency, retrieve similar cases, draft care and check drug/allergy risks. A Critique Agent reviews continuation outputs and requests corrections. Critical presentations bypass critique for immediate escalation. Its modules are not all separate language-model agents, and our project does not prescribe medication. Published 18 June 2026, printed on its first page.')
h('Numbers to explain correctly')
body('DispatchMAS: four doctors review 100 simulated calls from 50 adult records. Advice was provided in 91% of scenarios where it was deemed necessary. This is advice coverage, not clinical accuracy or a real ambulance-delivery rate. Most physician scores for helpfulness were 4 or 5 on a five-point scale; these are subjective ratings, not proof of improved patient outcomes. Source: Table 2 and Results, PDF pages 9 and 12.')
body('TriAgent: 65.7% of all 1,000 cases received the correct urgency tier. Of the study’s reference-critical cases, 85.0% were classified critical; about 15% received another tier. The 85% denominator is the critical subset, not all 1,000 cases or all positive predictions. Results include a separately trained classifier and recorded vital signs. Median runtimes of 64 s and 186 s describe case processing, not spoken-reply latency.')
body('Our <1.5 s is a target, not a result. No measured project accuracy, savings, mortality reduction, or real ambulance-dispatch outcome is claimed. The cost slide uses official prices checked on 24 November 2026, with estimated usage and unused Google monthly free caps; it is not a supplier quote or measured operating cost.')
story.append(PageBreak())

for start,stop in [(0,8),(8,18)]:
    heading('Slide-by-slide delivery cues' if start==0 else 'Delivery cues and closing')
    body('Use these as cues, not text to read aloud. The background, title, green subtitle and page number appear together on entry; click to reveal each remaining body unit. The cover and Thank you slide appear whole. Longer spoken outlines and source checks are embedded in the PowerPoint speaker notes.')
    for rec in slides[start:stop]:
        title=f"{rec['slide']:02d}  {short[rec['slide']-1]} — {rec['speaker']} — {mmss(rec['start_seconds'])}–{mmss(rec['end_seconds'])}"
        bits=[p(title,'CueHead'),p(rec['cue'],'CueBody')]
        if rec['transition']:
            bits.append(p('Transition: '+rec['transition'],'CueSmall'))
        story.append(KeepTogether(bits))
    story.append(PageBreak())

heading('Questions to rehearse together')
qa=[
('Why three agents and a Python controller?','Three roles separate conversation, preliminary assessment/guidance, and coordination. Ordinary Python software maintains state and enforces approval and notification rules. Agent count alone is not claimed to improve performance.'),
('Is this a diagnostic or autonomous ambulance service?','No definitive diagnosis or medication prescribing is in scope. Urgency is preliminary; guidance needs qualified review. Staff can take over and must approve dispatch requests. Ambulance resources are simulated.'),
('What happens when a caller corrects an address?','The incident is updated, relevant work is rerun, and results tied to outdated information are rejected. The earlier statement remains available for review.'),
('Can you automatically obtain GPS from an ordinary call?','No. Collect an address or landmark, or use an optional location-sharing link with caller permission where supported. Confirm it with the caller and retain unresolved details.'),
('What does the 1.5-second target measure?','End of the caller’s turn to the first meaningful audible reply. A filler acknowledgment does not qualify. Report preparation and delivery use separate clocks; report median and 95th percentile.'),
('Does a delivery receipt prove that an ambulance departed?','No. Approval, sending, receiver acceptance, simulated assignment and departure are separate states and timestamps. Retry the same request ID and alert staff when delivery remains failed or unconfirmed.'),
('Will you compare three agents with one agent?','A separate implemented single-agent baseline is not in the current committed scope. We plan component/integration and simulated-call evaluation. Published baselines provide context under different test conditions.'),
('Is an industrial partner secured?','The thesis reports outreach, not a confirmed partnership. Requirements input, a test telephone route, and qualified medical review remain prerequisites.'),
('What does the $17.78 estimate cover?','A month with 100 five-minute US test calls, model usage across three roles, live transcription, speech generation, both telephone/gateway legs, geocoding and route-matrix usage. Official prices were checked on 24 November 2026. The total assumes unused Google free caps and existing equipment/internet; without those caps, the same quantities at first paid tiers are about $26.78 before tax. An Egyptian hospital route needs a separate quote.'),
('Have you published either reviewed paper?','No such project publication is reported in the thesis. DispatchMAS and TriAgent are prior research by their named authors, included for literature review.'),
]
for q,a in qa:
    story.append(KeepTogether([p(q,'QAHead'),p(a,'QABody')]))
story.append(PageBreak())

heading('Use both rubrics — keep scores separate')
h('Midterm presentation evaluation: 10 marks')
table([
    ['Criterion','Max','Where the presentation supports it'],
    ['Slide design & visual quality','2','Original template retained; concise cards, native diagrams, readable type, verified logo order and charts.'],
    ['Organization & flow','1','Problem → objectives → research → design → evaluation → plan → conclusion. Handoffs and transitions are in notes.'],
    ['Explanation & communication','3','Spoken outlines explain metrics and limitations; slides use short text. Define terms and avoid reading paragraphs.'],
    ['Oral delivery & confidence','1','Delivery cues prompt pauses, clear emphasis, diagram tracing and audience contact. Actual delivery needs rehearsal.'],
    ['Time management','1','12:45 narrative including references, 2:15 reserved, nearly even speaking time, hidden standards and a separate four-slide appendix.'],
    ['Q&A communication','2','Prepared questions, source checks and focused backup slides support accurate, direct answers.'],
],[139,34,338])
h('Common presentation rubric: quality levels 4 / 3 / 2 / 0')
body('Content: cover the actual project stage and required topics. Visuals: readable text and graphics that explain the message. Presentation skills: audible, confident delivery and sustained audience attention. Organization: a logical sequence. Handling questions: demonstrate understanding and elaborate accurately. These are a separate quality scale; their scoring is not added to the midterm’s 10-mark scheme.')
h('Animated call example — slide 9')
body('Allow 45 seconds. Use Slide Show mode: five clicks reveal caller, collected facts/location, preliminary urgency and simulated vehicle, staff approval, and confirmed delivery; a sixth click reveals the summary beneath them. Arabic and English text describe a fictional caller. The 8-minute travel estimate is assumed. The example illustrates planned behavior, not a working hospital connection or validated clinical result. The PDF shows the final static state; MP4/GIF previews play the sequence automatically for review.')
h('Animated block diagram — slide 7')
body('Allow 70 seconds and fourteen clicks: thirteen alternating core reveals, then the arrow legend. Begin with caller/speech conversion, its arrow, Agent 1 Conversation, its arrow, then the Python controller and stored incident. Reveal each lower branch arrow before its destination: Agent 2, Agent 3, reviewer and test receiver. Each branch visibly starts at the controller. All six connectors are bidirectional, with 4-point lines and wide, short arrowheads at both ends, leaving a visible shaft. The legend explains vivid blue transcript/reply text, orange dashed agent tasks/results and green review/delivery messages. Speech conversion, medical sources, maps/fleet and delivery rules are included within the seven core blocks. Approval precedes sending; confirmation means stored delivery, not ambulance departure. The standalone files use the same simple diagram.')
h('Contributions and uniqueness — slide 11')
body('Allow 40 seconds. Four clicks reveal the cards in reading order: corrections, bilingual calls, location/ambulance choice, delivery recovery. A fifth click reveals the summary. Each gray line identifies a verified boundary of DispatchMAS or TriAgent; each explicitly labelled Our line describes the planned prototype contribution from thesis section 1.5. The distinction is their working connection in one hospital-call prototype. Do not claim that every feature is globally new, or that the prototype has outperformed the studies. The standalone slide and MP4/GIF preview are included.')
h('Specific testing procedures — slide 12')
body('Allow 55 seconds and seven clicks: reveal the column headings, then each of six complete test rows. Each row has a testing type, tested feature and concrete action with an output to check. Change Building 12 to Building 21 and delay the Building 12 map response; verify that it cannot overwrite the corrected location. Explain the three fictional ambulance records directly. For delivery, test confirmation on attempt two, failure of all three attempts, and a lost confirmation after the receiver has stored the request. Check that retries stop, staff are alerted and only one request is stored. For approval, attempt sending before the reviewer approves: no request is sent. Obtain approval, then send the approved request. This uses one reviewer role. The 1.5-second voice response is a target; medical reference answers require qualified review before testing.')
h('Other slides and closing')
body('The remaining body units appear one by one in reading order. Each cost-table row has its own click; timetable tasks reveal individually. References are visible on slide 17 for a 10-second acknowledgment after the 25-second conclusion. Thank you is slide 18 and appears whole at 12:45. Industrial standards is hidden slide 19 and does not advance during normal playback; open it deliberately only if needed for a question.')
h('Before presenting')
body('1. Run the complete talk with a timer and the real slide display.\n2. Agree the two handoff sentences and who leads each answer.\n3. Check the four logos and author names on the projection screen.\n4. Say “proposed”, “simulated”, and “target” where appropriate.\n5. End the narrative by 12:45; open the separate appendix only for a question.')
story.append(p('Content source: latest approved 44-page thesis on main, commit 798e161; the two supplied paper PDFs; CSE554 Midterm Evaluation Form and Rubric; and the shared Presentation Rubric. This revision adds deck-wide body reveals, restores visible references and hidden industrial standards, and updates slide 7 with Agent 1 Conversation and vivid bidirectional arrows. The cover and closing appear whole. The thesis is unchanged. The user requested the presentation and standalone diagram pushed to main.','SmallX'))

doc=SimpleDocTemplate(str(out/'Uni-Grad - Rehearsal Guide.pdf'),pagesize=A4,
                      rightMargin=42,leftMargin=42,topMargin=38,bottomMargin=57,
                      title='Uni-Grad — Midterm rehearsal guide',author='Uni-Grad project team')
doc.build(story,onFirstPage=footer,onLaterPages=footer)

lines=['# Midterm rehearsal guide','','Prepared narrative: **12:45**. Reserved Q&A: **2:15**. Total plan: **15:00**.',
       'Suggested speaking split: Omar 6:15; Abdelrahman 6:30. Visible slides 1–18; hidden Industrial standards slide 19; separate appendix slides 1–4.','',
       '| Slide | Topic | Suggested speaker | Window |','|---|---|---|---|']
for rec,title in zip(slides[:18],short):
    lines.append(f"| {rec['slide']} | {title} | {rec['speaker']} | {mmss(rec['start_seconds'])}–{mmss(rec['end_seconds'])} |")
lines+=['','On entry, the background, title, green subtitle and page number appear together. Remaining body units reveal one at a time; the cover and Thank you slide appear whole. Diagram: 13 core clicks plus legend; call example: 5 stages plus summary; contributions: 4 cards plus summary; testing: headings plus 6 rows. Native cost-table rows reveal individually. References slide 17 receives 10 seconds; Thank you slide 18 begins Q&A at 12:45. Hidden standards slide 19 is skipped in normal playback.','','## Objective pairing','','1+8: bilingual voice and cost; 2+7: reliable incident record; 3+4: triage/guidance/location; 5+6: resources and approved notification.','',
        '## Speaking notes','']
for rec in slides[:18]:
    lines += [f"### {rec['slide']}. {rec['title']}",'',rec['script'],'','Delivery cue: '+rec['cue'],'','Transition: '+rec['transition'],'']
lines+=['## Q&A preparation','']
for q,a in qa:lines += ['### '+q,'',a,'']
(out/'Uni-Grad - Rehearsal Guide.md').write_text('\n'.join(line.rstrip() for line in lines).rstrip()+'\n')
print('Created rehearsal guide PDF and Markdown from the actual slide timing and notes.')
