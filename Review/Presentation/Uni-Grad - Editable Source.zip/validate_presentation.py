"""Verify template continuity, requested content, timing, and readable text fit."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
from pptx import Presentation
from lxml import etree
import fitz
import hashlib
import json
import re
import zipfile

r=Path(__file__).parent
out=r/'output'
pptx=out/'Uni-Grad - Midterm Presentation.pptx'
pdfpath=out/'Uni-Grad - Midterm Presentation.pdf'
template=r/'inputs/Presentation_Template.pptx'
prs=Presentation(pptx)
doc=fitz.open(pdfpath)
records=json.loads((r/'slide-content-and-notes.json').read_text())
appendix=Presentation(out/'Uni-Grad - Appendix.pptx')
appendix_doc=fitz.open(out/'Uni-Grad - Appendix.pdf')
assert len(prs.slides)==len(doc)==17
assert len(records)==21 and len(appendix.slides)==len(appendix_doc)==4
assert prs.slide_width==12192000 and prs.slide_height==6858000
assert sum(x['seconds'] for x in records[:16])==765
assert records[16]['seconds']==135
assert sorted(n for pair in records[2]['objective_pairs'] for n in pair)==list(range(1,9))
assert len(records[2]['objective_pairs'])==4
assert sum(not x['backup'] for x in records)==17
assert [s._element.get('show') for s in prs.slides]==['1']*17
assert [s._element.get('show') for s in appendix.slides]==['1']*4
assert all(s.has_notes_slide and s.notes_slide.notes_text_frame.text for s in prs.slides)
def walk(shapes):
    for shape in shapes:
        yield shape
        if shape.shape_type==6:
            yield from walk(shape.shapes)

def texts(slide):
    items=[]
    for shape in walk(slide.shapes):
        if shape.has_text_frame:items.append(shape.text)
        if shape.has_table:items.extend(cell.text for row in shape.table.rows for cell in row.cells)
    return '\n'.join(items)

alltext='\n'.join(texts(slide) for deck in [prs,appendix] for slide in deck.slides)
for old in ['Car Black Box','Fall 2023','Main Grad Presentation Topics','Click to edit']:
    assert old.casefold() not in alltext.casefold(),old
assert all(x in prs.slides[4].shapes[0].text for x in ['Review of literature','DispatchMAS'])
assert 'TriAgent' in prs.slides[5].shapes[0].text
for sn in [4,5]:
    t=texts(prs.slides[sn])
    assert 'Method' in t and 'Limitations' in t and 'PUBLISHED:' in t
    assert [g.name for g in prs.slides[sn].shapes if g.shape_type==6]==['Goal panel','Method panel','Results panel','Limitations panel','Relevance to our project panel']
    assert len(records[sn]['literature_panels'])==5
    for panel in [g for g in prs.slides[sn].shapes if g.shape_type==6]:
        border=panel.shapes[0]
        for child in list(panel.shapes)[1:]:
            assert child.left>=border.left and child.top>=border.top
            assert child.left+child.width<=border.left+border.width+9144,(sn+1,panel.name,'right')
            assert child.top+child.height<=border.top+border.height+9144,(sn+1,panel.name,'bottom')
dispatch_text=' '.join(doc[4].get_text().split()).lower()
assert all(x in dispatch_text for x in ['91%','simulated scenarios needing advice','helpfulness ratings','4 or 5 out of 5'])
assert not any(x in dispatch_text for x in ['94%','police','fire'])
assert all(x in doc[5].get_text() for x in ['65.7%','85.0%','18 JUNE 2026'])
assert all(x in doc[5].get_text() for x in ['Orchestrator Agent','Specialist modules','Critique Agent'])
assert 'Staff approval' in doc[6].get_text() and 'Python controller' in doc[6].get_text()
assert '1.5 s' in doc[9].get_text()
contribution=prs.slides[10]
assert 'Contributions & uniqueness' in contribution.shapes[0].text
assert len(records[10]['contributions'])==4 and records[10]['seconds']==40
assert [c['number'] for c in records[10]['contributions']]==[1,2,3,4]
contribution_groups=[g for g in contribution.shapes if g.shape_type==6]
assert len(contribution_groups)==4
assert all(g.name.startswith('Contribution ') for g in contribution_groups)
for group in contribution_groups:
    border=group.shapes[0]
    for child in list(group.shapes)[1:]:
        assert child.left>=border.left and child.top>=border.top,(group.name,child.name)
        assert child.left+child.width<=border.left+border.width+9144,(group.name,'right')
        assert child.top+child.height<=border.top+border.height+9144,(group.name,'bottom')
assert 'planned' in texts(contribution).lower()
assert all(t in texts(contribution) for t in ['TriAgent [2]','DispatchMAS [1]',
           'Egyptian Arabic','symptoms or the address change','prevent duplicate','alert staff'])
assert len(contribution._element.xpath('.//p:cTn[@nodeType="clickEffect"]'))==4
assert len(contribution._element.xpath('.//p:animEffect[@filter="fade"]'))==4
assert not contribution._element.xpath('./p:transition[@advTm]')
check=json.loads((out/'Contributions Animation Checks.json').read_text())
assert check['libreoffice_imported_clicks']==check['libreoffice_imported_fades']==4
assert check['claims_are_planned']

with zipfile.ZipFile(template) as original,zipfile.ZipFile(pptx) as built:
    preserved=[n for n in original.namelist() if re.match(r'ppt/(slideMasters|slideLayouts)/.+\.xml$',n) or re.match(r'ppt/theme/theme\d+\.xml$',n)]
    for name in preserved:
        a=etree.tostring(etree.fromstring(original.read(name)),method='c14n')
        b=etree.tostring(etree.fromstring(built.read(name)),method='c14n')
        assert a==b,('template element changed',name)
    for slide in list(prs.slides)+list(appendix.slides):
        for shape in walk(slide.shapes):
            assert shape.left>=-1 and shape.top>=-1,(shape.name,shape.left,shape.top)
            assert shape.left+shape.width<=prs.slide_width+3,(shape.name,'right edge')
            assert shape.top+shape.height<=prs.slide_height+3,(shape.name,'bottom edge')
logos=[s for s in prs.slides[0].shapes if s.shape_type==13]
assert len(logos)==4
expected=['MSA Logo - V.png','CSE Department.png','Engineering1.png','University of Greenwich - Blue.png']
for shape,name in zip(sorted(logos,key=lambda s:s.left),expected):
    assert shape.image.blob==(r/'inputs/Logos'/name).read_bytes(),name

# Calibri-compatible Carlito metrics catch wrapped text and table-cell overflow.
issues=[]
def audit(tf,width,height,label,table=False):
    if not tf.text.strip():return
    availw=(width-tf.margin_left-tf.margin_right)/914400*72
    availh=(height-tf.margin_top-tf.margin_bottom)/914400*72
    height=0
    for p in tf.paragraphs:
        size=p.font.size.pt if p.font.size else 24
        fontfile=('NotoSansArabic-Regular.ttf' if any('\u0600'<=c<='\u06ff' for c in p.text) else 'Carlito-Bold.ttf' if p.font.bold else 'Carlito-Regular.ttf')
        font=ImageFont.truetype(str(r/'fonts'/fontfile),round(size*10))
        count=0
        for segment in p.text.replace('\v','\n').split('\n'):
            lines=['']
            for word in segment.split(' '):
                candidate=(lines[-1]+' '+word).strip()
                if font.getlength(candidate)/10>availw and lines[-1]:lines.append(word)
                else:lines[-1]=candidate
            count+=len(lines)
        height+=count*size*(1.13 if table else 1.28)
    if height>availh+2:
        issues.append({'location':label,'text':tf.text,'estimated_pt':round(height,2),'available_pt':round(availh,2)})

for kind,deck in [('main',prs),('appendix',appendix)]:
    for sn,slide in enumerate(deck.slides,1):
        assert slide.has_notes_slide and slide.notes_slide.notes_text_frame.text
        footers=[s.text for s in slide.shapes if s.has_text_frame and s.top>6.99*914400 and s.left>12*914400]
        assert str(sn) in footers,('missing plain slide number',kind,sn,footers)
        assert not any(re.fullmatch(r'\s*(?:\d+\s*/\s*\d+|B\d+)\s*',t) for t in footers)
        if not (kind=='main' and sn==1):
            assert not any(s.has_text_frame and s.text.strip() and s.left<6*914400 and s.top>7*914400 for s in slide.shapes)
        for shape in walk(slide.shapes):
            if shape.has_text_frame:audit(shape.text_frame,shape.width,shape.height,f'{kind} slide {sn}: {shape.name}')
            if shape.has_table:
                t=shape.table
                for i,row in enumerate(t.rows):
                    for j,cell in enumerate(row.cells):
                        audit(cell.text_frame,t.columns[j].width,row.height,f'{kind} slide {sn}: table {i},{j}',table=True)
(r/'text-fit-audit.json').write_text(json.dumps(issues,indent=2)+'\n')
assert not issues,issues
assert set(t for t in texts(prs.slides[16]).splitlines() if t.strip())=={'Thank you','Any questions?','17'}
assert 'flowchart' in texts(prs.slides[7]).lower()
assert len([s for s in prs.slides[7].shapes if s.shape_type==1 and s.auto_shape_type==4])==2
for sn,headers in [(11,['Testing type','Component / feature','How it will be tested']),
                   (12,['Component / feature','Estimate','Price source / basis'])]:
    tables=[s.table for s in prs.slides[sn].shapes if s.has_table]
    assert len(tables)==1,('native table missing',sn+1)
    assert [c.text for c in tables[0].rows[0].cells]==headers
leads=records[13]['task_leads']
assert len(leads)==11 and {x['lead'] for x in leads}=={'Omar','Abdelrahman'}
assert [x['lead'] for x in leads].count('Omar')==6
assert [x['lead'] for x in leads].count('Abdelrahman')==5
assert not re.search(r'\bBoth\b',texts(prs.slides[13]))

# Render every slide for visual inspection and provide a compact review sheet.
review=r/'rendered';review.mkdir(exist_ok=True)
thumbs=[]
for i,page in enumerate(doc):
    assert page.rect.width>page.rect.height
    pix=page.get_pixmap(matrix=fitz.Matrix(1.5,1.5))
    pix.save(review/f'slide-{i+1:02d}.png')
    small=page.get_pixmap(matrix=fitz.Matrix(.40,.40))
    im=Image.frombytes('RGB',[small.width,small.height],small.samples)
    tile=Image.new('RGB',(402,246),'#eef1ee')
    tile.paste(im,(9,25))
    ImageDraw.Draw(tile).text((9,5),f'{i+1:02d}'+('  BACKUP' if i>=17 else ''),fill='#062b49')
    thumbs.append(tile)
montage=Image.new('RGB',(1608,1230),'white')
for i,tile in enumerate(thumbs):montage.paste(tile,((i%4)*402,(i//4)*246))
montage.save(out/'Slide Overview.png')
main=fitz.open();main.insert_pdf(doc,from_page=0,to_page=16)
main.save(out/'Uni-Grad - Main Slides.pdf',garbage=4,deflate=True)
budget=json.loads((r/'pricing-assumptions.json').read_text())
from decimal import Decimal, ROUND_HALF_UP
estimated=Decimal('.75')+Decimal('.25')*Decimal('4.50')+500*Decimal('.017')+500*Decimal('.0085')+500*Decimal('.004')+Decimal('1.15')
assert estimated==Decimal(str(budget['estimated_total_usd_unrounded']))==Decimal('17.775')
assert sum(Decimal(str(x['estimated_usd_unrounded'])) for x in budget['items'])==estimated
rounded=estimated.quantize(Decimal('.01'),rounding=ROUND_HALF_UP)
assert rounded==Decimal(str(budget['estimated_total_usd']))==Decimal('17.78')
assert records[12]['estimated_scenario_usd']==17.78
assert budget['current_provider_rates_verified']
facts=json.loads((r/'pricing-sources/verified-price-facts.json').read_text())
assert facts['openai_standard_model_row']==['gpt-5.4-mini',.75,.075,4.5]
assert facts['openai_live_transcription']['rows'][0][-1]=='$0.017 / minute'
assert '$17.78' in doc[12].get_text() and '$11.20' not in doc[12].get_text()
assert all(x in doc[12].get_text() for x in ['GPT-5.4 mini','Chirp 3','24 NOVEMBER 2026'])
manifest={'template_file':str(template.name),'template_sha256':hashlib.sha256(template.read_bytes()).hexdigest(),
          'thesis_main_commit':'798e1611042be81b086a27a02259942b3f9d89ab','thesis_pages':44,
          'main_slides_including_qa':17,'appendix_slides_in_separate_file':4,'hidden_slides':0,
          'narrative_seconds':765,'reserved_qa_seconds':135,'maximum_planned_seconds':900,
          'proposed_speaking_seconds':{'Omar':375,'Abdelrahman':390},
          'objective_pairs':records[2]['objective_pairs'],'task_leads':leads,'text_fit_issues':issues,
          'original_template_masters_layouts_themes_preserved':True,'logo_order':expected,
          'publication_dates':{'DispatchMAS':'2026 (year shown in supplied paper; exact day/month not printed)',
                               'TriAgent':'18 June 2026'},
          'cost_scenario_usd':17.78,'cost_arithmetic_verified':True,'current_provider_rates_verified':True,
          'cost_status':'Official unit prices verified 24 November 2026; usage and provider choices remain estimates',
          'problem_definition_slide':2,'aim_and_objectives_slide':3,
          'literature_slide_blocks':['Goal','Method','Results','Limitations','Relevance to our project'],
          'animated_scenario_slide':9,'animation_clicks':5,
          'contributions_slide':11,'contributions_animation_clicks':4,'contributions_thesis_section':'1.5',
          'status':'User requested a complete animated slide 11 redesign from thesis section 1.5 and comparisons with the reviewed papers, and a push to main'}
(out/'Presentation-checks.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('PASS: 17 main slides plus separate 4-slide appendix; 12:45 narrative + 2:15 Q&A.')
print('PASS: original template masters, layouts and themes preserved; logo bytes and order verified.')
print('PASS: all 8 objectives mapped exactly once into 4 objectives; both paper slides contain method/results/limitations/date.')
print('PASS: no estimated text overflow or off-slide shapes; all slides rendered and main-only PDF exported.')

# Appendix is separate so the literal last main slide is the requested closing.
thumbs=[]
for i,page in enumerate(appendix_doc):
    page.get_pixmap(matrix=fitz.Matrix(1.5,1.5)).save(review/f'appendix-{i+1:02d}.png')
    pix=page.get_pixmap(matrix=fitz.Matrix(.4,.4))
    im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples)
    tile=Image.new('RGB',(402,246),'#eef1ee');tile.paste(im,(9,25))
    ImageDraw.Draw(tile).text((9,5),f'APPENDIX {i+1}',fill='#062b49');thumbs.append(tile)
montage=Image.new('RGB',(1608,246),'white')
for i,tile in enumerate(thumbs):montage.paste(tile,(i*402,0))
montage.save(out/'Appendix Overview.png')
cover=fitz.open();cover.insert_pdf(doc,from_page=0,to_page=0)
cover.save(out/'Cover Preview.pdf',garbage=4,deflate=True)
import shutil
shutil.copyfile(review/'slide-01.png',out/'Cover Preview.png')

# Focused two-slide preview for the current requested revision.
assert 'OUR AIM' not in texts(prs.slides[1])
assert 'OUR AIM' in texts(prs.slides[2])
assert len(records[1]['problem_rows'])==3 and records[2]['aim']
assert records[1]['seconds']==60 and records[2]['seconds']==65
assert prs.slides[1].shapes[0].text=='Problem definition'
assert prs.slides[2].shapes[0].text=='Project aim & objectives'
preview=fitz.open();preview.insert_pdf(doc,from_page=1,to_page=2)
preview.save(out/'Slides 2-3 Preview.pdf',garbage=4,deflate=True)
shutil.copyfile(review/'slide-02.png',out/'Slide 2 - Problem Definition.png')
shutil.copyfile(review/'slide-03.png',out/'Slide 3 - Aim and Objectives.png')
print('PASS: problem-only slide 2; aim and all four objective pairs on slide 3; focused preview exported.')

# Focused review of the two revised literature slides.
preview=fitz.open();preview.insert_pdf(doc,from_page=4,to_page=5)
preview.save(out/'Slides 5-6 - Literature Review.pdf',garbage=4,deflate=True)
shutil.copyfile(review/'slide-05.png',out/'Slide 5 - DispatchMAS.png')
shutil.copyfile(review/'slide-06.png',out/'Slide 6 - TriAgent.png')
print('PASS: both paper slides contain Goal, Method, Results, Limitations and Relevance in reading order.')

# Focused export of the revised contributions slide.
preview=fitz.open();preview.insert_pdf(doc,from_page=10,to_page=10)
preview.save(out/'Slide 11 - Contributions.pdf',garbage=4,deflate=True)
shutil.copyfile(review/'slide-11.png',out/'Slide 11 - Contributions.png')
print('PASS: slide 11 maps four illustrated contributions to thesis section 1.5; four on-click fades survive independent import.')

# Native animation is present in the deck and survives an independent Office-format import.
ns={'p':'http://schemas.openxmlformats.org/presentationml/2006/main'}
case=prs.slides[8]
assert 'scenario' in records[8] and records[8]['scenario']['fictional']
assert len(case._element.xpath('.//p:cTn[@nodeType="clickEffect"]'))==5
assert len(case._element.xpath('.//p:animEffect[@filter="fade"]'))==5
ids={s.shape_id for s in case.shapes}
assert all(x['shape_id'] in ids for x in records[8]['animation']['groups'])
assert not case._element.xpath('./p:transition[@advTm]')
check=json.loads((out/'Animated Example Checks.json').read_text())
assert check['libreoffice_imported_clicks']==check['libreoffice_imported_fades']==5
assert check['fictional_case'] and not check['prototype_performance_claim']
print('PASS: five manual click-builds, no automatic advance, fictional case, and preserved 15-minute plan.')
