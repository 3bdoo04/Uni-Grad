"""Verify template continuity, requested content, timing, and readable text fit."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
from pptx import Presentation
from lxml import etree
import fitz
import hashlib
import json
import re
import zipfile

r=Path(__file__).parent
out=r/'output'
pptx=out/'Uni-Grad - Midterm Presentation.pptx'
pdfpath=out/'Uni-Grad - Midterm Presentation.pdf'
template=r/'inputs/Presentation_Template.pptx'
prs=Presentation(pptx)
doc=fitz.open(pdfpath)
records=json.loads((r/'slide-content-and-notes.json').read_text())
appendix=Presentation(out/'Uni-Grad - Appendix.pptx')
appendix_doc=fitz.open(out/'Uni-Grad - Appendix.pdf')
assert len(prs.slides)==len(doc)==16
assert len(records)==20 and len(appendix.slides)==len(appendix_doc)==4
assert prs.slide_width==12192000 and prs.slide_height==6858000
assert sum(x['seconds'] for x in records[:15])==765
assert records[15]['seconds']==135
assert sorted(n for pair in records[2]['objective_pairs'] for n in pair)==list(range(1,9))
assert len(records[2]['objective_pairs'])==4
assert sum(not x['backup'] for x in records)==16
assert [s._element.get('show') for s in prs.slides]==['1']*16
assert [s._element.get('show') for s in appendix.slides]==['1']*4
assert all(s.has_notes_slide and s.notes_slide.notes_text_frame.text for s in prs.slides)
def walk(shapes):
    for shape in shapes:
        yield shape
        if shape.shape_type==6:
            yield from walk(shape.shapes)

def texts(slide):
    items=[]
    for shape in walk(slide.shapes):
        if shape.has_text_frame:items.append(shape.text)
        if shape.has_table:items.extend(cell.text for row in shape.table.rows for cell in row.cells)
    return '\n'.join(items)

alltext='\n'.join(texts(slide) for deck in [prs,appendix] for slide in deck.slides)
for old in ['Car Black Box','Fall 2023','Main Grad Presentation Topics','Click to edit']:
    assert old.casefold() not in alltext.casefold(),old
assert all(x in prs.slides[4].shapes[0].text for x in ['Review of literature','DispatchMAS'])
assert 'TriAgent' in prs.slides[5].shapes[0].text
for sn in [4,5]:
    t=texts(prs.slides[sn])
    assert 'Method' in t and 'Limitations' in t and 'PUBLISHED:' in t
    assert [g.name for g in prs.slides[sn].shapes if g.shape_type==6]==['Method panel','Results panel','Limitations panel']
assert '94%' in doc[4].get_text() and 'mocked' in doc[4].get_text().lower()
assert all(x in doc[5].get_text() for x in ['65.7%','85.0%','18 JUNE 2026'])
assert 'Staff approval' in doc[6].get_text() and 'Python controller' in doc[6].get_text()
assert '1.5 s' in doc[8].get_text()

with zipfile.ZipFile(template) as original,zipfile.ZipFile(pptx) as built:
    preserved=[n for n in original.namelist() if re.match(r'ppt/(slideMasters|slideLayouts)/.+\.xml$',n) or re.match(r'ppt/theme/theme\d+\.xml$',n)]
    for name in preserved:
        a=etree.tostring(etree.fromstring(original.read(name)),method='c14n')
        b=etree.tostring(etree.fromstring(built.read(name)),method='c14n')
        assert a==b,('template element changed',name)
    for slide in list(prs.slides)+list(appendix.slides):
        for shape in walk(slide.shapes):
            assert shape.left>=-1 and shape.top>=-1,(shape.name,shape.left,shape.top)
            assert shape.left+shape.width<=prs.slide_width+3,(shape.name,'right edge')
            assert shape.top+shape.height<=prs.slide_height+3,(shape.name,'bottom edge')
logos=[s for s in prs.slides[0].shapes if s.shape_type==13]
assert len(logos)==4
expected=['MSA Logo - V.png','CSE Department.png','Engineering1.png','University of Greenwich - Blue.png']
for shape,name in zip(sorted(logos,key=lambda s:s.left),expected):
    assert shape.image.blob==(r/'inputs/Logos'/name).read_bytes(),name

# Calibri-compatible Carlito metrics catch wrapped text and table-cell overflow.
issues=[]
def audit(tf,width,height,label,table=False):
    if not tf.text.strip():return
    availw=(width-tf.margin_left-tf.margin_right)/914400*72
    availh=(height-tf.margin_top-tf.margin_bottom)/914400*72
    height=0
    for p in tf.paragraphs:
        size=p.font.size.pt if p.font.size else 24
        fontfile='Carlito-Bold.ttf' if p.font.bold else 'Carlito-Regular.ttf'
        font=ImageFont.truetype(str(r/'fonts'/fontfile),round(size*10))
        count=0
        for segment in p.text.replace('\v','\n').split('\n'):
            lines=['']
            for word in segment.split(' '):
                candidate=(lines[-1]+' '+word).strip()
                if font.getlength(candidate)/10>availw and lines[-1]:lines.append(word)
                else:lines[-1]=candidate
            count+=len(lines)
        height+=count*size*(1.13 if table else 1.28)
    if height>availh+2:
        issues.append({'location':label,'text':tf.text,'estimated_pt':round(height,2),'available_pt':round(availh,2)})

for kind,deck in [('main',prs),('appendix',appendix)]:
    for sn,slide in enumerate(deck.slides,1):
        assert slide.has_notes_slide and slide.notes_slide.notes_text_frame.text
        footers=[s.text for s in slide.shapes if s.has_text_frame and s.top>6.99*914400 and s.left>12*914400]
        assert str(sn) in footers,('missing plain slide number',kind,sn,footers)
        assert not any(re.fullmatch(r'\s*(?:\d+\s*/\s*\d+|B\d+)\s*',t) for t in footers)
        if not (kind=='main' and sn==1):
            assert not any(s.has_text_frame and s.text.strip() and s.left<6*914400 and s.top>7*914400 for s in slide.shapes)
        for shape in walk(slide.shapes):
            if shape.has_text_frame:audit(shape.text_frame,shape.width,shape.height,f'{kind} slide {sn}: {shape.name}')
            if shape.has_table:
                t=shape.table
                for i,row in enumerate(t.rows):
                    for j,cell in enumerate(row.cells):
                        audit(cell.text_frame,t.columns[j].width,row.height,f'{kind} slide {sn}: table {i},{j}',table=True)
(r/'text-fit-audit.json').write_text(json.dumps(issues,indent=2)+'\n')
assert not issues,issues
assert set(t for t in texts(prs.slides[15]).splitlines() if t.strip())=={'Thank you','Any questions?','16'}
assert 'flowchart' in texts(prs.slides[7]).lower()
assert len([s for s in prs.slides[7].shapes if s.shape_type==1 and s.auto_shape_type==4])==2
for sn,headers in [(10,['Testing type','Component / feature','How it will be tested']),
                   (11,['Component / feature','Estimate','Price source / basis'])]:
    tables=[s.table for s in prs.slides[sn].shapes if s.has_table]
    assert len(tables)==1,('native table missing',sn+1)
    assert [c.text for c in tables[0].rows[0].cells]==headers
leads=records[12]['task_leads']
assert len(leads)==11 and {x['lead'] for x in leads}=={'Omar','Abdelrahman'}
assert [x['lead'] for x in leads].count('Omar')==6
assert [x['lead'] for x in leads].count('Abdelrahman')==5
assert not re.search(r'\bBoth\b',texts(prs.slides[12]))

# Render every slide for visual inspection and provide a compact review sheet.
review=r/'rendered';review.mkdir(exist_ok=True)
thumbs=[]
for i,page in enumerate(doc):
    assert page.rect.width>page.rect.height
    pix=page.get_pixmap(matrix=fitz.Matrix(1.5,1.5))
    pix.save(review/f'slide-{i+1:02d}.png')
    small=page.get_pixmap(matrix=fitz.Matrix(.40,.40))
    im=Image.frombytes('RGB',[small.width,small.height],small.samples)
    tile=Image.new('RGB',(402,246),'#eef1ee')
    tile.paste(im,(9,25))
    ImageDraw.Draw(tile).text((9,5),f'{i+1:02d}'+('  BACKUP' if i>=16 else ''),fill='#062b49')
    thumbs.append(tile)
montage=Image.new('RGB',(1608,984),'white')
for i,tile in enumerate(thumbs):montage.paste(tile,((i%4)*402,(i//4)*246))
montage.save(out/'Slide Overview.png')
main=fitz.open();main.insert_pdf(doc,from_page=0,to_page=15)
main.save(out/'Uni-Grad - Main Slides.pdf',garbage=4,deflate=True)
budget=json.loads((r/'pricing-assumptions.json').read_text())
from decimal import Decimal, ROUND_HALF_UP
estimated=Decimal('.75')+Decimal('.25')*Decimal('4.50')+500*Decimal('.017')+500*Decimal('.0085')+500*Decimal('.004')+Decimal('1.15')
assert estimated==Decimal(str(budget['estimated_total_usd_unrounded']))==Decimal('17.775')
assert sum(Decimal(str(x['estimated_usd_unrounded'])) for x in budget['items'])==estimated
rounded=estimated.quantize(Decimal('.01'),rounding=ROUND_HALF_UP)
assert rounded==Decimal(str(budget['estimated_total_usd']))==Decimal('17.78')
assert records[11]['estimated_scenario_usd']==17.78
assert budget['current_provider_rates_verified']
facts=json.loads((r/'pricing-sources/verified-price-facts.json').read_text())
assert facts['openai_standard_model_row']==['gpt-5.4-mini',.75,.075,4.5]
assert facts['openai_live_transcription']['rows'][0][-1]=='$0.017 / minute'
assert '$17.78' in doc[11].get_text() and '$11.20' not in doc[11].get_text()
assert all(x in doc[11].get_text() for x in ['GPT-5.4 mini','Chirp 3','24 NOVEMBER 2026'])
manifest={'template_file':str(template.name),'template_sha256':hashlib.sha256(template.read_bytes()).hexdigest(),
          'thesis_main_commit':'798e1611042be81b086a27a02259942b3f9d89ab','thesis_pages':44,
          'main_slides_including_qa':16,'appendix_slides_in_separate_file':4,'hidden_slides':0,
          'narrative_seconds':765,'reserved_qa_seconds':135,'maximum_planned_seconds':900,
          'proposed_speaking_seconds':{'Omar':375,'Abdelrahman':390},
          'objective_pairs':records[2]['objective_pairs'],'task_leads':leads,'text_fit_issues':issues,
          'original_template_masters_layouts_themes_preserved':True,'logo_order':expected,
          'publication_dates':{'DispatchMAS':'2026 (year shown in supplied paper; exact day/month not printed)',
                               'TriAgent':'18 June 2026'},
          'cost_scenario_usd':17.78,'cost_arithmetic_verified':True,'current_provider_rates_verified':True,
          'cost_status':'Official unit prices verified 24 November 2026; usage and provider choices remain estimates',
          'status':'User approved publication of this presentation revision on main'}
(out/'Presentation-checks.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('PASS: 16 main slides plus separate 4-slide appendix; 12:45 narrative + 2:15 Q&A.')
print('PASS: original template masters, layouts and themes preserved; logo bytes and order verified.')
print('PASS: all 8 objectives mapped exactly once into 4 objectives; both paper slides contain method/results/limitations/date.')
print('PASS: no estimated text overflow or off-slide shapes; all slides rendered and main-only PDF exported.')

# Appendix is separate so the literal last main slide is the requested closing.
thumbs=[]
for i,page in enumerate(appendix_doc):
    page.get_pixmap(matrix=fitz.Matrix(1.5,1.5)).save(review/f'appendix-{i+1:02d}.png')
    pix=page.get_pixmap(matrix=fitz.Matrix(.4,.4))
    im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples)
    tile=Image.new('RGB',(402,246),'#eef1ee');tile.paste(im,(9,25))
    ImageDraw.Draw(tile).text((9,5),f'APPENDIX {i+1}',fill='#062b49');thumbs.append(tile)
montage=Image.new('RGB',(1608,246),'white')
for i,tile in enumerate(thumbs):montage.paste(tile,(i*402,0))
montage.save(out/'Appendix Overview.png')
cover=fitz.open();cover.insert_pdf(doc,from_page=0,to_page=0)
cover.save(out/'Cover Preview.pdf',garbage=4,deflate=True)
import shutil
shutil.copyfile(review/'slide-01.png',out/'Cover Preview.png')
