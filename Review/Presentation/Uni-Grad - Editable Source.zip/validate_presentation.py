"""Verify template continuity, requested content, timing, and readable text fit."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
from pptx import Presentation
from lxml import etree
import fitz
import hashlib
import json
import re
import zipfile

r=Path(__file__).parent
out=r/'output'
pptx=out/'Uni-Grad - Midterm Presentation.pptx'
pdfpath=out/'Uni-Grad - Midterm Presentation.pdf'
template=r/'inputs/Presentation_Template.pptx'
prs=Presentation(pptx)
doc=fitz.open(pdfpath)
records=json.loads((r/'slide-content-and-notes.json').read_text())
assert len(prs.slides)==len(doc)==len(records)==20
assert prs.slide_width==12192000 and prs.slide_height==6858000
assert sum(x['seconds'] for x in records[:15])==765
assert records[15]['seconds']==135
assert sorted(n for pair in records[2]['objective_pairs'] for n in pair)==list(range(1,9))
assert len(records[2]['objective_pairs'])==4
assert sum(not x['backup'] for x in records)==16
assert [s._element.get('show') for s in prs.slides]==['1']*16+['0']*4
assert all(s.has_notes_slide and s.notes_slide.notes_text_frame.text for s in prs.slides)
alltext='\n'.join(s.text for slide in prs.slides for s in slide.shapes if s.has_text_frame)
for old in ['Car Black Box','Fall 2023','Main Grad Presentation Topics','Click to edit']:
    assert old.casefold() not in alltext.casefold(),old
assert all(x in prs.slides[4].shapes[0].text for x in ['Review of literature','DispatchMAS'])
assert 'TriAgent' in prs.slides[5].shapes[0].text
for sn in [4,5]:
    t='\n'.join(s.text for s in prs.slides[sn].shapes if s.has_text_frame)
    assert 'Method:' in t and 'Limitations' in t and 'PUBLISHED:' in t
assert '94%' in doc[4].get_text() and 'mocked' in doc[4].get_text().lower()
assert all(x in doc[5].get_text() for x in ['65.7%','85.0%','18 JUNE 2026'])
assert 'Staff approval' in doc[6].get_text() and 'Python controller' in doc[6].get_text()
assert '1.5 s' in doc[8].get_text()

with zipfile.ZipFile(template) as original,zipfile.ZipFile(pptx) as built:
    preserved=[n for n in original.namelist() if re.match(r'ppt/(slideMasters|slideLayouts)/.+\.xml$',n) or re.match(r'ppt/theme/theme\d+\.xml$',n)]
    for name in preserved:
        a=etree.tostring(etree.fromstring(original.read(name)),method='c14n')
        b=etree.tostring(etree.fromstring(built.read(name)),method='c14n')
        assert a==b,('template element changed',name)
    for slide in prs.slides:
        for shape in slide.shapes:
            assert shape.left>=-1 and shape.top>=-1,(shape.name,shape.left,shape.top)
            assert shape.left+shape.width<=prs.slide_width+3,(shape.name,'right edge')
            assert shape.top+shape.height<=prs.slide_height+3,(shape.name,'bottom edge')
logos=[s for s in prs.slides[0].shapes if s.shape_type==13]
assert len(logos)==4
expected=['MSA Logo - V.png','CSE Department.png','Engineering1.png','University of Greenwich - Blue.png']
for shape,name in zip(sorted(logos,key=lambda s:s.left),expected):
    assert shape.image.blob==(r/'inputs/Logos'/name).read_bytes(),name

# Calibri-compatible Carlito metrics catch text that runs outside its shape.
issues=[]
for sn,slide in enumerate(prs.slides,1):
    for shape in slide.shapes:
        if not shape.has_text_frame or not shape.text.strip():
            continue
        tf=shape.text_frame
        availw=(shape.width-tf.margin_left-tf.margin_right)/914400*72
        availh=(shape.height-tf.margin_top-tf.margin_bottom)/914400*72
        height=0
        for p in tf.paragraphs:
            size=p.font.size.pt if p.font.size else 24
            fontfile='Carlito-Bold.ttf' if p.font.bold else 'Carlito-Regular.ttf'
            font=ImageFont.truetype(str(r/'fonts'/fontfile),round(size*10))
            lines=['']
            for word in p.text.split(' '):
                candidate=(lines[-1]+' '+word).strip()
                if font.getlength(candidate)/10>availw and lines[-1]:
                    lines.append(word)
                else:
                    lines[-1]=candidate
            height+=len(lines)*size*1.28
        if height>availh+2:
            issues.append({'slide':sn,'text':shape.text,'estimated_pt':round(height,2),'available_pt':round(availh,2)})
(r/'text-fit-audit.json').write_text(json.dumps(issues,indent=2)+'\n')
assert not issues,issues

# Render every slide for visual inspection and provide a compact review sheet.
review=r/'rendered';review.mkdir(exist_ok=True)
thumbs=[]
for i,page in enumerate(doc):
    assert page.rect.width>page.rect.height
    pix=page.get_pixmap(matrix=fitz.Matrix(1.5,1.5))
    pix.save(review/f'slide-{i+1:02d}.png')
    small=page.get_pixmap(matrix=fitz.Matrix(.40,.40))
    im=Image.frombytes('RGB',[small.width,small.height],small.samples)
    tile=Image.new('RGB',(402,246),'#eef1ee')
    tile.paste(im,(9,25))
    ImageDraw.Draw(tile).text((9,5),f'{i+1:02d}'+('  BACKUP' if i>=16 else ''),fill='#062b49')
    thumbs.append(tile)
montage=Image.new('RGB',(1608,1230),'white')
for i,tile in enumerate(thumbs):montage.paste(tile,((i%4)*402,(i//4)*246))
montage.save(out/'Slide Overview.png')
main=fitz.open();main.insert_pdf(doc,from_page=0,to_page=15)
main.save(out/'Uni-Grad - Main Slides.pdf',garbage=4,deflate=True)
manifest={'template_file':str(template.name),'template_sha256':hashlib.sha256(template.read_bytes()).hexdigest(),
          'thesis_main_commit':'798e1611042be81b086a27a02259942b3f9d89ab','thesis_pages':44,
          'slides':20,'main_slides_including_qa':16,'hidden_backup_slides':4,
          'narrative_seconds':765,'reserved_qa_seconds':135,'maximum_planned_seconds':900,
          'proposed_speaking_seconds':{'Omar':375,'Abdelrahman':390},
          'objective_pairs':records[2]['objective_pairs'],'text_fit_issues':issues,
          'original_template_masters_layouts_themes_preserved':True,'logo_order':expected,
          'publication_dates':{'DispatchMAS':'2026 (year shown in supplied paper; exact day/month not printed)',
                               'TriAgent':'18 June 2026'},
          'status':'Validated presentation; user approved publication on main'}
(out/'Presentation-checks.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('PASS: 20 slides; 16 main, 4 hidden backups; 12:45 narrative + 2:15 Q&A.')
print('PASS: original template masters, layouts and themes preserved; logo bytes and order verified.')
print('PASS: all 8 objectives mapped exactly once into 4 objectives; both paper slides contain method/results/limitations/date.')
print('PASS: no estimated text overflow or off-slide shapes; all slides rendered and main-only PDF exported.')
