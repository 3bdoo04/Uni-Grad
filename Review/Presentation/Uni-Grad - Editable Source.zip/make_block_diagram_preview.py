"""Export slide 7's individual block/arrow builds and portable previews.

The standalone PowerPoint preserves the native presenter-controlled entrances.
The PDF and high-resolution PNG show the complete diagram; the MP4/GIF play
the same object order automatically using short review timings.
"""
from pathlib import Path
from copy import deepcopy
from io import BytesIO
import json, os, shutil, subprocess, tempfile, zipfile
from pptx import Presentation
from PIL import Image
from lxml import etree
import fitz

r=Path(__file__).parent
out=r/'output';work=r/'block-diagram-preview';work.mkdir(exist_ok=True)
records=json.loads((r/'slide-content-and-notes.json').read_text())
index=next(i for i,x in enumerate(records) if 'block_diagram' in x)
record=records[index];assert index==6
prs=Presentation(out/'Uni-Grad - Midterm Presentation.pptx')
for i,entry in reversed(list(enumerate(list(prs.slides._sldIdLst)))):
    if i!=index:
        prs.part.drop_rel(entry.rId);prs.slides._sldIdLst.remove(entry)
prs.core_properties.title='Presentation Block Diagram'
standalone=out/'Presentation Block Diagram.pptx';prs.save(standalone)
source=prs.slides[0];layout_name=str(source.slide_layout.part.partname)
groups=[x['shape_id'] for x in record['animation']['groups']]
count=len(groups)
assert count>0 and len(set(groups))==count
assert set(groups).issubset({s.shape_id for s in source.shapes})
assert len(source._element.xpath('.//p:cTn[@nodeType="clickEffect"]'))==count
assert len(source._element.xpath('.//p:animEffect[@filter="fade"]'))==count
assert not source._element.xpath('./p:transition[@advTm]')
buffer=BytesIO();prs.save(buffer);states=Presentation(BytesIO(buffer.getvalue()))
for entry in list(states.slides._sldIdLst):
    states.part.drop_rel(entry.rId);states.slides._sldIdLst.remove(entry)
layout=next(x for x in states.slide_layouts if str(x.part.partname)==layout_name)
group_index={shape_id:i for i,shape_id in enumerate(groups)}
for state in range(count+1):
    slide=states.slides.add_slide(layout)
    for shape in list(slide.shapes):shape._element.getparent().remove(shape._element)
    for shape in source.shapes:
        if shape.shape_id in group_index and group_index[shape.shape_id]>=state:continue
        slide.shapes._spTree.insert_element_before(deepcopy(shape._element),'p:extLst')
states_path=work/'Block diagram build states.pptx';states.save(states_path)
soffice=shutil.which('soffice') or shutil.which('libreoffice')
if not soffice:raise SystemExit('LibreOffice is required to export and check the diagram previews.')
env=os.environ.copy();env['FONTCONFIG_FILE']=str(r/'fonts/fonts.conf')
with tempfile.TemporaryDirectory(prefix='uni-grad-block-diagram-office-') as profile:
    common=[soffice,'-env:UserInstallation='+Path(profile).as_uri(),'--headless']
    subprocess.run(common+['--convert-to','pdf','--outdir',str(work),str(states_path)],check=True,env=env)
    subprocess.run(common+['--convert-to','odp','--outdir',str(work),str(standalone)],check=True,env=env)
with zipfile.ZipFile(work/'Presentation Block Diagram.odp') as z:
    root=etree.fromstring(z.read('content.xml'))
ns={'anim':'urn:oasis:names:tc:opendocument:xmlns:animation:1.0',
    'presentation':'urn:oasis:names:tc:opendocument:xmlns:presentation:1.0',
    'smil':'urn:oasis:names:tc:opendocument:xmlns:smil-compatible:1.0'}
fades=root.xpath('//anim:transitionFilter[@smil:type="fade"]',namespaces=ns)
clicks=root.xpath('//*[@presentation:node-type="on-click"]',namespaces=ns)
assert len(fades)==len(clicks)==count,(len(fades),len(clicks),count)
doc=fitz.open(work/'Block diagram build states.pdf');assert len(doc)==count+1
assert abs(doc[-1].rect.width-960)<1 and abs(doc[-1].rect.height-540)<1
complete=fitz.open();complete.insert_pdf(doc,from_page=count,to_page=count)
complete.save(out/'Presentation Block Diagram.pdf',garbage=4,deflate=True)
doc[-1].get_pixmap(matrix=fitz.Matrix(3,3)).save(out/'Presentation Block Diagram.png')
frames=[]
for i,page in enumerate(doc):
    pix=page.get_pixmap(matrix=fitz.Matrix(4/3,4/3))
    im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples).resize((1280,720),Image.Resampling.LANCZOS)
    im.save(work/f'state-{i:02d}.png');frames.append(im)
fps=20;fade_frames=4
video=out/'Presentation Block Diagram - Animation Preview.mp4'
cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pixel_format','rgb24',
     '-video_size','1280x720','-framerate',str(fps),'-i','pipe:0','-an',
     '-c:v','libx264','-pix_fmt','yuv420p','-crf','21','-movflags','+faststart',str(video)]
process=subprocess.Popen(cmd,stdin=subprocess.PIPE)
def hold(im,seconds):
    raw=im.tobytes()
    for _ in range(round(seconds*fps)):process.stdin.write(raw)
hold(frames[0],.7)
for step in range(1,count+1):
    for frame in range(1,fade_frames+1):
        process.stdin.write(Image.blend(frames[step-1],frames[step],frame/fade_frames).tobytes())
    hold(frames[step],.6 if step<count else 4.0)
process.stdin.close();assert process.wait()==0
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(video),
    '-filter_complex','fps=10,scale=960:-1:flags=lanczos,split[s0][s1];[s0]palettegen=max_colors=192:stats_mode=diff[p];[s1][p]paletteuse=dither=bayer:bayer_scale=3',
    '-loop','0',str(out/'Presentation Block Diagram - Animation Preview.gif')],check=True)
audit={'slide_number':7,'native_fade_entrances':count,'on_click_steps':count,
       'duration_ms':record['animation'].get('duration_ms'),
       'libreoffice_imported_fades':len(fades),'libreoffice_imported_clicks':len(clicks),
       'macros':False,'automatic_slide_advance':False,'prototype_is_planned':True,
       'progressive_state_count':count+1,'final_pdf_pages':1,'final_png_pixels':[2880,1620],
       'preview_fps':fps,'preview_fade_ms':200,'preview_hold_seconds':.6,
       'animation_order':record['animation']['groups'],
       'preview_note':'MP4/GIF automatically demonstrate the native one-object-at-a-time sequence with short review timings; PowerPoint uses presenter clicks.'}
(out/'Block Diagram Animation Checks.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
print(f'PASS: slide 7 has {count} native on-click fades; independent import and {count+1} progressive states verified. Standalone PPTX, final PDF/PNG and MP4/GIF exported.')
