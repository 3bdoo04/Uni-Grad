"""Package the review draft and reproducible source, without publishing or pushing."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

r=Path(__file__).parent
out=r/'output'
shutil.copyfile(r/'Cost Assumptions.md',out/'Cost Assumptions.md')
notes='''# Midterm presentation — revised review draft

Current revision: **slide 11 rebuilt as four illustrated, animated contribution cards**, based on published presentation `338a020` and thesis section 1.5. Each card pairs a specific study boundary with a planned prototype contribution: caller corrections without restarting; English/Egyptian Arabic with separate speech/interpretation error checks; confirmed location and explained ambulance selection; and confirmed delivery with duplicate prevention and failure alerts. The comparisons use DispatchMAS and TriAgent, not incompatible accuracy percentages. The distinction is the connection of these functions in one hospital-call prototype, not a claim that every individual feature is new to all research. **Slide 11 - Contributions.pdf / .png** show the final slide. **Uni-Grad - Animated Contributions.pptx** provides the editable slide with four presenter-controlled fades; **Contributions - Animation Preview.mp4 / .gif** show the four builds automatically.

The main deck has 17 slides and ends with **Thank you / Any questions?**. Four supporting slides are in the separate Appendix PowerPoint/PDF.

Implemented the requested plain slide numbers, removal of bottom-left thesis footers, separate Method/Results/Limitations paper panels, clearer block-diagram arrows, minimal flowchart on slide 8, native testing and cost tables, and one accountable lead per timetable task (Omar: six; Abdelrahman: five). The original template and approved cover design are retained.

The narrative plan is **12:45**, with **2:15** reserved for questions and transitions. Speaker notes and the rehearsal guide reflect the revisions. The two supplied rubrics remain mapped in the guide.

**Official prices checked: 24 November 2026.** The cost table estimates **$17.78** for 100 five-minute test calls, including live transcription and both telephone/gateway legs, and assuming unused Google monthly free caps. Usage and provider choices remain estimates. The current provider pages marked the earlier model examples deprecated; the costing example now uses current candidates. Without those Google free caps, the same quantities at the first paid tiers are about **$26.78 before tax**. The telephone example is a US test route; an Egypt route needs a separate quote. Official links, quantities, exact calculations and exclusions are in **Cost Assumptions.md**. Provider pages, retrieval hashes and checked price rows are included in the source bundle.

Review the editable PowerPoint, PDF, overview and guide here. The source ZIP rebuilds both slide files and their audits. The review ZIP includes the complete review package.

The user has **requested this slide 11 revision and a push to main**. The thesis and earlier pre-midterm presentation are unchanged.
'''
(out/'Review Notes.md').write_text(notes)
source_names=['animation_tools.py','make_animation_preview.py','make_contributions_preview.py','build_presentation.py','build_all.py','validate_presentation.py','make_rehearsal_guide.py',
              'package_review.py','literature-evidence.json','contributions-evidence.json','Cost Assumptions.md','README.md','source-manifest.json','slide-content-and-notes.json',
              'pricing-assumptions.json','requested-revision-checklist.md','text-fit-audit.json']
source_paths=[r/name for name in source_names]
source_paths+=sorted((r/'inputs').rglob('*'))
source_paths+=[p for p in sorted((r/'fonts').iterdir()) if p.suffix in ['.ttf','.txt']]
source_paths+=sorted((r/'pricing-sources').glob('*'))
source_paths=[p for p in source_paths if p.is_file()]
with zipfile.ZipFile(out/'Uni-Grad - Editable Source.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in source_paths:z.write(p,p.relative_to(r))
review_names=['Uni-Grad - Midterm Presentation.pptx','Uni-Grad - Midterm Presentation.pdf',
              'Uni-Grad - Main Slides.pdf','Uni-Grad - Appendix.pptx','Uni-Grad - Appendix.pdf',
              'Uni-Grad - Rehearsal Guide.pdf','Uni-Grad - Rehearsal Guide.md',
              'Uni-Grad - Animated Call Example.pptx','Animated Call Example - Preview.mp4',
              'Animated Call Example - Preview.gif','Animated Call Example - Static.pdf',
              'Animated Call Example - Final.png','Animated Example Checks.json',
              'Cost Assumptions.md','Review Notes.md','Slide Overview.png','Appendix Overview.png',
              'Slides 2-3 Preview.pdf','Slide 2 - Problem Definition.png','Slide 3 - Aim and Objectives.png',
              'Slides 5-6 - Literature Review.pdf','Slide 5 - DispatchMAS.png','Slide 6 - TriAgent.png',
              'Slide 11 - Contributions.pdf','Slide 11 - Contributions.png','Uni-Grad - Animated Contributions.pptx',
              'Contributions - Animation Preview.mp4','Contributions - Animation Preview.gif','Contributions Animation Checks.json',
              'Cover Preview.pdf','Cover Preview.png','Presentation-checks.json','Uni-Grad - Editable Source.zip']
assert all((out/n).is_file() for n in review_names)
manifest={n:{'bytes':(out/n).stat().st_size,'sha256':hashlib.sha256((out/n).read_bytes()).hexdigest()}
          for n in review_names}
(out/'Review-files.json').write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(out/'Uni-Grad - Presentation Review.zip','w',zipfile.ZIP_DEFLATED) as z:
    for name in review_names+['Review-files.json']:z.write(out/name,name)
for name in ['Uni-Grad - Editable Source.zip','Uni-Grad - Presentation Review.zip']:
    with zipfile.ZipFile(out/name) as z:assert z.testzip() is None
print('Packaged local review files and reproducible source. No Git operations performed.')
