"""Static closing slide using native, editable project-related icons."""
import math
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN
from pptx.oxml.ns import qn

NAVY='062B49'; GREEN='549848'; DARKGREEN='3D6B32'; MINT='F1F7EE'; WHITE='FFFFFF'
def draw_closing(slide, page_number=18):
    for node in list(slide.shapes):
        slide.shapes._spTree.remove(node._element)
    for timing in list(slide._element.findall(qn('p:timing'))):
        slide._element.remove(timing)
    def shape(kind,x,y,w,h,fill=WHITE,stroke=None,width=2):
        s=slide.shapes.add_shape(kind,Inches(x),Inches(y),Inches(w),Inches(h))
        s.fill.solid();s.fill.fore_color.rgb=RGBColor.from_string(fill)
        if stroke:s.line.color.rgb=RGBColor.from_string(stroke);s.line.width=Pt(width)
        else:s.line.fill.background()
        if kind==MSO_SHAPE.ROUNDED_RECTANGLE:s.adjustments[0]=.15
        return s
    def line(x1,y1,x2,y2,color=NAVY,width=2.5,dashed=False):
        s=slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,Inches(x1),Inches(y1),Inches(x2),Inches(y2))
        s.line.color.rgb=RGBColor.from_string(color);s.line.width=Pt(width)
        if dashed:s.line.dash_style=2
        return s
    def label(x,y,w,h,value,size,color,font='Calibri',align=PP_ALIGN.CENTER):
        s=slide.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h))
        tf=s.text_frame;tf.margin_left=tf.margin_right=tf.margin_top=tf.margin_bottom=0
        p=tf.paragraphs[0];p.text=value;p.alignment=align
        p.font.name=font;p.font.size=Pt(size);p.font.color.rgb=RGBColor.from_string(color)
        return s
    # Preserve the template's ribbon and navy footer, with a clean white field.
    shape(MSO_SHAPE.RECTANGLE,0,2.05,13.333,5.40)
    shape(MSO_SHAPE.RECTANGLE,6.00,1.58,7.333,.47)
    label(.9,2.40,11.53,1.16,'Thank you',62,NAVY,'Calibri Light')
    shape(MSO_SHAPE.ROUNDED_RECTANGLE,6.16,3.52,1.01,.045,fill=GREEN)
    label(.9,3.80,11.53,.62,'Any questions?',28,DARKGREEN)
    # Quiet connectors form a single call-to-care motif, without extra text.
    line(4.56,5.33,5.91,5.33,GREEN,2,True)
    line(7.41,5.33,8.76,5.33,GREEN,2,True)
    def badge(cx,kind):
        start=len(slide.shapes)
        shape(MSO_SHAPE.OVAL,cx-.79,4.54,1.58,1.58,fill=MINT)
        shape(MSO_SHAPE.OVAL,cx-.64,4.69,1.28,1.28,fill=WHITE,stroke=GREEN,width=1.6)
        if kind=='call':
            # Headset arch, earpieces, microphone and outgoing audio waves.
            pts=[(cx+.36*math.cos(math.pi-i*math.pi/16),5.24-.36*math.sin(math.pi-i*math.pi/16)) for i in range(17)]
            for a,b in zip(pts,pts[1:]):line(*a,*b,width=2.6)
            shape(MSO_SHAPE.ROUNDED_RECTANGLE,cx-.42,5.17,.15,.35,fill=NAVY)
            shape(MSO_SHAPE.ROUNDED_RECTANGLE,cx+.27,5.17,.15,.35,fill=NAVY)
            line(cx+.34,5.49,cx+.22,5.67,width=2)
            line(cx+.22,5.67,cx+.03,5.67,width=2)
            shape(MSO_SHAPE.OVAL,cx-.04,5.62,.12,.09,fill=GREEN)
        elif kind=='care':
            shape(MSO_SHAPE.ROUNDED_RECTANGLE,cx-.31,4.96,.62,.72,stroke=NAVY,width=2)
            shape(MSO_SHAPE.RECTANGLE,cx-.065,5.07,.13,.33,fill=GREEN)
            shape(MSO_SHAPE.RECTANGLE,cx-.165,5.17,.33,.13,fill=GREEN)
            pts=[(cx-.46,5.49),(cx-.25,5.49),(cx-.15,5.39),(cx-.04,5.65),(cx+.08,5.46),(cx+.46,5.46)]
            # White underlay keeps the pulse legible over the card outline.
            for a,b in zip(pts,pts[1:]):line(*a,*b,color=WHITE,width=6)
            for a,b in zip(pts,pts[1:]):line(*a,*b,color=NAVY,width=2.2)
        else:
            shape(MSO_SHAPE.ROUNDED_RECTANGLE,cx-.46,5.10,.60,.43,stroke=NAVY,width=2)
            shape(MSO_SHAPE.ROUNDED_RECTANGLE,cx+.13,5.23,.32,.30,stroke=NAVY,width=2)
            shape(MSO_SHAPE.RECTANGLE,cx+.21,5.27,.14,.11,fill=MINT)
            shape(MSO_SHAPE.ROUNDED_RECTANGLE,cx+.22,5.15,.09,.06,fill=GREEN)
            shape(MSO_SHAPE.RECTANGLE,cx-.22,5.17,.08,.23,fill=GREEN)
            shape(MSO_SHAPE.RECTANGLE,cx-.295,5.245,.23,.08,fill=GREEN)
            for x in [cx-.28,cx+.28]:
                shape(MSO_SHAPE.OVAL,x-.10,5.46,.20,.20,fill=NAVY)
                shape(MSO_SHAPE.OVAL,x-.035,5.525,.07,.07,fill=WHITE)
        g=slide.shapes.add_group_shape(list(slide.shapes)[start:]);g.name={'call':'Emergency call icon','care':'Medical care icon','ambulance':'Ambulance dispatch icon'}[kind]
    for cx,kind in [(3.86,'call'),(6.66,'care'),(9.46,'ambulance')]:badge(cx,kind)
    label(12.20,7.16,.55,.27,str(page_number),14,NAVY,align=PP_ALIGN.RIGHT)
