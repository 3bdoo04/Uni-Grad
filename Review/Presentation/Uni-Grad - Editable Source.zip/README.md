# Uni-Grad midterm presentation — review draft

Based on the approved 44-page thesis (`798e1611042be81b086a27a02259942b3f9d89ab`), the supplied PowerPoint template, and both presentation rubrics. This revision starts from published presentation `de1f050b42f119e9f68db26a830716c0849cc2b2`. It adds the requested bidirectional diagram arrows and deck-wide body reveals, renames Agent 1 to Conversation, and restores visible references and hidden industrial standards. Updated 26 November 2026 (Africa/Cairo). The user requested the updated presentation and standalone **Presentation Block Diagram** pushed to main.

## Slide order and timing

The PowerPoint contains **19 physical slides**. Slides **1–18 are visible** in normal playback: References is slide 17 and **Thank you / Any questions?** is slide 18. **Industrial standards is hidden slide 19**, skipped during the normal show. The main PDF and existing Main Slides PDF download contain the 18 visible slides.

The separate four-slide Appendix PowerPoint/PDF remains available for questions, in this order: industrial standards, evaluation definitions, three-agent/controller roles, references. All four slides in that separate file are visible. Standards is also retained as the hidden slide in the main PowerPoint, as requested.

The prepared narrative remains **12:45**, with **2:15** reserved for questions and transitions. The conclusion receives 25 seconds and references receive 10 seconds; Q&A begins on slide 18 at 12:45. Proposed speaking time remains Omar 6:15 and Abdelrahman 6:30, with handoffs after slides 6 and 14. These are rehearsal targets, not automatic slide advances.

## Animation policy — 26 November 2026

- On each content slide, the background, title, green subtitle and page number appear together on entry.
- Remaining body elements reveal one logical unit at a time, on presenter clicks. Native tables reveal one row at a time; text and graphics belonging to a card or row appear together.
- The cover and Thank you slide appear whole, with no body animation.
- The diagram keeps its 13 alternating core reveals, then reveals the legend on click 14. The fictional call example has five stages plus a summary (six clicks); contributions have four cards plus a summary (five clicks); testing has headings plus six test rows (seven clicks).
- The PowerPoint uses native fades, without automatic slide advance, macros or external service calls. PDF files show the fully revealed static state.
- **Deck Animation Plan.json** records each slide’s policy and targets. **Deck Animation Checks.json** checks body coverage, initial chrome, ordering, hidden settings and arrow styling, including import into LibreOffice’s OpenDocument format. This is not a Microsoft PowerPoint application test.

## Block diagram — slide 7

Seven core blocks and six direct connections preserve the thesis responsibilities without crossing lines. Speech conversion belongs with the caller interface; the incident record and delivery rules belong with the Python controller; reviewed medical sources and maps/simulated fleet inputs belong with the relevant agents. Agent 1 is named **Conversation**.

Every connection is bidirectional. The controller can send updated inputs and receive agent results; Agent 1 exchanges transcript and reply text with the caller’s speech interface. The legend distinguishes **vivid blue solid** transcript/reply links (`#0066CC`), **vivid orange dashed** agent input/result links (`#C75000`), and **vivid green solid** review/delivery links (`#00843D`). All use 4-point strokes and wide, short arrowheads at both ends, leaving a visible shaft.

Thirteen core clicks follow **block → associated arrow → next block**; each lower branch begins at the controller. The legend appears last. One reviewer/doctor role, simulated ambulance matching, approval before sending, maximum three same-ID attempts and missing-confirmation alerts remain explicit. Confirmation means the receiving software stored the request; it does not mean an ambulance departed.

- **Presentation Block Diagram.pptx** — identical editable animated diagram, one slide.
- **Presentation Block Diagram.pdf / .png** — static vector PDF and 2880×1620 PNG.
- **Presentation Block Diagram - Animation Preview.mp4 / .gif** — automatic review of all 14 reveals.
- **Block Diagram Animation Checks.json** — independent Office-format import checks.
- `block-diagram-evidence.json` maps components to thesis Figure 3.1 and records scope, direction and legend details.

## Focused previews

- **Slides 2-3 Preview.pdf**, **Slide 2 - Problem Definition.png**, **Slide 3 - Aim and Objectives.png** — concrete problems, one project aim, and four paired objectives.
- **Slides 5-6 - Literature Review.pdf**, **Slide 5 - DispatchMAS.png**, **Slide 6 - TriAgent.png** — Goal, Method, Results, Limitations and Relevance panels. Publication dates and metrics are checked against the supplied papers in `literature-evidence.json`.
- **Uni-Grad - Animated Call Example.pptx**, **Animated Call Example - Preview.mp4 / .gif**, **Animated Call Example - Static.pdf / Final.png**, **Animated Example Checks.json** — fictional Arabic/English caller, assumed travel time, five stages and final summary. No prototype or clinical result is claimed.
- **Slide 11 - Contributions.pdf / .png**, **Uni-Grad - Animated Contributions.pptx**, **Contributions - Animation Preview.mp4 / .gif**, **Contributions Animation Checks.json** — four illustrated cards and summary. `contributions-evidence.json` separates paper comparisons from the planned thesis section 1.5 contributions; the 40-second allocation remains.
- **Slide 12 - Testing.pdf / .png**, **Uni-Grad - Animated Testing.pptx**, **Testing - Animation Preview.mp4 / .gif**, **Testing Animation Checks.json** — headings then six complete rows under Testing type / What will be tested / How it will be tested. `testing-evidence.json` maps concrete actions and expected checks to thesis requirements; the 55-second allocation remains.

The address test changes Building 12 to Building 21 and delays the old map response. The approval test attempts sending before approval, then repeats after approval. Delivery tests cover confirmation on attempt two, failure of all three attempts and a lost confirmation after storage; only one request should be stored. Expected outcomes remain planned tests, not measured results.

## Review files

- **Uni-Grad - Midterm Presentation.pptx / .pdf** — editable presentation with speaker notes / static 18-page visible-slide export.
- **Uni-Grad - Main Slides.pdf** — the same visible-slide PDF under the existing download name.
- **Uni-Grad - Appendix.pptx / .pdf** — four supporting slides for questions.
- **Uni-Grad - Rehearsal Guide.pdf / .md** — 18-slide timing, speaking split, delivery cues, questions and rubric mapping.
- **Cost Assumptions.md** — quantities, arithmetic, official pricing links and limits.
- **Slide Overview.png / Appendix Overview.png**, **Cover Preview.pdf / .png** — visual review sheets and cover preview.
- **Presentation-checks.json**, **Deck Animation Plan.json**, **Deck Animation Checks.json** — content, template, timing, numbering, layout and reveal audits.
- **Uni-Grad - Editable Source.zip** — reproducible source and inputs.
- **Uni-Grad - Presentation Review.zip**, **Review-files.json** — review artifacts and their hashes.

## Retained content and cost estimate

The original template masters, layouts, themes, green/navy palette and approved cover design are retained. Logos appear **MSA → CSE → Engineering → Greenwich**. Plain page numbers and removal of grey thesis footers are retained; evidence remains in notes and the visible references slide. The flowchart remains slide 8. All 11 timetable tasks have one proposed accountable lead: six for Omar and five for Abdelrahman. The confirmed submission deadline remains 17 January 2027.

All eight thesis objectives remain paired once each: 1+8, 2+7, 3+4 and 5+6. DispatchMAS and TriAgent retain their verified dates, study-specific metrics and limitations. Published results are not prototype results; the <1.5-second reply value remains a target. The proposed prototype uses three language-model roles, a Python software controller, reviewer approval and simulated ambulance resources. The thesis, original template and earlier pre-midterm presentation are unchanged.

Official unit prices were checked on **24 November 2026**. The estimated test budget is **$17.78** for 100 five-minute US test calls, assuming unused Google monthly free allowances and existing development equipment. It includes GPT-5.4 mini usage across all three roles, live transcription, Google Chirp 3: HD speech, both Twilio telephone/gateway legs, geocoding, route-matrix usage and a self-hosted backend. Provider choices and quantities remain estimates. Without the Google free caps, the same quantities at first paid tiers would cost about **$26.78 before tax**. An Egyptian hospital route needs a separate quote.

The backend’s $0 means no additional software licence charge on an existing PC. Taxes, caller charges, equipment, internet, electricity and hosted infrastructure are excluded. See `Cost Assumptions.md`, `pricing-assumptions.json` and `pricing-sources/verified-price-facts.json` for calculations, official rates and retrieval evidence. Price assumptions were not changed by this animation revision.

## Rubrics

The midterm presentation rubric has six criteria totaling 10 marks: visual quality (2), organization (1), explanation (3), oral delivery (1), timing (1), and questions (2). The common rubric separately grades content, visuals, presentation skills, organization and questions on 4/3/2/0 quality levels. The rehearsal guide maps the deck to both; their scoring systems are not combined.

## Rebuild

With Python packages `python-pptx`, `pillow`, `pymupdf`, `lxml`, `reportlab`, LibreOffice/soffice and FFmpeg available:

```sh
python3 build_all.py
```

`build_presentation.py` creates the main and appendix files and applies `deck_animation.py`. `verify_deck_reveals.py` checks the resulting sequence and import behavior. The preview helpers create the standalone animated slides and MP4/GIF previews after PDF export. `package_review.py` creates the source and review ZIPs without Git operations.

The bundled Noto Sans Arabic font supports PDF rendering of the editable Arabic quote; its licence is included. The PPTX requests Arial for that text so Office font fallback can render it. Calibri/Calibri Light remain in the PPTX; PDF export uses bundled compatible Carlito through a local fontconfig file. The OFL licence is in `fonts/OFL.txt`. No system font settings are changed.

Checks cover template preservation, logo bytes/order, objectives, literature panels, native table rows, flowchart symbols, task ownership, numbering, removed source footers, visible and hidden slides, timing, body reveal coverage, arrows, text fit and slide boundaries. Every slide is rendered for visual inspection.
