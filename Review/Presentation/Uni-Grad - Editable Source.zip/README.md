# Uni-Grad midterm presentation — review draft

Based on the approved 44-page thesis (`798e1611042be81b086a27a02259942b3f9d89ab`), the supplied PowerPoint template, and both presentation rubrics. This revision starts from published presentation `338a020` and completely rebuilds slide 11 using the four anticipated contributions in thesis section 1.5. Four illustrated cards compare caller corrections, bilingual calls, explained location/ambulance selection and reliable delivery with specific boundaries in DispatchMAS and TriAgent. One presenter click reveals each card. The claim of distinction is their working connection in this hospital-call prototype, not universal novelty or measured superiority. The user requested the redesign and a push to main.

## Contributions revision — slide 11

- Four native, editable illustrated cards with 350 ms Fade entrances, on click, in reading order.
- Each card explicitly separates the paper comparison from the planned **Our** contribution.
- **Slide 11 - Contributions.pdf / .png** — focused static previews.
- **Uni-Grad - Animated Contributions.pptx** — one-slide editable animation.
- **Contributions - Animation Preview.mp4 / .gif** — automatically demonstrate the four builds.
- **Contributions Animation Checks.json** — confirms all four animations survive independent Office-format import.
- Sources and claim limits are recorded in `contributions-evidence.json`; the script and delivery cues retain the 40-second allocation.

## Review files

- **Uni-Grad - Midterm Presentation.pptx / .pdf** — 17 main slides, editable shapes/tables and speaker notes; ends with “Thank you / Any questions?”.
- **Uni-Grad - Main Slides.pdf** — the same 17 main slides under the existing download name.
- **Uni-Grad - Appendix.pptx / .pdf** — four separate supporting slides for questions: standards, metrics, roles, references. Keeping them separate makes the closing the literal last slide in the main file.
- **Uni-Grad - Rehearsal Guide.pdf / .md** — run order, proposed speaking split, delivery cues, questions and rubric mapping.
- **Cost Assumptions.md** — budget quantities, arithmetic, official pricing reference links and limits.
- **Slide Overview.png / Appendix Overview.png** — visual review sheets.
- **Presentation-checks.json** — content, template, timing, numbering and layout checks.

## Current animation revision — 25 November 2026

- **Slide 9** is a fictional case, with an editable Arabic caller quote and English translation. Vehicle travel time is assumed; no clinical or prototype result is claimed.
- Each step uses a **350 ms Fade entrance, on click**. There is no automatic slide advance and no macro or external service call.
- **Uni-Grad - Animated Call Example.pptx** is the same animated slide in a separate one-slide file.
- **Animated Call Example - Preview.mp4 / .gif** automatically show the five builds for review. They are previews of the intended click sequence.
- **Animated Call Example - Static.pdf / Final.png** show the fully revealed slide. PDF files do not play PowerPoint animations.
- The talk remains **12:45**, plus **2:15** for questions. The new 45-second case is balanced by shorter architecture/flow/specification/contribution/testing explanations. The two speaking totals remain 6:15 / 6:30.
- Native timing structure, target group IDs and fade effects are checked, then imported into LibreOffice's OpenDocument format to confirm five fades and five on-click steps survive import. This is not a Microsoft PowerPoint application test.
- The original template, cover, literature content and existing flowchart are retained. Slides after the new example are renumbered; the final main slide is 17.

## Retained literature revision — 25 November 2026

- Goal → Method → Results are arranged across the top; Limitations → Relevance are below. Method/results have wider panels to keep the explanations readable.
- The two original papers were checked directly. `literature-evidence.json` records source hashes and the metric definitions.
- `Slides 5-6 - Literature Review.pdf` and the individual paper-slide PNGs provide a focused preview.
- The literature edition retained 16 main slides. The animated edition now has 17, with the same 12:45 narrative and 2:15 reserved.

## Retained problem/aim revision — 25 November 2026

The current update applies the two requested dispatch-delivery wording changes to slides 2 and 3. The user has also approved pushing this update to main.

- Slide 2: one main problem statement, followed by three rows explaining missing patient details, location/resource difficulties, and incorrect or undelivered requests. Each row states why it matters.
- Slide 3: one project aim above four objectives, retaining the blue descriptions and green evaluation lines. The original eight objectives remain paired once each.
- Speaking notes and the rehearsal guide follow the new sequence. Slide 2 receives 60 seconds and slide 3 65 seconds; the overall narrative and speaking split are unchanged.
- `Slides 2-3 Preview.pdf` and the two slide PNGs provide a focused review. All other slide content is retained.

## Retained revisions from the published presentation

1. Plain page numbers on every slide, including the cover.
2. Cost analysis as an editable table with component, estimate and source/basis.
3. Closing slide containing only thanks, a question invitation and its number.
4. Bottom-left thesis/source footers removed; evidence remains in speaker notes and the separate references appendix.
5. Testing table with test type, component/feature and method.
6. Slide 8 uses a conventional minimal flowchart with process boxes, two decision diamonds, approval/receipt branches and failure outcomes.
7. All 11 timetable rows have one proposed accountable lead: six for Omar and five for Abdelrahman. The confirmed submission date remains 17 January 2027.
8. Block-diagram arrows use clear line weights and arrowheads, with routing/results and receipt directions explained in notes.
9. Each paper's Method, Results and Limitations has its own editable panel.

## Cost estimate status

Official unit prices were checked successfully on **24 November 2026**. The network restriction is resolved. The estimated test budget is **$17.78** for 100 five-minute calls, assuming unused Google monthly free allowances and existing development equipment. It includes GPT-5.4 mini model usage across all three roles, live transcription, Google Chirp 3: HD speech, both Twilio telephone/gateway legs, geocoding and route-matrix usage, and a self-hosted backend.

The provider pages marked the earlier GPT-4o mini, Whisper and tts-1 examples deprecated, so they were replaced in the costing example. Providers remain candidates for later testing and selection. The telephone rates describe a **US test route**; an Egyptian hospital route needs its own quote. The model allowance includes billed reasoning/output tokens. With the Google free caps already consumed, the same quantities at the first paid tiers would cost about **$26.78 before tax**.

The backend's $0 means no additional software licence charge on an existing PC. Taxes, caller charges, equipment, internet, electricity and hosted infrastructure are excluded. See `Cost Assumptions.md` for exact rates, quantities, official source links, calculations, free-cap assumptions and exclusions. The source bundle includes downloaded provider pages, retrieval hashes and `pricing-sources/verified-price-facts.json` with the published rows used in the estimate.

## Timing and content

The prepared narrative is **12:45**, with **2:15** reserved for questions and transitions. Proposed speaking time is Omar 6:15 and Abdelrahman 6:30. Rehearse with a timer; these are targets rather than automatic slide advances.

The eight objectives remain paired 1+8, 2+7, 3+4 and 5+6 into four objectives. DispatchMAS and TriAgent retain their verified dates, study-specific metrics and limitations. Published results are not prototype results; the <1.5-second reply value remains a target. The prototype retains three language-model roles, a Python software controller, staff approval and simulated ambulance resources.

The original template masters, layouts, themes, green/navy palette and approved cover design are retained. The original logo files appear MSA → CSE → Engineering → Greenwich. The thesis, original template and earlier pre-midterm presentation are unchanged.

## Rubrics

The midterm presentation rubric has six criteria totaling 10 marks: visual quality (2), organization (1), explanation (3), oral delivery (1), timing (1), and questions (2). The common rubric separately grades content, visuals, presentation skills, organization and questions on 4/3/2/0 quality levels. The guide maps the deck to both; the scoring systems are not combined.

## Rebuild

With Python packages `python-pptx`, `pillow`, `pymupdf`, `lxml`, `reportlab`, and LibreOffice/soffice plus FFmpeg available:

```sh
python3 build_all.py
```

`build_presentation.py` alone creates the main and appendix PowerPoint files. `make_animation_preview.py` creates the standalone case and its previews after PDF export. The bundled Noto Sans Arabic font is used for the editable Arabic quote during PDF rendering; its licence is included. The PPTX requests Arial for the Arabic text so normal Office Arabic font fallback can render it. The PPTX retains Calibri/Calibri Light; PDF export uses bundled, compatible Carlito fonts through a local fontconfig file. The OFL licence is in `fonts/OFL.txt`. No system font settings are changed.

Checks cover both files, template preservation, logo bytes/order, objective coverage, literature panels, native tables, flowchart symbols, one owner per task, plain numbering, removed source footers, timing, estimated text fit, and slide boundaries. Every slide is rendered for visual inspection. Source inputs include the template, logos, rubric extracts and pricing assumptions.
