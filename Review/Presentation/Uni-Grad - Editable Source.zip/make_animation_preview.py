"""Export the animated case and portable previews from its actual PowerPoint shapes.

The PPTX has native on-click fades. The MP4/GIF auto-play the recorded builds
for review; the PDF is the fully revealed static slide.
"""
from pathlib import Path
from copy import deepcopy
from io import BytesIO
import json,os,shutil,subprocess,tempfile,zipfile
from pptx import Presentation
from PIL import Image
from lxml import etree
import fitz

r=Path(__file__).parent;out=r/'output';work=r/'scenario-preview';work.mkdir(exist_ok=True)
records=json.loads((r/'slide-content-and-notes.json').read_text())
index=next(i for i,x in enumerate(records) if 'scenario' in x)
record=records[index];assert index==8
prs=Presentation(out/'Uni-Grad - Midterm Presentation.pptx')
for i,entry in reversed(list(enumerate(list(prs.slides._sldIdLst)))):
    if i!=index:prs.part.drop_rel(entry.rId);prs.slides._sldIdLst.remove(entry)
prs.core_properties.title='Uni-Grad — illustrative emergency call — animated example'
standalone=out/'Uni-Grad - Animated Call Example.pptx';prs.save(standalone)
source=prs.slides[0];layout_name=str(source.slide_layout.part.partname)
groups=[x['shape_id'] for x in record['animation']['groups']]
count=len(groups);assert count>0
# Retain the same template parts for the initial state and every recorded build.
buffer=BytesIO();prs.save(buffer);states=Presentation(BytesIO(buffer.getvalue()))
for entry in list(states.slides._sldIdLst):states.part.drop_rel(entry.rId);states.slides._sldIdLst.remove(entry)
layout=next(x for x in states.slide_layouts if str(x.part.partname)==layout_name)
for state in range(count+1):
    slide=states.slides.add_slide(layout)
    for shape in list(slide.shapes):shape._element.getparent().remove(shape._element)
    for shape in source.shapes:
        if shape.shape_id in groups and groups.index(shape.shape_id)>=state:continue
        slide.shapes._spTree.insert_element_before(deepcopy(shape._element),'p:extLst')
states_path=work/'Scenario build states.pptx';states.save(states_path)
soffice=shutil.which('soffice') or shutil.which('libreoffice')
env=os.environ.copy();env['FONTCONFIG_FILE']=str(r/'fonts/fonts.conf')
with tempfile.TemporaryDirectory(prefix='uni-grad-scenario-office-') as profile:
    common=[soffice,'-env:UserInstallation='+Path(profile).as_uri(),'--headless']
    subprocess.run(common+['--convert-to','pdf','--outdir',str(work),str(states_path)],check=True,env=env)
    subprocess.run(common+['--convert-to','odp','--outdir',str(work),str(standalone)],check=True,env=env)
# LibreOffice import must recognise every recorded entrance and manual click step.
with zipfile.ZipFile(work/'Uni-Grad - Animated Call Example.odp') as z:
    root=etree.fromstring(z.read('content.xml'))
ns={'anim':'urn:oasis:names:tc:opendocument:xmlns:animation:1.0',
    'presentation':'urn:oasis:names:tc:opendocument:xmlns:presentation:1.0',
    'smil':'urn:oasis:names:tc:opendocument:xmlns:smil-compatible:1.0'}
fades=root.xpath('//anim:transitionFilter[@smil:type="fade"]',namespaces=ns)
clicks=root.xpath('//*[@presentation:node-type="on-click"]',namespaces=ns)
assert len(fades)==count,('imported fade count',len(fades),count)
assert len(clicks)==count,('imported on-click count',len(clicks),count)
audit={'slide_number':index+1,'native_fade_entrances':count,'on_click_steps':count,'duration_ms':record['animation'].get('duration_ms',350),
       'macros':False,'automatic_slide_advance':False,
       'libreoffice_imported_fades':len(fades),'libreoffice_imported_clicks':len(clicks),
       'preview_note':'MP4/GIF automatically demonstrate the native click-build sequence; PowerPoint uses presenter clicks.',
       'fictional_case':True,'prototype_performance_claim':False}
(out/'Animated Example Checks.json').write_text(json.dumps(audit,indent=2)+'\n')
doc=fitz.open(work/'Scenario build states.pdf');assert len(doc)==count+1
frames=[]
for i,page in enumerate(doc):
    pix=page.get_pixmap(matrix=fitz.Matrix(4/3,4/3));im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples).resize((1280,720),Image.Resampling.LANCZOS)
    im.save(work/f'state-{i}.png');frames.append(im)
frames[-1].save(out/'Animated Call Example - Final.png')
static=fitz.open();static.insert_pdf(doc,from_page=count,to_page=count);static.save(out/'Animated Call Example - Static.pdf',garbage=4,deflate=True)
fps=25
video=out/'Animated Call Example - Preview.mp4'
cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pixel_format','rgb24',
     '-video_size',f'{frames[0].width}x{frames[0].height}','-framerate',str(fps),'-i','pipe:0',
     '-an','-c:v','libx264','-pix_fmt','yuv420p','-crf','21','-movflags','+faststart',str(video)]
p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
def hold(im,seconds):
    raw=im.tobytes()
    for _ in range(round(seconds*fps)):p.stdin.write(raw)
hold(frames[0],1.0)
for step in range(1,count+1):
    for frame in range(1,10):p.stdin.write(Image.blend(frames[step-1],frames[step],frame/9).tobytes())
    hold(frames[step],3.0 if step<count else 4.0)
p.stdin.close();assert p.wait()==0
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(video),
                '-filter_complex','fps=12,scale=800:-1:flags=lanczos,split[s0][s1];[s0]palettegen=max_colors=192:stats_mode=diff[p];[s1][p]paletteuse=dither=bayer:bayer_scale=3',
                '-loop','0',str(out/'Animated Call Example - Preview.gif')],check=True)
print(f'PASS: {count} native on-click fades survive LibreOffice import; {count+1} states and animated/static previews exported.')
