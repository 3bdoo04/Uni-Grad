# Requested presentation revisions

- Plain sequential page numbers, including cover.
- Cost table with usage assumptions, estimates, and price sources.
- Actual final slide: Thank you / Any questions only.
- No grey thesis/source footer on slides.
- Testing table: type, component/feature, test method.
- Slide 8: minimal flowchart, with start/end and decisions.
- Timetable: one proposed accountable lead per task; distributed between Omar and Abdelrahman.
- Block diagram: longer, heavier arrows with clear heads.
- Literature: one bounded shape each for Method, Results, Limitations.

Keep the 15-minute limit. Main deck ends with the closing slide; supporting material is exported separately. The user has approved pushing this presentation revision to main. Official provider prices verified on 24 November 2026; estimated usage and unused Google free caps are disclosed.


## 25 November 2026 — approved revision

- Replace slide 2's vague fragments with the main problem plus concrete problems and consequences.
- Move the project aim from slide 2 to slide 3, above the four objectives.
- Preserve all eight thesis objectives through the existing four pairs.
- Keep 16 main slides, original colours/template, and the 15-minute total plan.
- Revised slides were shown for review; the user has now approved pushing them to main.


## Delivery wording — approved for push

- Slide 2, third consequence: The dispatch request may fail to reach the receiving team.
- Slide 3, fourth objective: Send approved dispatch requests and record whether delivery was confirmed.
- Keep simulated ambulance matching and confirm the revised text fits before pushing.


## Literature clarity — approved for push

- Add Goal immediately before Method and Relevance immediately after Limitations in reading order.
- Rewrite both methods and limitations with direct explanations.
- Define DispatchMAS’s 94% as a doctor-rated simulated extra-responder contact outcome.
- Define TriAgent’s 85% as the proportion of reference-critical cases identified as critical.
- Retain the publication dates, two paper slides, original template, and 15-minute plan.
- User explicitly requested pushing this revision to main.


## Animated call example — approved for publication

- Add one slide after the existing flowchart, with native on-click animation.
- Use a clearly fictional Egyptian Arabic caller and an English translation.
- Reveal collection/location, preliminary assessment/resource recommendation, staff approval and delivery confirmation in sequence.
- No diagnosis, treatment instruction, real response-time result or working-prototype claim.
- Retain the 15-minute plan and existing template.
- Animated previews and the editable one-slide example were provided; the user has explicitly instructed pushing this revision to main.


## Critical paper relevance — approved for push

- Ground each relevance block in the method/result/limitation shown on the same paper slide.
- DispatchMAS: focused questioning for our interview; separate delivery/retry/deduplication tests because contact was simulated.
- TriAgent: selection of necessary checks in our controller; separately evaluate our phone triage because the paper used recorded vital signs and a trained classifier.
- Keep the animation, other slide content and the 15-minute plan.
- User requested the changes and a push to main.


## Medical results, method and shared relevance — approved for push

- Replace the DispatchMAS extra-service contact statistic with medical advice provision in 91% of simulated scenarios needing advice and physician helpfulness ratings.
- Define the result as advice provision rather than clinical accuracy, patient outcomes or real ambulance delivery.
- Explain TriAgent's Orchestrator Agent, specialist modules and Critique Agent, with their respective tasks. Explain the trained urgency model and emergency bypass in speaker notes.
- Rewrite both Relevance blocks as the actual medical functions shared with our project, rather than development or testing plans.
- Keep the five-block layout, original template, animation and 15-minute plan; fit the expanded method at the existing readable font size.
- User explicitly requested making these changes and pushing them to main.


## Contributions and uniqueness — slide 11, approved for push

- Replace the old comparison table completely with the four anticipated contributions from thesis section 1.5.
- Compare each planned contribution with a specific reported scope or evaluation boundary in DispatchMAS or TriAgent.
- Use editable illustrations, aligned cards and four presenter-controlled fade entrances while preserving the original template and palette.
- Keep comparisons to prototype capabilities; do not claim universal novelty, clinical effectiveness or superior measured performance.
- Preserve the other main slides, slide 11's 40 seconds and the overall 15-minute plan.
- Provide a focused preview and verify the native animation before pushing; user explicitly requested the push.


## Specific proposed testing procedures — slide 12, approved for push

- Replace the slide completely; avoid generic instructions such as run scenarios or inspect outcomes.
- Keep three clear columns: testing type, what will be tested and how it will be tested.
- Name concrete inputs/actions and expected checks for medical outputs, changed addresses/late results, ambulance selection, bilingual calls/reply timing, request delivery/duplicates and approval restrictions.
- Include successful confirmation, failed delivery after three attempts and a lost return confirmation; do not equate a receipt with ambulance departure.
- Add editable illustrations and six presenter-controlled fade entrances while retaining the template, other slides and 15-minute total plan.
- Keep the 55-second slot; no completed results or unreviewed clinical reference answers are claimed.
- User explicitly requested the changes and pushing them to main.


## Exact test-method wording — approved for push

- Apply the user's exact Building 12-to-21 method to the address-correction row.
- Apply the user's exact before/after reviewer approval method to the existing approval row. The user called it test 5; the current slide places approval in row 6, while row 5 is the separate delivery-reliability test.
- Keep the delivery-failure row, all six animations, other slides and the 15-minute plan.
- Update notes and previews to match; push to main as requested.


## Outdated wording — approved for push

- Replace stale with outdated in slide 15 and the matching rehearsal-guide term.
- Preserve other main slides, animations and timing; push to main as requested.


## Animated presentation block diagram — approved for push

- Redraw slide 7 from thesis Figure 3.1, retaining its 13 components and explaining each function concretely.
- Separate controller task/result links from voice, data/tool, approval, confirmation and failure paths.
- Show one reviewer user role, three AI agents, a Python controller and a software test receiver with simulated resources.
- Give each block and each logical arrow a separate entrance: 30 clicks in total.
- Export identical standalone Presentation Block Diagram as editable animated PPTX, vector PDF and high-resolution PNG in Thesis Diagrams.
- Preserve other slides and the 15-minute plan; user explicitly requested pushing both presentation and diagram to main.
