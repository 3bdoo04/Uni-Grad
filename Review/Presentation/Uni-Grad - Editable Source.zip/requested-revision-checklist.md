# Requested presentation revisions

## Current revision — 26 November 2026, approved for push

- Make the caller/speech-interface ↔ Agent 1 connection bidirectional.
- Make each agent ↔ Python controller connection bidirectional so updated facts can be sent and results returned.
- Rename Agent 1 from Interview to **Conversation**.
- Use vivid, projector-visible arrow colours, 4-point strokes and wide, short arrowheads at both ends, leaving a visible shaft: blue solid for transcript/reply text, orange dashed for agent tasks/results, green solid for review/delivery messages. Match the legend to all three types.
- Preserve seven core blocks, six direct non-crossing links and explicit component functions. Preserve the 13 core reveals in block → associated arrow → next block order; reveal the legend on click 14. Each lower branch begins at the controller.
- On every content slide, show the background, title, green subtitle and page number together on entry; reveal the remaining body units one by one. Native tables reveal one row at a time.
- Show the cover, timetable (slide 14) and Thank you slide whole, with no body animation.
- Restore References as visible slide 17. Place Thank you at visible slide 18. Restore Industrial standards as hidden slide 19, skipped in normal playback.
- Retain the separate four-slide appendix: industrial standards, evaluation definitions, agent/controller roles, references.
- Preserve the 12:45 narrative and 2:15 Q&A: conclusion 25 seconds, references 10 seconds. No automatic slide advance.
- Update both the presentation and standalone **Presentation Block Diagram.pptx / .pdf / .png** in Thesis Diagrams, with matching previews and audits. Push them to main as explicitly requested.

## Retained approved requirements

- Use the supplied template’s design and colour language, the approved organized cover, and logos in MSA → CSE → Engineering → Greenwich order.
- Use plain page numbers, including the cover. Remove grey thesis/source footers; retain evidence in speaker notes and references.
- State the main problem clearly. In slide 2’s third consequence, use: **The dispatch request may fail to reach the receiving team.**
- Put the project aim and four paired objectives on slide 3. Retain all eight thesis objectives exactly once through pairs 1+8, 2+7, 3+4, 5+6.
- In the fourth objective, use: **Send approved dispatch requests and record whether delivery was confirmed.**
- Keep the two most relevant papers on separate slides with Goal, Method, Results, Limitations and Relevance panels, verified publication dates and direct explanations.
- Use DispatchMAS’s medical advice provision in 91% of simulated scenarios needing advice and physician helpfulness ratings. Define advice provision separately from clinical accuracy, patient outcomes or real ambulance delivery.
- Explain TriAgent’s Orchestrator Agent, specialist modules and Critique Agent. Define 85% as the reference-critical cases identified as critical; explain the trained urgency model, recorded vital signs and emergency bypass in notes.
- Write each relevance block around actual medical functions shared with our project rather than development plans. Keep source checks and claim limits in literature-evidence.json.
- Keep slide 8 as the minimal flowchart with process blocks, approval/delivery decisions and explicit failure paths.
- Keep the fictional Arabic/English call example on slide 9. Reveal its five stages and then summary in six clicks. Travel time is assumed; no working-prototype or clinical result is claimed.
- Keep four illustrated contribution cards based on thesis section 1.5, with specific comparisons to DispatchMAS or TriAgent and a final summary. Five clicks in total; 40 seconds. Do not claim universal novelty or measured superiority.
- Keep slide 12’s three columns: Testing type / What will be tested / How it will be tested. Reveal headings, then six complete rows in seven clicks; retain the 55-second allocation.
- Use the exact corrected-location test: **Change the address from Building 12 to Building 21. Delay the Building 12 map response; verify that it cannot overwrite the corrected location.**
- Use the exact approval test: **Try sending a dispatch request before the reviewer approves it → no request sent. Obtain reviewer approval → send the approved request.**
- Retain separate delivery tests for confirmation on attempt two, all three attempts failing and a lost confirmation after storage. Retries use the same ID, one request is stored, and missing confirmation alerts the reviewer. A confirmation does not mean ambulance departure.
- Keep the cost analysis as an editable table with each component/feature, estimate and official price source. Prices were checked on 24 November 2026; quantities, unused Google free caps and exclusions remain disclosed. The scenario estimate remains $17.78.
- Give each of the 11 timetable tasks one proposed accountable lead: six Omar, five Abdelrahman. Retain the confirmed submission deadline of 17 January 2027.
- Use **outdated**, rather than stale, in the challenges slide and guide.
- Keep the single reviewer/doctor user role, three AI roles, ordinary Python controller, software test receiver and simulated ambulance resources explicit.
- Provide editable standalone animated slides, focused static previews, MP4/GIF previews, content/animation audits, source ZIP and review ZIP under their existing filenames.
- Preserve the thesis and original thesis diagrams. Apply the changes to the presentation and its standalone presentation diagram only.

The guide maps the deck to both supplied presentation rubrics without combining their scoring systems. Prepared timings and expected test outcomes remain plans, not measured project results. The user explicitly authorized pushing this updated presentation and block diagram to main.
