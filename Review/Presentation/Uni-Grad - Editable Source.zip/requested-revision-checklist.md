# Requested presentation revisions

- Plain sequential page numbers, including cover.
- Cost table with usage assumptions, estimates, and price sources.
- Actual final slide: Thank you / Any questions only.
- No grey thesis/source footer on slides.
- Testing table: type, component/feature, test method.
- Slide 8: minimal flowchart, with start/end and decisions.
- Timetable: one proposed accountable lead per task; distributed between Omar and Abdelrahman.
- Block diagram: longer, heavier arrows with clear heads.
- Literature: one bounded shape each for Method, Results, Limitations.

Keep the 15-minute limit. Main deck ends with the closing slide; supporting material is exported separately. The user has approved pushing this presentation revision to main. Official provider prices verified on 24 November 2026; estimated usage and unused Google free caps are disclosed.


## 25 November 2026 — approved revision

- Replace slide 2's vague fragments with the main problem plus concrete problems and consequences.
- Move the project aim from slide 2 to slide 3, above the four objectives.
- Preserve all eight thesis objectives through the existing four pairs.
- Keep 16 main slides, original colours/template, and the 15-minute total plan.
- Revised slides were shown for review; the user has now approved pushing them to main.


## Delivery wording — approved for push

- Slide 2, third consequence: The dispatch request may fail to reach the receiving team.
- Slide 3, fourth objective: Send approved dispatch requests and record whether delivery was confirmed.
- Keep simulated ambulance matching and confirm the revised text fits before pushing.
