"""Native PowerPoint on-click fade entrances (PresentationML timing, no macros).

The node structure follows standard PowerPoint timing, cross-checked against
LibreOffice's public PPTX interoperability fixtures. No fixture artwork is used.
"""
from pptx.oxml.xmlchemy import OxmlElement


def element(tag, parent=None, **attrs):
    e=OxmlElement('p:'+tag)
    for k,v in attrs.items():e.set(k,str(v))
    if parent is not None:parent.append(e)
    return e


def condition(parent,delay='0'):
    element('cond',element('stCondLst',parent),delay=delay)


def target(parent,shape_id):
    element('spTgt',element('tgtEl',parent),spid=shape_id)


def add_click_fades(slide,groups,duration_ms=350):
    timing=element('timing')
    root=element('cTn',element('par',element('tnLst',timing)),id=1,dur='indefinite',restart='never',nodeType='tmRoot')
    seq=element('seq',element('childTnLst',root),concurrent=1,nextAc='seek')
    main=element('cTn',seq,id=2,dur='indefinite',nodeType='mainSeq')
    steps=element('childTnLst',main)
    next_id=3
    for group in groups:
        click=element('cTn',element('par',steps),id=next_id,fill='hold');next_id+=1
        condition(click,'indefinite')
        simultaneous=element('cTn',element('par',element('childTnLst',click)),id=next_id,fill='hold');next_id+=1
        condition(simultaneous)
        entrance=element('cTn',element('par',element('childTnLst',simultaneous)),
                         id=next_id,presetID=10,presetClass='entr',presetSubtype=0,fill='hold',nodeType='clickEffect');next_id+=1
        condition(entrance)
        actions=element('childTnLst',entrance)
        show=element('set',actions);behavior=element('cBhvr',show)
        ctn=element('cTn',behavior,id=next_id,dur=1,fill='hold');next_id+=1;condition(ctn)
        target(behavior,group.shape_id)
        attribute=element('attrName',element('attrNameLst',behavior));attribute.text='style.visibility'
        element('strVal',element('to',show),val='visible')
        fade=element('animEffect',actions,transition='in',filter='fade')
        behavior=element('cBhvr',fade);element('cTn',behavior,id=next_id,dur=duration_ms);next_id+=1
        target(behavior,group.shape_id)
    for tag,event in [('prevCondLst','onPrev'),('nextCondLst','onNext')]:
        cond=element('cond',element(tag,seq),evt=event,delay=0)
        element('sldTgt',element('tgtEl',cond))
    slide._element.insert_element_before(timing,'p:extLst')
    return {'effect':'fade','trigger':'on click','duration_ms':duration_ms,
            'groups':[{'shape_id':g.shape_id,'name':g.name} for g in groups]}
