"""Audit native deck entrances, static chrome, hidden slides and diagram arrows.

An independent LibreOffice import must retain each slide's exact entrance count.
This script writes an audit artifact; it does not modify the PowerPoint.
"""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil
import subprocess
import tempfile
import zipfile

from lxml import etree
from pptx import Presentation
from pptx.oxml.ns import qn


ROOT = Path(__file__).parent
OUT = ROOT / 'output'
PPTX = OUT / 'Uni-Grad - Midterm Presentation.pptx'
WORK = ROOT / 'deck-animation-preview'
WORK.mkdir(exist_ok=True)
records = json.loads((ROOT / 'slide-content-and-notes.json').read_text())
prs = Presentation(PPTX)
assert len(prs.slides) == 19, ('Main physical slide count', len(prs.slides))
records = records[:len(prs.slides)]
assert len(records) == len(prs.slides)
expected_visibility = ['1'] * 18 + ['0']
assert [slide._element.get('show', '1') for slide in prs.slides] == expected_visibility
assert 'References' in records[16]['title']
assert records[17]['title'] == 'Thank you'
assert records[18]['title'] == 'Industrial standards'
assert not records[16].get('backup') and not records[17].get('backup')

slide_audits = []
for index, (slide, record) in enumerate(zip(prs.slides, records)):
    whole = index in (0, 17)
    policy = record.get('body_reveal_policy', {})
    timings = slide._element.findall(qn('p:timing'))
    effects = slide._element.xpath('.//p:animEffect[@filter="fade"]')
    fade_targets = slide._element.xpath('.//p:animEffect/p:cBhvr/p:tgtEl/p:spTgt/@spid')
    click_effects = slide._element.xpath('.//p:cTn[@nodeType="clickEffect"]')
    roots = slide._element.xpath('.//p:cTn[@nodeType="tmRoot"]')
    assert not slide._element.xpath('./p:transition[@advTm]'), ('Automatic slide advance', index+1)
    ids = slide._element.xpath('.//p:cNvPr/@id')
    assert len(ids) == len(set(ids)), ('Duplicate shape ID', index+1)
    if whole:
        assert not timings and not effects and not click_effects, ('Whole-entry slide has timing', index+1)
        assert policy.get('mode') == 'whole_slide'
        expected_targets = []
        chrome = []
    else:
        assert len(timings) == len(roots) == 1, ('Timing root count', index+1, len(timings), len(roots))
        assert policy.get('mode') == 'progressive_body'
        assert policy.get('title_subtitle_number_together') is True
        expected_targets = [str(x['shape_id']) for x in record['animation']['groups']]
        chrome = [str(x) for x in policy['chrome_shape_ids']]
        assert len(expected_targets) > 0
        assert len(expected_targets) == len(set(expected_targets)), ('Repeated metadata target', index+1)
        assert fade_targets == expected_targets, ('Native fade order differs from metadata', index+1, fade_targets, expected_targets)
        assert len(effects) == len(click_effects) == len(expected_targets), ('Entrance count', index+1)
        assert all(count == 1 for count in Counter(fade_targets).values())
        all_targets = set(slide._element.xpath('.//p:timing//p:spTgt/@spid'))
        assert not all_targets.intersection(chrome), ('Animated title/subtitle/number', index+1)
        top_ids = {str(shape.shape_id) for shape in slide.shapes}
        assert set(chrome).issubset(top_ids), ('Chrome not top-level', index+1)
        assert top_ids-set(chrome) == set(expected_targets), ('Uncovered or repeated body element', index+1, top_ids-set(chrome), set(expected_targets))
        assert set(expected_targets).issubset(top_ids)
    slide_audits.append({
        'slide':index+1, 'title':record['title'],
        'visible_in_normal_show':expected_visibility[index] == '1',
        'entry':'whole slide at once' if whole else 'background, title, green subtitle and slide number together; body one element per click',
        'native_clicks':len(click_effects), 'native_fades':len(effects),
        'chrome_shape_ids':[int(x) for x in chrome],
        'ordered_body_shape_ids':[int(x) for x in expected_targets],
        'native_order_matches_metadata':True,
        'every_nonchrome_body_shape_targeted_once':not whole,
    })


# Six real diagram links, not only the examples in the legend, must have two
# large arrowheads and projector-friendly strokes. Schema order is significant.
diagram = prs.slides[6]
blueprint = records[6]['block_diagram']
expected_colours = {'voice':'0066CC', 'control':'C75000', 'hospital':'00843D'}
assert {arrow['kind'] for arrow in blueprint['arrows']} == set(expected_colours)
group_by_name = {shape.name:shape for shape in diagram.shapes if shape.shape_type == 6}
assert len(blueprint['arrows']) == 6
arrow_audits = []


def check_line(line, colour, label):
    children = [etree.QName(child).localname for child in line]
    head, tail = line.find(qn('a:headEnd')), line.find(qn('a:tailEnd'))
    assert head is not None and tail is not None, ('Not bidirectional', label)
    assert children.index('headEnd') < children.index('tailEnd'), ('Line-end schema order', label)
    for end in (head, tail):
        assert end.get('type') == 'triangle', ('Wrong arrowhead', label)
        assert end.get('w') == 'lg' and end.get('len') == 'sm', ('Arrowhead must be wide and short to retain a visible shaft', label)
    width = int(line.get('w', '0'))/12700
    assert width >= 3.5, ('Thin projector stroke', label, width)
    rgb = line.find(qn('a:solidFill')).find(qn('a:srgbClr')).get('val').upper()
    assert rgb == colour, ('Wrong stroke colour', label, rgb, colour)
    return {'rgb':rgb, 'width_points':width, 'bidirectional':True,
            'head_width':'large', 'tail_width':'large', 'head_length':'short',
            'tail_length':'short', 'schema_head_before_tail':True}


for arrow in blueprint['arrows']:
    group = group_by_name['Arrow - '+arrow['id']]
    lines = group._element.xpath('.//p:cxnSp/p:spPr/a:ln')
    assert len(lines) == 1, ('Core link should be straight', arrow['id'], len(lines))
    info = check_line(lines[0], expected_colours[arrow['kind']], arrow['id'])
    dash = lines[0].find(qn('a:prstDash'))
    if arrow['kind'] == 'control':
        assert dash is not None and dash.get('val') not in ('solid', None), ('Missing task/result dash', arrow['id'])
    else:
        assert dash is None or dash.get('val') == 'solid', ('Unexpected dash', arrow['id'])
    arrow_audits.append({'id':arrow['id'], 'source':arrow['source'],
                         'target':arrow['target'], 'kind':arrow['kind'], **info})
legend = group_by_name['Arrow legend']
legend_lines = legend._element.xpath('.//p:cxnSp/p:spPr/a:ln')
assert len(legend_lines) == 3
legend_colours = []
for line in legend_lines:
    colour = line.find(qn('a:solidFill')).find(qn('a:srgbClr')).get('val').upper()
    assert colour in expected_colours.values()
    check_line(line, colour, 'legend '+colour)
    legend_colours.append(colour)
assert set(legend_colours) == set(expected_colours.values())
agent1 = group_by_name['Block - agent1']
agent1_text = '\n'.join(x.text for x in agent1.shapes if x.has_text_frame)
assert 'Agent 1 · Conversation' in agent1_text and 'Interview' not in agent1_text

# Independent import of the actual full deck, including its hidden standard
# slide, catches timing structures that are syntactically present but unusable.
soffice = shutil.which('soffice') or shutil.which('libreoffice')
if not soffice:
    raise SystemExit('LibreOffice is required for independent animation validation.')
odp = WORK / (PPTX.stem+'.odp')
odp.unlink(missing_ok=True)
env = os.environ.copy()
env['FONTCONFIG_FILE'] = str(ROOT/'fonts/fonts.conf')
with tempfile.TemporaryDirectory(prefix='uni-grad-full-deck-animation-') as profile:
    command = [soffice, '-env:UserInstallation='+Path(profile).as_uri(), '--headless',
               '--convert-to', 'odp', '--outdir', str(WORK), str(PPTX)]
    result = subprocess.run(command, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    if result.returncode:
        raise RuntimeError('Full-deck Office import failed: '+result.stdout)
    print(result.stdout.strip())
assert odp.is_file(), 'Independent ODP export missing'
with zipfile.ZipFile(odp) as archive:
    content = etree.fromstring(archive.read('content.xml'))
    styles = etree.fromstring(archive.read('styles.xml'))
ns = {'draw':'urn:oasis:names:tc:opendocument:xmlns:drawing:1.0',
      'office':'urn:oasis:names:tc:opendocument:xmlns:office:1.0',
      'anim':'urn:oasis:names:tc:opendocument:xmlns:animation:1.0',
      'presentation':'urn:oasis:names:tc:opendocument:xmlns:presentation:1.0',
      'smil':'urn:oasis:names:tc:opendocument:xmlns:smil-compatible:1.0',
      'style':'urn:oasis:names:tc:opendocument:xmlns:style:1.0'}
pages = content.xpath('//office:presentation/draw:page', namespaces=ns)
assert len(pages) == 19, ('Imported page count', len(pages))
style_map = {}
for document in (content, styles):
    for style in document.xpath('//style:style', namespaces=ns):
        style_map[style.get('{'+ns['style']+'}name')] = style
for index, page in enumerate(pages):
    fades = page.xpath('.//anim:transitionFilter[@smil:type="fade"]', namespaces=ns)
    clicks = page.xpath('.//*[@presentation:node-type="on-click"]', namespaces=ns)
    expected = slide_audits[index]['native_clicks']
    assert len(fades) == len(clicks) == expected, ('Imported animation count', index+1, len(fades), len(clicks), expected)
    visibility = page.get('{'+ns['presentation']+'}visibility')
    if visibility is None:
        style = style_map.get(page.get('{'+ns['draw']+'}style-name'))
        if style is not None:
            properties = style.find('{'+ns['style']+'}drawing-page-properties')
            if properties is not None:
                visibility = properties.get('{'+ns['presentation']+'}visibility')
    if visibility is not None:
        assert (visibility == 'hidden') == (index == 18), ('Imported hidden flag', index+1, visibility)
    slide_audits[index].update(libreoffice_imported_fades=len(fades),
                               libreoffice_imported_clicks=len(clicks),
                               libreoffice_visibility=visibility,
                               independent_import_matches_native=True)

audit = {
    'checked_at_utc':datetime.now(timezone.utc).isoformat(),
    'file':PPTX.name, 'sha256':hashlib.sha256(PPTX.read_bytes()).hexdigest(),
    'physical_slides':19, 'visible_slides':18,
    'whole_entry_slides':[1,18], 'visible_references_slide':17,
    'hidden_industrial_standards_slide':19,
    'entry_policy':'Slide background, title, green subtitle and slide number appear together. All other logical body elements reveal one per click, except intro and Thank You which appear whole.',
    'arrow_bidirectionality':arrow_audits,
    'legend_matches_arrow_colours':True,
    'all_agent_controller_arrows_bidirectional':True,
    'caller_agent1_arrow_bidirectional':True,
    'arrow_colours':expected_colours,
    'all_slides_independently_imported':True,
    'fully_validated':True,
    'slides':slide_audits,
}
(OUT/'Deck Animation Checks.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2)+'\n')
print('PASS: all 19 physical slides retain the expected animations after independent import; intro/Thank You whole, references visible and industrial standards hidden.')
print('PASS: all six diagram links are bidirectional, large-headed, correctly ordered and at least 3.5 pt; legend colours match.')
