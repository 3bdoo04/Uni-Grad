"""Build the midterm deck on the uploaded template's original masters/layouts.

All diagrams/charts are native PowerPoint shapes. Logo bytes are unchanged;
PowerPoint crop properties remove transparent margins. No thesis claims of
completed implementation or measured prototype performance are introduced.
"""
from pathlib import Path
from datetime import datetime, timezone
from copy import deepcopy
import json
import math
import zipfile
from PIL import Image, ImageFont
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.oxml.xmlchemy import OxmlElement

ROOT = Path(__file__).parent
TEMPLATE = ROOT / 'inputs/Presentation_Template.pptx'
LOGOS = ROOT / 'inputs/Logos'
OUT = ROOT / 'output'
OUT.mkdir(exist_ok=True)
NAVY = '062B49'
INK = '102346'
GREEN = '549848'  # Sampled from the original template's green ribbon.
DARKGREEN = '3D6B32'
MINT = 'F1F7EE'
GRAY = '566672'
LINE = 'D5DFD2'
WHITE = 'FFFFFF'
PALE = 'F5F7F8'
GOLD = 'B58C55'
FONT = 'Calibri'
DISPLAY = 'Calibri Light'
prs = Presentation(TEMPLATE)
cover_layout = prs.slides[0].slide_layout
body_layout = prs.slides[2].slide_layout
for slide_id in list(prs.slides._sldIdLst):
    prs.part.drop_rel(slide_id.rId)
    prs.slides._sldIdLst.remove(slide_id)
SW, SH = prs.slide_width / 914400, prs.slide_height / 914400
records = []


def rgb(value):
    return RGBColor.from_string(value)


def rect(slide, x, y, w, h, fill=WHITE, stroke=None, radius=False, line_width=.9):
    kind = MSO_SHAPE.ROUNDED_RECTANGLE if radius else MSO_SHAPE.RECTANGLE
    shape = slide.shapes.add_shape(kind, Inches(x), Inches(y), Inches(w), Inches(h))
    if radius:
        shape.adjustments[0] = .08
    shape.fill.solid()
    shape.fill.fore_color.rgb = rgb(fill)
    if stroke:
        shape.line.color.rgb = rgb(stroke)
        shape.line.width = Pt(line_width)
    else:
        shape.line.fill.background()
    return shape


def text(slide, x, y, w, h, value, size=24, color=INK, bold=False,
         align=PP_ALIGN.LEFT, valign=MSO_ANCHOR.TOP, font=FONT):
    # Reserve the font's full line box, not just nominal point size. This keeps
    # ascenders/descenders inside the editable text frame in Office and Impress.
    metric_font=ImageFont.truetype(str(ROOT/'fonts'/('Carlito-Bold.ttf' if bold else 'Carlito-Regular.ttf')),round(size*10))
    line_count=0
    for paragraph in value.split('\n'):
        lines=['']
        for word in paragraph.split(' '):
            candidate=(lines[-1]+' '+word).strip()
            if metric_font.getlength(candidate)/10>w*72 and lines[-1]:
                lines.append(word)
            else:
                lines[-1]=candidate
        line_count+=len(lines)
    h=max(h,(line_count*size*1.28+2)/72)
    box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = box.text_frame
    tf.clear()
    tf.word_wrap = True
    tf.margin_left = tf.margin_right = 0
    tf.margin_top = tf.margin_bottom = 0
    tf.vertical_anchor = valign
    for i, line in enumerate(value.split('\n')):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.text = line
        p.alignment = align
        p.space_before = Pt(0)
        p.space_after = Pt(0)
        p.line_spacing = 1.06
        p.font.name = font
        p.font.size = Pt(size)
        p.font.bold = bold
        p.font.color.rgb = rgb(color)
    return box


def tag(slide, x, y, w, label, fill=MINT, color=DARKGREEN, size=17):
    rect(slide, x, y, w, .38, fill)
    text(slide, x + .09, y + .035, w - .18, .33, label, size=size, color=color, bold=True)


def arrow(slide, x1, y1, x2, y2, color=GREEN, width=2.0, both=False, dash=False):
    shape = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,
                                      Inches(x1), Inches(y1), Inches(x2), Inches(y2))
    shape.line.color.rgb = rgb(color)
    shape.line.width = Pt(width)
    ln = shape._element.spPr.find('{http://schemas.openxmlformats.org/drawingml/2006/main}ln')
    end = OxmlElement('a:tailEnd')
    end.set('type', 'triangle')
    end.set('w', 'sm')
    end.set('len', 'sm')
    ln.append(end)
    if both:
        begin = OxmlElement('a:headEnd')
        begin.set('type', 'triangle')
        begin.set('w', 'sm')
        begin.set('len', 'sm')
        ln.append(begin)
    if dash:
        shape.line.dash_style = 2
    return shape


def new_slide(title, section, source='', backup=False, cover=False):
    slide = prs.slides.add_slide(cover_layout if cover else body_layout)
    for shape in list(slide.shapes):
        shape._element.getparent().remove(shape._element)
    idx = len(prs.slides)
    if not cover:
        text(slide, .53, .34, 12.2, .73, title, size=34, color=NAVY, font=DISPLAY)
        text(slide, .55, 1.23, 11.9, .32, section.upper(), size=16,
             color=DARKGREEN, bold=True)
        text(slide, .55, 7.17, 10.9, .25, 'Uni-Grad  •  Graduation Project I  •  2026/2027',
             size=13, color=GRAY)
        text(slide, 11.75, 7.16, 1.02, .27,
             f'B{idx-16:02d}' if backup else f'{idx:02d} / 16', size=14,
             color=NAVY, align=PP_ALIGN.RIGHT)
        if source:
            text(slide, .56, 6.90, 12.08, .22, source, size=12, color=GRAY)
    records.append({'slide': idx, 'title': title, 'backup': backup,
                    'source': source, 'section': section})
    return slide


def note(slide, speaker, seconds, script, cue, transition='', qa='', sources=''):
    rec = records[-1]
    rec.update(speaker=speaker, seconds=seconds, script=script,
               cue=cue, transition=transition, qa=qa, verification=sources)
    slide.notes_slide.notes_text_frame.text = (
        f"SUGGESTED SPEAKER: {speaker}\nTIME: {seconds} seconds\n"
        f"KEY MESSAGE / SPOKEN OUTLINE\n{script}\n\nDELIVERY CUE\n{cue}\n"
        f"\nTRANSITION\n{transition}\n\nQ&A PREPARATION\n{qa}\n"
        f"\nSOURCE AND SCOPE CHECK\n{sources}\n"
    )


def node(slide, x, y, w, h, title, detail='', fill=WHITE, title_size=23,
         detail_size=21, title_color=NAVY, center=False):
    rect(slide, x, y, w, h, fill, stroke=LINE, radius=True)
    align = PP_ALIGN.CENTER if center else PP_ALIGN.LEFT
    text(slide, x+.17, y+.13, w-.34, .45, title, size=title_size,
         color=title_color, bold=True, align=align)
    if detail:
        text(slide, x+.17, y+.66, w-.34, h-.76, detail, size=detail_size,
             color=INK, align=align)


def picture_contain(slide, path, cx, cy, maxw, maxh):
    im = Image.open(path)
    iw, ih = im.size
    bbox = im.getbbox() if im.mode == 'RGBA' else (0, 0, iw, ih)
    x0, y0, x1, y1 = bbox
    vw, vh = x1-x0, y1-y0
    scale = min(maxw/vw, maxh/vh)
    w, h = vw*scale, vh*scale
    pic = slide.shapes.add_picture(str(path), Inches(cx-w/2), Inches(cy-h/2),
                                   Inches(w), Inches(h))
    pic.crop_left, pic.crop_right = x0/iw, (iw-x1)/iw
    pic.crop_top, pic.crop_bottom = y0/ih, (ih-y1)/ih
    return pic


# 1 — Preserve the campus photograph, green wave, olive branch and typography.
s = new_slide('Agentic Emergency Tele-Triage & Autonomous Medical Dispatch System',
              'Cover', cover=True)
rect(s, 0, 0, SW, 1.57, WHITE)
rect(s, 0, 1.57, SW, .035, GREEN)
logos = ['MSA Logo - V.png','CSE Department.png','Engineering1.png','University of Greenwich - Blue.png']
for cx, name in zip([2.05, 5.12, 8.18, 11.23], logos):
    picture_contain(s, LOGOS/name, cx, .78, 2.35, 1.12)
text(s, 6.10, 2.40, 6.65, .36, 'GRADUATION PROJECT I  /  MIDTERM',
     size=18, color=DARKGREEN, bold=True)
text(s, 5.86, 3.02, 6.99, 1.70,
     'Agentic Emergency\nTele-Triage & Autonomous\nMedical Dispatch System',
     size=32, color=NAVY, bold=False, font=DISPLAY)
text(s, 5.90, 4.97, 6.90, .40, 'Three agents. One hospital-reviewed request.', size=21, color=DARKGREEN)
text(s, 5.90, 5.64, 6.85, .35, 'Omar Mostafa Omar  ·  235559', size=21)
text(s, 5.90, 6.08, 6.85, .35, 'Abdelrahman Mahmoud Ali  ·  237343', size=21)
text(s, 5.90, 6.57, 6.85, .34, 'Supervisor: Dr. Gehad Mohey Rezk', size=20)
text(s, 5.90, 7.00, 6.85, .28, 'Computer Systems Engineering  •  MSA University', size=17, color=GRAY)
note(s, 'Omar', 20,
     'Every emergency call needs clear patient facts, a confirmed location, and a request that someone actually receives. Our project connects these steps through three agents and a hospital-reviewed workflow.',
     'Open with the purpose. Do not read the full title or every logo. Pause after “actually receives.”',
     'First, what makes that connection difficult?',
     'Why does the title say autonomous? The approved title is retained; the current prototype requires staff approval before dispatch notification.',
     'Latest thesis English cover and Sections 1.4–1.5. Logos are the repository originals in MSA → CSE → ENG → Greenwich order.')

# 2 — Problem and aim in one slide to keep the main narrative within the limit.
s = new_slide('Problem definition & aim', 'What happened? Where? Was the request received?', 'Thesis §§1.1–1.2, 1.4; reviewed evidence [1], [2].')
for x,n,title,detail in [
    (.55,'01','Incomplete information','Symptoms arrive gradually.\nEarlier answers can change.'),
    (4.75,'02','Uncertain location','Clarify the address.\nConfirm it with the caller.'),
    (8.95,'03','Unconfirmed delivery','A sent alert does not prove\nthat a receiver accepted it.')]:
    rect(s,x,2.22,3.83,2.26,MINT,stroke=LINE,radius=True)
    text(s,x+.19,2.39,.6,.45,n,size=25,color=GREEN,bold=True)
    text(s,x+.19,3.02,3.43,.43,title,size=25,color=NAVY,bold=True)
    text(s,x+.19,3.64,3.43,.70,detail,size=22)
rect(s,.55,4.93,12.23,1.60,NAVY,radius=True)
text(s,.82,5.10,1.10,.34,'OUR AIM',size=17,color='C4E2B8',bold=True)
text(s,2.15,5.08,10.27,1.33,
     'A hospital-linked telephone prototype to collect patient facts,\nestimate urgency and support staff-approved dispatch\nin English and Egyptian Arabic.',
     size=25,color=WHITE)
note(s,'Omar',65,
     'The problem is the transfer from an incomplete conversation to a request that hospital staff can review. A caller may correct symptoms or an address. The system must update what it knows rather than continue using the old answer. Location is a separate issue: an ordinary telephone call does not automatically give us GPS coordinates. Finally, generating or sending an alert is different from confirming that a receiver accepted it. Our aim is to connect information collection, preliminary urgency, caller-confirmed location, and approved notification in English and Egyptian Arabic. The prototype represents one hospital and uses simulated ambulance resources.',
     'Move left to right across the three cards, then point to the aim. Explain GPS as location coordinates if asked.',
     'We express that aim through four measurable objectives.',
     'Do you diagnose the patient? No. The output is a preliminary urgency recommendation, with reviewed guidance and human escalation.',
     'Thesis Chapter 1. No mortality, real ambulance response-time reduction, or deployed-service claim is made.')

# 3 — Four cards, pairing every original objective exactly once.
s = new_slide('Project objectives', 'Eight thesis objectives combined into four', 'Thesis §1.4. Exact pair mapping is in the speaker notes and rehearsal guide.')
objectives = [
    (.55,2.15,'01','Bilingual voice service','English, Egyptian Arabic and mixed calls.\nTarget a meaningful reply below 1.5 s.','Measure language performance and cost.',[1,8]),
    (6.78,2.15,'02','Reliable incident record','Retain patient facts and corrections.\nRecover calls; reject outdated results.','Measure extraction errors and recovery.',[2,7]),
    (.55,4.48,'03','Triage, guidance & location','Recommend reviewed preliminary urgency.\nRetrieve first aid; confirm the location.','Measure urgency and location errors.',[3,4]),
    (6.78,4.48,'04','Approved dispatch support','Match a simulated ambulance to the case.\nSend approved requests and record receipts.','Measure failures, retries and duplicates.',[5,6]),
]
for x,y,n,title,body,measure,pair in objectives:
    rect(s,x,y,6.0,2.12,WHITE,stroke=LINE,radius=True)
    rect(s,x,y,.065,2.12,GREEN)
    text(s,x+.20,y+.13,.5,.35,n,size=19,color=GREEN,bold=True)
    text(s,x+.82,y+.13,4.95,.40,title,size=25,bold=True)
    text(s,x+.20,y+.69,5.60,.85,body,size=22)
    text(s,x+.20,y+1.66,5.60,.30,measure,size=18,color=DARKGREEN,bold=True)
records[-1]['objective_pairs'] = [row[-1] for row in objectives]
note(s,'Omar',60,
     'We have combined the eight thesis objectives into four without dropping any. First, provide bilingual voice interaction and measure response time, language performance, and service cost. Second, preserve one incident record through corrections, interruptions, and delayed results. Third, combine preliminary triage and reviewed first-aid guidance with caller-confirmed location. Fourth, recommend a suitable simulated ambulance and send only a staff-approved request, with receipts and duplicate prevention. Each objective has an observable test. The 1.5-second value is a design target for the first meaningful audible reply, not a result and not the time to finish the whole report.',
     'Use about 15 seconds per card. Do not read all the supporting text.',
     'Clinical review and realistic requirements will need input from an industrial partner.',
     'Which objectives were combined? 1+8, 2+7, 3+4, and 5+6. Every original objective appears once.',
     'Pairs preserve all eight objectives in thesis §1.4, including cost, noisy/mixed-language testing, interruption recovery, and approved notification.')

# 4 — Outreach is not represented as a secured partnership.
s = new_slide('Industrial partner', 'Current status and the support we need', 'Thesis §1.6. Outreach reported in the thesis; no confirmed partnership is claimed.')
tag(s,.58,2.16,4.45,'NO OFFICIAL PARTNER SECURED',fill=PALE,color=GRAY)
text(s,.58,2.85,5.85,.52,'Reported outreach',size=28,bold=True)
text(s,.58,3.58,5.72,2.15,
     'eHealth  •  Khabeer Group  •  paraMIND\nCleopatra Hospitals Group\nEgyptian Ambulance Organization\nITIDA: project support and sponsorship',size=23)
rect(s,6.92,2.16,5.84,4.33,MINT,stroke=LINE,radius=True)
text(s,7.20,2.44,5.24,.52,'Partner input will support',size=27,bold=True)
for y,label in [(3.32,'Requirements and emergency workflow'),(4.23,'Review of urgency and first-aid material'),(5.14,'An authorized telephone test arrangement')]:
    rect(s,7.23,y,.08,.44,GREEN)
    text(s,7.48,y-.01,4.97,.74,label,size=24)
note(s,'Omar',25,
     'The thesis reports outreach to these organizations, but no official partner has been secured. We need practical requirements, qualified review of urgency and first-aid material, and an authorized test telephone arrangement. Outreach is not evidence of a partnership or access to patient records.',
     'Be precise about status. Do not imply that any listed organization endorses the prototype.',
     'Two of the reviewed studies most directly inform our proposed workflow.',
     'Is a hospital already committed? No official partnership is documented in the current thesis.',
     'Thesis §1.6. ITIDA is outreach for support/sponsorship, not a clinical validation partner.')

# 5 — First of exactly two main literature-review slides.
s = new_slide('Review of literature — DispatchMAS', 'Emergency caller–dispatcher simulation', '[1] Li et al., BMC Emergency Medicine, vol. 26, art. 78, 2026. DOI: 10.1186/s12873-026-01540-9.')
tag(s,.57,2.10,3.15,'PUBLISHED: 2026',size=18)
text(s,4.06,2.14,8.64,.39,'Method: 50 adult records → 100 synthetic calls',size=24,bold=True)
for x,title in [(.57,'Complaint taxonomy'),(4.78,'Caller + dispatcher agents'),(8.99,'Four-physician review')]:
    node(s,x,2.82,3.78,.88,title,title_size=22,fill=MINT,center=True)
arrow(s,4.39,3.25,4.70,3.25)
arrow(s,8.60,3.25,8.91,3.25)
rect(s,.57,4.02,4.02,2.49,NAVY,radius=True)
text(s,.84,4.08,3.48,1.10,'94%',size=60,color=WHITE,bold=True)
text(s,.84,5.29,3.48,1.13,'Correct potential\nauxiliary-agent contact\n— mocked in simulation',size=22,color=WHITE)
text(s,4.99,4.05,7.65,.40,'Limitations',size=26,bold=True)
text(s,4.99,4.65,7.49,1.31,'Synthetic, English-only communication tests.\nOne fixed address; responder contact is mocked.\nTurn pacing is not measured voice-response latency.',size=23)
text(s,4.99,6.04,7.50,.75,'Design lesson: focused questions need real location and receipt tests.',size=21,color=DARKGREEN,bold=True)
note(s,'Omar',60,
     'DispatchMAS is our closest reference for emergency caller–dispatcher conversation. It creates 100 synthetic calls from 50 adult records. A complaint taxonomy and protocol guide caller and dispatcher agents, and four physicians review the simulated interactions. The reported 94 percent concerns contacting the correct potential auxiliary agent within the simulation. It is not a measured delivery rate to a real hospital or ambulance. Its communication experiments are English-only, the address is fixed, and responder contact is mocked. We take the focused-questioning idea, then plan separate tests for varied locations, bilingual telephone input, and receipt at a working test receiver.',
     'Define what the 94% measures before discussing the number. Point to “mocked in simulation.”',
     'TriAgent informs a different part of the design: selecting work when information is incomplete.',
     'Why not use the paper’s 1.8 s as proof of a fast voice agent? It is transcript-derived pacing, not measured speech-to-response latency.',
     'Thesis §2.6; original paper Methods/Results. Supplied PDF identifies publication year 2026 but does not print a publication day/month. The accepted date 11 March 2026 is not substituted for publication date. No exact day is inferred from PDF creation metadata.')

# 6 — Same method/result/limitation structure for a fair comparison.
s = new_slide('Review of literature — TriAgent', 'Clinical decision support under incomplete information', '[2] Ibrahim et al., AI, vol. 7, art. 230, published 18 June 2026. DOI: 10.3390/ai7060230.')
tag(s,.57,2.10,4.13,'PUBLISHED: 18 JUNE 2026',size=18)
text(s,5.05,2.14,7.68,.39,'Method: retrospective study of 1,000 cases',size=24,bold=True)
for x,title in [(.57,'Adaptive orchestration'),(4.78,'Retrieval + classifier'),(8.99,'Safety checks + critique')]:
    node(s,x,2.82,3.78,.88,title,title_size=22,fill=MINT,center=True)
arrow(s,4.39,3.25,4.70,3.25)
arrow(s,8.60,3.25,8.91,3.25)
rect(s,.57,4.02,4.02,2.49,NAVY,radius=True)
text(s,.82,4.10,3.53,.74,'65.7%',size=42,color=WHITE,bold=True)
text(s,.85,4.88,3.48,.35,'Overall urgency accuracy',size=20,color=WHITE)
text(s,.82,5.30,3.53,.74,'85.0%',size=42,color=WHITE,bold=True)
text(s,.85,6.08,3.48,.35,'Critical-case recall',size=20,color=WHITE)
text(s,4.99,4.05,7.65,.40,'Limitations',size=26,bold=True)
text(s,4.99,4.65,7.49,1.31,'Structured clinical inputs and a trained triage classifier.\nMedian case runtime: 64 s bypass / 186 s continuation.\nNo live telephone or ambulance-receiver evaluation.',size=23)
text(s,4.99,6.04,7.50,.75,'Design lesson: selective tasks and traceable review; assess latency separately.',size=21,color=DARKGREEN,bold=True)
note(s,'Omar',65,
     'TriAgent was published on 18 June 2026. It adaptively selects clinical tasks, retrieves related cases, applies safety checks, and records a critique. On 1,000 retrospective cases it reports 65.7 percent overall urgency accuracy and 85 percent critical-case recall. Those outcomes use structured clinical information and a separately trained triage classifier. The improvement cannot be attributed to agent count alone, and the same accuracy cannot be promised for a telephone symptom report. Its median runtimes are 64 seconds for the bypass and 186 seconds for the continuation path. We adopt selective task execution and reviewability, while measuring spoken-reply latency separately. Abdelrahman will now show our narrower three-agent design.',
     'Keep the two percentages tied to their own labels. Pause before the limitations. Handoff to Abdelrahman.',
     'These studies motivate focused conversation, selective tasks, and a visible staff-review step.',
     'Is TriAgent the same three-agent arrangement as ours? No. It includes an orchestrator, specialist modules, critique, and a trained classifier. Our controller is ordinary Python software.',
     'Thesis §2.7; original paper first page gives publication date. Structured inputs, trained classifier, and case runtimes are study-specific. No project performance or single-agent baseline implementation is claimed.')

# 7 — Native editable block diagram; arrows to each agent show controller routing.
s = new_slide('Proposed system — block diagram', 'Three large language model (LLM) agents + a Python software controller', 'Simplified from thesis §§3.1–3.1.2. Proposed design; fleet resources are simulated.')
node(s,.55,2.47,1.99,2.17,'Caller', 'Telephone\n↕\nSpeech tools',fill=PALE,title_size=24,detail_size=23,center=True)
agents = [(2.98,'Agent 1','Conversation','Collect facts.\nPreserve corrections.\nSpeak to the caller.'),
          (6.29,'Agent 2','Triage & guidance','Red / Yellow / Green.\nRetrieve reviewed\nfirst-aid instructions.'),
          (9.60,'Agent 3','Coordination','Confirm location.\nMatch a vehicle.\nDraft the report.')]
for x,label,title,detail in agents:
    rect(s,x,2.27,3.17,2.38,MINT,stroke=NAVY,radius=True)
    text(s,x+.16,2.42,2.85,.32,label.upper(),size=17,color=DARKGREEN,bold=True)
    text(s,x+.16,2.91,2.85,.43,title,size=24,bold=True)
    text(s,x+.16,3.45,2.85,.95,detail,size=20)
arrow(s,2.57,3.35,2.91,3.35,both=True)
rect(s,2.98,4.91,9.79,.78,NAVY,radius=True)
text(s,3.17,5.05,9.4,.47,'Python controller  |  task routing  |  update checks  |  incident record',size=21,color=WHITE,bold=True)
for x in [4.57,7.88,11.18]:arrow(s,x,4.85,x,4.71,both=True)
node(s,.55,5.04,1.99,1.45,'Takeover','Staff at any\nstage',title_size=21,detail_size=19,fill=WHITE,center=True)
node(s,2.98,6.03,2.90,.60,'Current incident',title_size=21,fill=WHITE,center=True)
node(s,6.42,6.03,2.90,.60,'Staff approval',title_size=21,fill=MINT,center=True)
node(s,9.86,6.03,2.90,.60,'Receiver + receipt',title_size=21,fill=WHITE,center=True)
arrow(s,5.92,6.33,6.34,6.33)
arrow(s,9.36,6.33,9.79,6.33)
arrow(s,4.43,5.73,4.43,5.97)
note(s,'Abdelrahman',90,
     'The caller enters through the hospital test telephone connection and speech services. Agent 1 is the only agent that speaks. It gathers facts and corrections. Agent 2 uses the current facts to recommend preliminary urgency and retrieve reviewed first-aid material. Agent 3 confirms location, checks simulated vehicle availability, estimated travel time and equipment, and prepares the report. The Python controller is not a fourth AI agent. It decides which task needs to run, validates results, and maintains one incident record. A result based on an old address must not overwrite a correction. The controller does not invoke every agent after every utterance. Staff can inspect partial information, take over the call, and approve or reject the request. Only an approved request reaches the test receiver. The receipt is logged separately from simulated assignment or departure. The diagram is simplified for the slide; the thesis contains the fuller block diagram and flowchart.',
     'Trace the caller-to-Agent-1 arrow, then each role, then the controller bar, then the bottom approval path. Do not present the three agents as a forced sequential chain.',
     'The flowchart shows what happens when information is missing or a delivery fails.',
     'Could all agents use the same model? Yes, different roles can use separate instructions with the same underlying model. Final model/tool selection remains detailed-design work.',
     'Thesis §§3.1–3.1.2. Numbered agents are roles; speech, maps, storage, and retrieval are services. No actual live ambulance control is shown.')

# 8 — Flowchart with explicit approval and recovery rather than a success-only path.
s = new_slide('Proposed system — call flow', 'Corrections and failed deliveries remain visible', 'Simplified from the thesis two-part flowchart, §3.1.2. Retry limit is proposed.')
node(s,.60,2.22,3.67,1.55,'1  Collect & clarify','Symptoms, callback, corrections',fill=MINT,title_size=24,detail_size=21)
node(s,4.83,2.22,3.67,1.55,'2  Assess & guide','Preliminary urgency; reviewed guidance',fill=MINT,title_size=24,detail_size=21)
node(s,9.06,2.22,3.67,1.55,'3  Confirm & match','Location and simulated resources',fill=MINT,title_size=24,detail_size=21)
arrow(s,4.31,3.00,4.75,3.00)
arrow(s,8.54,3.00,8.98,3.00)
arrow(s,10.89,3.83,10.89,4.04)
node(s,9.06,4.14,3.67,1.55,'4  Staff review','Approve, reject, or request clarification',fill=WHITE,title_size=24,detail_size=21)
node(s,4.83,4.14,3.67,1.55,'5  Notify receiver','Approved request; up to 3 attempts',fill=WHITE,title_size=24,detail_size=21)
node(s,.60,4.14,3.67,1.55,'6  Record outcome','Receipt, or failed/unconfirmed alert',fill=WHITE,title_size=24,detail_size=21)
arrow(s,8.99,4.92,8.58,4.92)
text(s,8.37,3.80,.74,.27,'Approve',size=15,color=DARKGREEN,bold=True)
arrow(s,4.75,4.92,4.34,4.92)
rect(s,.60,5.91,12.13,.65,NAVY,radius=True)
text(s,.82,6.04,11.69,.35,'Correction or rejection → update the record → repeat the affected task',size=24,color=WHITE,align=PP_ALIGN.CENTER)
note(s,'Abdelrahman',60,
     'The main path is collection, preliminary assessment, location and resource confirmation, and staff review. If staff approve, the controller sends the request to the test receiver. Failed delivery uses a proposed maximum of three attempts, with the same request identifier so that a retry cannot become a second order. A missing receipt produces a failed or unconfirmed state and an alert to staff. It is not silently treated as success. If the caller corrects a symptom or location, or staff reject the report, we update the incident and repeat only the affected task. Human takeover remains available throughout the call.',
     'Follow the top row left-to-right, then the lower row right-to-left. Point to the correction bar last.',
     'These steps give us measurable system specifications.',
     'Does a receipt mean an ambulance departed? No. Approval, sending, receipt, simulated assignment, and departure are separate events.',
     'Thesis functional requirements and flowchart. “Up to 3 attempts” is proposed, not a measured reliability result.')

# 9 — Clearly distinguish targets from results.
s = new_slide('System specifications', 'Design targets and scope — not measured prototype results', 'Thesis §3.1: functional and non-functional requirements.')
specs=[(.58,2.20,'< 1.5 s','First meaningful audible reply','Report median and p95 delay.'),
       (6.80,2.20,'3 language conditions','English • Egyptian Arabic • mixed','Report each condition separately.'),
       (.58,4.44,'1 hospital','Test telephone line + simulated fleet','A working, authorized test receiver.'),
       (6.80,4.44,'Up to 3 attempts','Proposed notification retry limit','Same request ID; staff alert on failure.')]
for x,y,big,label,small in specs:
    rect(s,x,y,5.96,2.04,WHITE,stroke=LINE,radius=True)
    text(s,x+.20,y+.14,5.56,.55,big,size=31,color=GREEN,bold=True)
    text(s,x+.20,y+.85,5.56,.46,label,size=23,bold=True)
    text(s,x+.20,y+1.49,5.56,.34,small,size=20,color=GRAY)
note(s,'Abdelrahman',40,
     'These are targets and boundaries. The 1.5-second value is the first meaningful audible response after a caller finishes a turn. A filler acknowledgment does not qualify. English, Egyptian Arabic, and mixed-language calls will be measured separately. The prototype represents one hospital and uses simulated ambulance resources. The proposed notification limit is three attempts with duplicate prevention. Urgency labels and first-aid content still require qualified review.',
     'Say “target” before the latency value. Expand p95 as the 95th percentile.',
     'Our contribution is how these requirements connect into one workflow.',
     'Is a full incident report also due within 1.5 seconds? No. Spoken reply, report preparation, and notification have separate clocks.',
     'Thesis §3.1. Proposed prototype constraints are not achieved measurements.')

# 10 — Compare capabilities, not incompatible accuracy figures.
s = new_slide('Contributions & uniqueness', 'The contribution is the connected workflow', 'Thesis §§1.3, 1.5 and Chapter 2 summary; [1], [2]. “Planned” is not an achieved capability.')
cols=[.58,3.25,6.67,9.66,12.76]
heads=['System','Call input','Location','Notification']
for j in range(4):
    rect(s,cols[j],2.20,cols[j+1]-cols[j],.55,NAVY)
    text(s,cols[j]+.13,2.30,cols[j+1]-cols[j]-.24,.36,heads[j],size=22,color=WHITE,bold=True)
rows=[['DispatchMAS [1]','Synthetic English\ndialogues','Fixed address','Mocked contact'],
      ['TriAgent [2]','Clinical narratives\n+ structured inputs','Not evaluated','No receiver trial'],
      ['Our prototype\nPLANNED','Bilingual\ntelephone calls','Caller-confirmed\nlocation','Staff approval\n+ receiver receipt']]
for i,row in enumerate(rows):
    y=2.75+i*.92
    for j,value in enumerate(row):
        rect(s,cols[j],y,cols[j+1]-cols[j],.92,MINT if i==2 else WHITE,stroke=LINE,line_width=.6)
        text(s,cols[j]+.13,y+.14,cols[j+1]-cols[j]-.25,.70,value,size=22,bold=(j==0),color=DARKGREEN if i==2 else INK)
rect(s,.58,5.89,12.18,.65,NAVY,radius=True)
text(s,.83,6.03,11.68,.36,'Preserve corrections  •  show unresolved details  •  verify delivery',size=25,color=WHITE,align=PP_ALIGN.CENTER)
note(s,'Abdelrahman',45,
     'We compare capabilities rather than ranking incompatible accuracy percentages. DispatchMAS evaluates synthetic conversation with a fixed address and mocked contact. TriAgent evaluates clinical information and escalation logic, without a telephone or receiver trial. Our anticipated contribution is the connection between bilingual telephone intake, corrections, confirmed location, a suitable simulated resource, and approved notification with a receipt. Every entry in our row is planned. We are not proposing a new language model or clinical triage standard, and we are not claiming that no other system has ever combined similar functions.',
     'Read across one study row, then the planned row. Emphasize the word “planned.”',
     'We will test that contribution through the following measurements.',
     'How will you prove three agents beat one? That is not a committed project claim. The thesis specifies component/integration testing; paper comparisons give context, not a promised implemented single-agent baseline.',
     'Thesis comparison table and summary, with original study limitations retained.')

# 11 — Six outcomes with a three-level test strategy.
s = new_slide('Proposed testing procedures', 'Component checks → integration tests → simulated calls', 'Thesis §3.1 and Chapter 5. Scenarios and urgency reference labels require qualified review.')
tests=[('Information','Correct facts, omissions, corrections'),('Urgency','Confusion matrix; missed urgent cases'),
       ('Location','Correct confirmation; unsupported matches'),('Response time','Median and p95 meaningful-reply delay'),
       ('Notifications','Receipts, failures and duplicate requests'),('Operating cost','Service use for successful and failed calls')]
for i,(title,detail) in enumerate(tests):
    col,row=i%2,i//2;x=.58+col*6.22;y=2.15+row*1.27
    rect(s,x,y,5.97,1.08,WHITE,stroke=LINE,radius=True)
    text(s,x+.17,y+.12,5.63,.35,title,size=24,color=NAVY,bold=True)
    text(s,x+.17,y+.61,5.63,.34,detail,size=21)
tag(s,.60,6.22,12.13,'Stress cases: noisy speech • corrected addresses • interrupted calls • late receipts',size=20)
note(s,'Abdelrahman',65,
     'Testing starts with individual components, then connected services, then full simulated emergency calls. Annotated scenarios provide the facts we expect to collect. A qualified reviewer must agree urgency labels and guidance before testing. We will measure information errors, urgency errors, location confirmation, meaningful-reply delay, notification outcomes, and cost. We will separate transcript interpretation from end-to-end speech tests, so we can identify whether an error came from recognition or reasoning. Tests include noise, code-switching, corrected addresses, unavailable vehicles, call interruptions, and delayed or duplicate receipts. A failure is an outcome to record and explain. No clinical effectiveness or real ambulance deployment is established by these prototype tests.',
     'Describe the test strategy first, then highlight two measures rather than reading six cards.',
     'Cost is part of the evaluation, but service prices have not yet been selected.',
     'Who supplies ground truth? Reviewed scenario annotations, urgency reference labels, and simulated resource constraints; not unreviewed model self-grading.',
     'Thesis proposed evaluation. No dataset size, clinical target accuracy, or completed test result is invented.')

# 12 — Cost planning is honestly shown as pending, matching thesis Chapter 5.
s = new_slide('Cost analysis — planned method', 'Detailed pricing follows service and component selection', 'Thesis §3.1 operating-cost requirement and Chapter 5 next steps.')
text(s,.60,2.18,12.0,.55,'Measure cost per completed call — and per failed call',size=29,bold=True)
drivers=[(.60,'Telephone','Call duration'),(3.73,'Speech','Audio input + spoken output'),(6.86,'Models','Model and retrieval usage'),(9.99,'Other services','Maps, storage, notifications')]
for x,title,detail in drivers:
    rect(s,x,3.05,2.74,1.97,MINT,stroke=LINE,radius=True)
    text(s,x+.16,3.26,2.42,.49,title,size=25,bold=True)
    text(s,x+.16,4.01,2.42,.85,detail,size=22)
rect(s,.60,5.48,12.13,.84,WHITE,stroke=LINE,radius=True)
text(s,.84,5.68,11.65,.45,'Rates and prototype total: pending selection. No budget or savings figure is claimed.',size=24,color=GRAY)
note(s,'Abdelrahman',30,
     'Detailed costing follows service selection. We will log telephone time, speech processing, model usage, mapping, storage and notification attempts, including failures. This supports a cost per completed or failed call. No service rates or prototype total are agreed yet, and the reviewed papers do not provide directly comparable per-call costs.',
     'Explain the cost drivers. Do not invent dollar values to fill the template.',
     'The remaining design work is scheduled against the confirmed submission date.',
     'Where is the numerical budget? It is pending service selection in the planned detailed design; this midterm reports the costing method.',
     'Thesis Chapter 5 explicitly lists cost analysis as next work. The slide adapts the template’s Cost Analysis topic to the current documented stage.')

# 13 — Wide editable Gantt, faithfully grouping the original 11 tasks.
s = new_slide('Timetable — remaining Grad I work', 'Proposed leads and dates; confirmed submission: 17 January 2027', 'Thesis Chapter 4. Grouped for presentation; internal dates and responsibilities are proposed.')
x0=5.13;cw=.94
for j,label in enumerate(['23 Nov','30 Nov','7 Dec','14 Dec','21 Dec','28 Dec','4 Jan','11 Jan']):
    text(s,x0+j*cw,2.15,cw,.31,label,size=16,color=NAVY,bold=True,align=PP_ALIGN.CENTER)
    rect(s,x0+j*cw,2.57,cw-.025,3.45,WHITE if j%2==0 else PALE)
text(s,.60,2.15,3.20,.31,'Task',size=16,color=NAVY,bold=True)
text(s,3.83,2.15,1.14,.31,'Lead',size=16,color=NAVY,bold=True)
tasks=[('Scope & requirements','Both',0,1),('Guidance + voice plan','Both',1,2),
       ('Controller interfaces','Omar',3,1),('Location + dashboard','Both',4,1),
       ('Safety, cost + test plan','Both',5,1),('Review + submission','Both',6,2)]
for i,(label,lead,start,duration) in enumerate(tasks):
    y=2.65+i*.53
    text(s,.60,y,3.20,.34,label,size=20,bold=True)
    text(s,3.83,y+.025,1.14,.34,lead,size=17,color=GRAY)
    rect(s,x0+start*cw+.06,y+.07,duration*cw-.15,.28,GREEN if i%2==0 else DARKGREEN,radius=True)
    if i<5:
        endx=x0+(start+duration)*cw-.08
        nextx=x0+tasks[i+1][2]*cw+.06
        arrow(s,endx,y+.35,nextx,y+.59,color=GRAY,width=.8)
text(s,.60,5.95,4.37,.32,'Report and decision log: continuous',size=18,color=GRAY)
rect(s,x0+.06,6.06,8*cw-.15,.12,NAVY)
text(s,.60,6.30,8.10,.28,'Omar: guidance, controller, location, scenarios',size=16,color=DARKGREEN,bold=True)
text(s,.60,6.59,8.10,.28,'Abdelrahman: telephone, dashboard, privacy and cost',size=16,color=DARKGREEN,bold=True)
text(s,8.72,6.42,4.04,.42,'14–16 Jan: correction buffer',size=18,color=DARKGREEN,bold=True,align=PP_ALIGN.RIGHT)
milestone=s.shapes.add_shape(MSO_SHAPE.DIAMOND,Inches(12.46),Inches(5.41),Inches(.20),Inches(.20))
milestone.fill.solid();milestone.fill.fore_color.rgb=rgb(DARKGREEN);milestone.line.fill.background()
text(s,11.62,5.72,1.12,.25,'17 Jan',size=14,color=DARKGREEN,bold=True,align=PP_ALIGN.RIGHT)
note(s,'Abdelrahman',60,
     'The thesis plan runs from 23 November to the confirmed 17 January Grad I deadline. These are proposed dates and leads, not claims that every task has been completed. The review and preliminary design already exist in the thesis. Omar leads guidance and bilingual scenarios, then controller interfaces and location rules. Abdelrahman leads telephone feasibility, dashboard and receiver design, and privacy and costing. Both contribute to integration review and submission. The chart groups parallel tasks for readability; the thesis retains all eleven tasks and their dependencies. Report work continues throughout, with a 14–16 January correction buffer. Omar will finish with the main challenges and next steps.',
     'Point to the deadline, two parallel work periods, and the final buffer. Handoff back to Omar.',
     'The plan also depends on resolving several technical and clinical constraints.',
     'Does 17 January mean a clinically validated deployed service? No. It is the confirmed Grad I submission deadline for the scheduled work.',
     'Thesis Chapter 4 and time-plan-tasks.json. Source task groups: T1; T2+T3; T4; T5+T6; T7+T8; T9+T10; T11 ongoing. No T-codes appear on the slide.')

# 14 — Planned responses, not claims that problems have already been solved.
s = new_slide('Limitations & challenges', 'Planned controls for the prototype’s main failure cases', 'Thesis §§3.1–3.1.2 and Chapter 5. Qualified review and authorized test access remain prerequisites.')
for x,w,label in [(.60,4.14,'Challenge'),(4.74,8.0,'Planned response')]:
    rect(s,x,2.20,w,.57,NAVY)
    text(s,x+.17,2.31,w-.34,.35,label,size=23,color=WHITE,bold=True)
for i,(challenge,response) in enumerate([
    ('Noisy or mixed-language speech','Separate speech-recognition errors from\nerrors in interpreting a correct transcript.'),
    ('Missing symptoms or location','Ask focused questions; preserve unknowns;\nallow staff takeover.'),
    ('Service failures or outdated results','Reject stale results; limit retries;\nprevent duplicate dispatch requests.')]):
    y=2.77+i*1.02
    rect(s,.60,y,4.14,1.02,MINT,stroke=LINE)
    rect(s,4.74,y,8.0,1.02,WHITE,stroke=LINE)
    text(s,.79,y+.19,3.76,.76,challenge,size=24,bold=True)
    text(s,4.94,y+.16,7.60,.80,response,size=24)
tag(s,.60,6.25,12.13,'Before hospital testing: authorization • reviewed urgency labels • reviewed first-aid sources',size=19)
note(s,'Omar',45,
     'The main risks are misunderstandings in noisy or mixed-language speech, missing facts or an uncertain location, and failures across connected services. The proposed controls are separate speech-versus-interpretation tests, focused clarification, explicit unknown fields, and access to staff. For late or failed service results, the controller checks whether the incident has changed and manages bounded retries with one request identifier. These are design requirements to implement and verify. Before a hospital demonstration, the team still needs authorization and qualified review of urgency criteria, first-aid sources, and test scenarios.',
     'Use “planned response” and “will test”; do not say the prototype has already solved these problems.',
     'Our conclusion is therefore about progress, the proposed approach, and the next steps.',
     'Is the prototype ready for unsupervised emergencies? No. The documented scope is authorized simulation and staff review.',
     'Thesis requirements and initial conclusion; international guidance does not establish local legal compliance.')

# 15 — Mirrors the thesis's three conclusion paragraphs.
s = new_slide('Conclusion', 'Progress so far • proposed approach • next steps', 'Thesis Chapter 5. Prototype performance and clinical benefit have not yet been established.')
for x,title,body in [
    (.60,'Progress so far','Problem and gap defined.\nSix studies reviewed.\nPreliminary design prepared.'),
    (4.80,'Proposed approach','Three agents + controller.\nOne incident record.\nStaff-approved notifications.'),
    (9.00,'Next steps','Detail the design.\nReview guidance and costs.\nBuild and evaluate.')]:
    rect(s,x,2.22,3.73,2.77,MINT,stroke=LINE,radius=True)
    text(s,x+.18,2.46,3.37,.48,title,size=27,bold=True)
    text(s,x+.18,3.18,3.37,1.57,body,size=23)
rect(s,.60,5.49,12.13,.95,NAVY,radius=True)
text(s,.88,5.71,11.57,.58,'From an emergency call to a reviewable, acknowledged request.',size=29,color=WHITE,align=PP_ALIGN.CENTER)
note(s,'Omar',35,
     'We have defined the problem, reviewed six studies, and prepared requirements and preliminary diagrams. Our proposed approach connects three agents, a Python controller, and staff approval. Next come detailed design, tool selection, clinical review, costing, implementation, and simulated-call evaluation. The contribution is a reviewable path from call to acknowledged request. Thank you; we welcome your questions.',
     'Return to the opening purpose. Stop the prepared narrative at or before 12:45.',
     'Questions and discussion.',
     'What have you actually completed? Research review and preliminary design/documentation; implementation and evaluation are future work.',
     'Thesis Chapter 5, preserving its three-part structure without fabricated results.')

# 16 — Reserved within the 15-minute ceiling, not an extra presentation segment.
s = new_slide('Questions & discussion', 'Thank you', '')
text(s,.85,2.54,11.63,.83,'Three agents. One reviewable emergency-call workflow.',size=34,color=NAVY,align=PP_ALIGN.CENTER)
for x,title,detail in [(.85,'Safety','Human review and approval'),(5.05,'Architecture','Why three agents and a controller?'),(9.25,'Evaluation','What counts as a successful call?')]:
    node(s,x,4.04,3.23,1.63,title,detail,fill=MINT,title_size=26,detail_size=23,center=True)
text(s,.85,6.34,11.63,.34,'Backup slides: standards • metric definitions • controller decisions • references',size=19,color=GRAY,align=PP_ALIGN.CENTER)
note(s,'Both',135,
     'This slide starts the question period. The planned talk ends at 12:45, leaving 2:15 inside the 15-minute maximum. Keep answers focused and use a backup slide only when it helps. If questions are handled separately by the committee, the prepared talk still remains below the limit.',
     'Listen fully. Let the presenter responsible for a topic answer first, then add only missing information. State uncertainty honestly.',
     '',
     'Useful backups: 17 guidance; 18 evaluation definitions; 19 controller and role choice; 20 sources/publication status.',
     'Both presentation rubrics emphasize understanding, concise answers, confidence, and audience engagement. Suggested speaking assignments are editable.')

# 17–20 — Backup, not part of the timed prepared narrative.
s = new_slide('Industrial standards', 'Backup: guidance applied to the proposed requirements', 'Thesis §§2.8 and 3.1.1. Names retained as design guidance; no standards bibliography citations.',backup=True)
rows=[('NIST AI RMF 1.0','Risk records, review responsibilities and failure tests.'),
      ('NIST AI 600-1','Check invented facts, unsupported advice and summaries.'),
      ('WHO health-AI guidance','Medical review, human oversight and language fairness.'),
      ('W3C WebRTC 1.0','Browser media connections in the proposed LiveKit path.'),
      ('NIST Privacy Framework 1.0','Minimize data; define access, consent and retention.')]
rect(s,.60,2.19,4.20,.52,NAVY);rect(s,4.80,2.19,7.93,.52,NAVY)
text(s,.79,2.28,3.82,.34,'Standard',size=23,color=WHITE,bold=True)
text(s,5.00,2.28,7.53,.34,'Use in the proposed design',size=23,color=WHITE,bold=True)
for i,(a,b) in enumerate(rows):
    y=2.71+i*.65
    rect(s,.60,y,4.20,.65,MINT,stroke=LINE)
    rect(s,4.80,y,7.93,.65,WHITE,stroke=LINE)
    text(s,.79,y+.14,3.82,.43,a,size=22,bold=True)
    text(s,5.00,y+.14,7.53,.43,b,size=22)
text(s,.65,6.29,12.0,.36,'These frameworks, guidance and specifications do not establish certification or legal compliance.',size=20,color=GRAY)
note(s,'Both',0,'Use only if asked about industrial standards, ethics, privacy, or professional context.',
     'Web Audio API is intentionally excluded; the thesis keeps WebRTC because the proposal names it.',
     qa='Why these references? They come from the guide’s AI-track or shared personal-data entries and map to actual design decisions.',
     sources='Current thesis standards sections; no numeric standards citations or standards bibliography entries, following the user’s requested format.')

s = new_slide('Evaluation definitions', 'Backup: measure different outcomes with different clocks', 'Thesis objectives and §3.1. Design target <1.5 s applies to meaningful spoken reply.',backup=True)
defs=[('Spoken reply delay','End of caller turn → first meaningful audible reply.'),
      ('Report preparation','Time to a staff-reviewable incident report.'),
      ('Notification delivery','Approved sending → receiver confirmation.'),
      ('Urgency performance','Reviewed labels; confusion matrix and missed urgent cases.'),
      ('Reliability','Interrupted calls, delayed results, failures and duplicate count.')]
for i,(a,b) in enumerate(defs):
    y=2.16+i*.77
    node(s,.60,y,12.13,.64,a,title_size=22,fill=MINT if i%2==0 else WHITE)
    text(s,4.12,y+.14,8.35,.40,b,size=22)
tag(s,.60,6.31,12.13,'A receiver receipt is not evidence of ambulance departure.',size=22)
note(s,'Both',0,'Use to clarify latency, accuracy, and delivery outcomes.',
     'Do not compare DispatchMAS transcript pacing or TriAgent case runtimes directly with our spoken-reply target.',
     qa='Are paper accuracies the benchmark target? They provide context under different labels, inputs and datasets. We will evaluate against reviewed prototype scenarios.',
     sources='Thesis §§1.2–1.4, §3.1 and Chapter 2 summary.')

s = new_slide('Why three agents and a software controller?', 'Backup: roles separate responsibilities; software enforces state and approval', 'Thesis §§1.5 and 3.1. More agents are not assumed to improve every metric.',backup=True)
node(s,.60,2.22,5.86,3.32,'Agent roles',
     'Conversation: speak and collect facts.\nTriage: urgency and reviewed guidance.\nCoordination: location, resources and report.',fill=MINT,title_size=28,detail_size=24)
node(s,6.88,2.22,5.86,3.32,'Python controller',
     'Keep one incident record.\nRun only affected tasks.\nReject outdated results.\nEnforce approval, retries and request IDs.',fill=WHITE,title_size=28,detail_size=24)
tag(s,.60,6.04,12.13,'The same underlying model may serve multiple roles. Final model selection is still planned.',size=21)
note(s,'Both',0,'Use when asked about the agent count, model choices, context, or controller design.',
     'Explain one corrected-address example: a late lookup using the old update must not overwrite the confirmed new address.',
     qa='Is the controller another AI agent? No. It is ordinary Python software. Is a single-agent comparison mandatory? The current committed evaluation does not include an implemented single-agent baseline; no agent-count superiority is claimed.',
     sources='Thesis §§1.4–1.5 and §3.1. Tool choices in the proposal remain preliminary.')

s = new_slide('References & publication status', 'Backup: sources for the two literature slides', 'Research citations use IEEE numeric style. Full research bibliography remains in the thesis.',backup=True)
text(s,.62,2.17,12.05,1.43,
     '[1] X. Li et al., “DispatchMAS: Fusing taxonomy and artificial intelligence agents for emergency medical services,” BMC Emergency Medicine, vol. 26, art. 78, 2026.\nDOI: 10.1186/s12873-026-01540-9',size=23)
text(s,.62,4.04,12.05,1.54,
     '[2] A. Ibrahim, A. AlSanousi, and A. Serag, “TriAgent: An adaptive multi-agent architecture for crisis clinical decision support under incomplete information,” AI, vol. 7, art. 230, 18 June 2026.\nDOI: 10.3390/ai7060230',size=23)
tag(s,.62,6.20,12.05,'Project publication status: no project publication is reported in the current thesis.',size=20)
note(s,'Both',0,'Reference slide and publication-status disclosure; do not narrate unless asked.',
     'The two cited papers are reviewed prior work, not publications by the project team.',
     qa='Why only two papers on the slides? Six are reviewed in the thesis. These two directly support emergency-call simulation and controlled work under incomplete information, allowing depth within 15 minutes.',
     sources='Original supplied paper PDFs and thesis §§2.6–2.7. DispatchMAS publication year is verified; the supplied PDF does not print publication day/month. TriAgent prints Published: 18 June 2026.')


# A manual presentation, with rehearsed timing in notes, not forced auto-advance.
elapsed = 0
for rec,slide in zip(records,prs.slides):
    if not rec['backup']:
        rec['start_seconds']=elapsed
        elapsed += rec['seconds']
        rec['end_seconds']=elapsed
    for shape in slide.shapes:
        if shape.has_text_frame:
            for p in shape.text_frame.paragraphs:
                pPr=p._p.get_or_add_pPr()
                pPr.set('rtl','0')
    # Skip backup slides in an ordinary slide show; they remain available for Q&A.
    slide._element.set('show','0' if rec['backup'] else '1')
assert elapsed == 900
assert sum(r['seconds'] for r in records[:15]) == 765
assert sorted(n for pair in records[2]['objective_pairs'] for n in pair)==list(range(1,9))
prs.core_properties.title='Agentic Emergency Tele-Triage & Autonomous Medical Dispatch System — Midterm'
prs.core_properties.subject='Graduation Project I presentation based on the current thesis and both supplied rubrics'
prs.core_properties.author='Omar Mostafa Omar; Abdelrahman Mahmoud Ali'
prs.core_properties.keywords='Midterm; MSA; three agents; staff-approved dispatch; proposed prototype'
prs.core_properties.comments='Uploaded template masters retained; main narrative 12:45; Q&A 2:15; four labelled backup slides.'
prs.core_properties.created=datetime(2026,11,24,12,0,tzinfo=timezone.utc)
prs.core_properties.modified=datetime(2026,11,24,12,0,tzinfo=timezone.utc)
target=OUT/'Uni-Grad - Midterm Presentation.pptx'
prs.save(target)
(ROOT/'slide-content-and-notes.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
print('Saved',target)
print('Slides:',len(records),'main including Q&A:',16,'backup:',4)
print('Prepared narrative: 12:45; reserved Q&A: 2:15; total:',elapsed,'seconds')
print('Suggested speaking:',{speaker:sum(r['seconds'] for r in records[:15] if r['speaker']==speaker) for speaker in ['Omar','Abdelrahman']})
