"""Build the midterm deck on the uploaded template's original masters/layouts.

All diagrams/charts are native PowerPoint shapes. Logo bytes are unchanged;
PowerPoint crop properties remove transparent margins. No thesis claims of
completed implementation or measured prototype performance are introduced.
"""
from pathlib import Path
from datetime import datetime, timezone
from copy import deepcopy
import json
import math
import zipfile
from PIL import Image, ImageFont
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.oxml.xmlchemy import OxmlElement
from animation_tools import add_click_fades

ROOT = Path(__file__).parent
TEMPLATE = ROOT / 'inputs/Presentation_Template.pptx'
LOGOS = ROOT / 'inputs/Logos'
OUT = ROOT / 'output'
OUT.mkdir(exist_ok=True)
NAVY = '062B49'
INK = '102346'
GREEN = '549848'  # Sampled from the original template's green ribbon.
DARKGREEN = '3D6B32'
MINT = 'F1F7EE'
GRAY = '566672'
LINE = 'D5DFD2'
WHITE = 'FFFFFF'
PALE = 'F5F7F8'
GOLD = 'B58C55'
FONT = 'Calibri'
DISPLAY = 'Calibri Light'
prs = Presentation(TEMPLATE)
cover_layout = prs.slides[0].slide_layout
body_layout = prs.slides[2].slide_layout
for slide_id in list(prs.slides._sldIdLst):
    prs.part.drop_rel(slide_id.rId)
    prs.slides._sldIdLst.remove(slide_id)
SW, SH = prs.slide_width / 914400, prs.slide_height / 914400
records = []
MAIN_SLIDE_COUNT = 17


def rgb(value):
    return RGBColor.from_string(value)


def rect(slide, x, y, w, h, fill=WHITE, stroke=None, radius=False, line_width=.9):
    kind = MSO_SHAPE.ROUNDED_RECTANGLE if radius else MSO_SHAPE.RECTANGLE
    shape = slide.shapes.add_shape(kind, Inches(x), Inches(y), Inches(w), Inches(h))
    if radius:
        shape.adjustments[0] = .08
    shape.fill.solid()
    shape.fill.fore_color.rgb = rgb(fill)
    if stroke:
        shape.line.color.rgb = rgb(stroke)
        shape.line.width = Pt(line_width)
    else:
        shape.line.fill.background()
    return shape


def text(slide, x, y, w, h, value, size=24, color=INK, bold=False,
         align=PP_ALIGN.LEFT, valign=MSO_ANCHOR.TOP, font=FONT):
    # Reserve the font's full line box, not just nominal point size. This keeps
    # ascenders/descenders inside the editable text frame in Office and Impress.
    metric_font=ImageFont.truetype(str(ROOT/'fonts'/('Carlito-Bold.ttf' if bold else 'Carlito-Regular.ttf')),round(size*10))
    line_count=0
    for paragraph in value.split('\n'):
        lines=['']
        for word in paragraph.split(' '):
            candidate=(lines[-1]+' '+word).strip()
            if metric_font.getlength(candidate)/10>w*72 and lines[-1]:
                lines.append(word)
            else:
                lines[-1]=candidate
        line_count+=len(lines)
    h=max(h,(line_count*size*1.28+2)/72)
    box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = box.text_frame
    tf.clear()
    tf.word_wrap = True
    tf.margin_left = tf.margin_right = 0
    tf.margin_top = tf.margin_bottom = 0
    tf.vertical_anchor = valign
    for i, line in enumerate(value.split('\n')):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.text = line
        p.alignment = align
        p.space_before = Pt(0)
        p.space_after = Pt(0)
        p.line_spacing = 1.06
        p.font.name = font
        p.font.size = Pt(size)
        p.font.bold = bold
        p.font.color.rgb = rgb(color)
    return box


def tag(slide, x, y, w, label, fill=MINT, color=DARKGREEN, size=17):
    rect(slide, x, y, w, .38, fill)
    text(slide, x + .09, y + .035, w - .18, .33, label, size=size, color=color, bold=True)


def arrow(slide, x1, y1, x2, y2, color=GREEN, width=2.5, both=False, dash=False, head='med'):
    shape = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,
                                      Inches(x1), Inches(y1), Inches(x2), Inches(y2))
    shape.line.color.rgb = rgb(color)
    shape.line.width = Pt(width)
    ln = shape._element.spPr.find('{http://schemas.openxmlformats.org/drawingml/2006/main}ln')
    if head:
        end = OxmlElement('a:tailEnd')
        end.set('type', 'triangle')
        end.set('w', head)
        end.set('len', head)
        ln.append(end)
    if both:
        begin = OxmlElement('a:headEnd')
        begin.set('type', 'triangle')
        begin.set('w', head or 'med')
        begin.set('len', head or 'med')
        ln.append(begin)
    if dash:
        shape.line.dash_style = 2
    return shape


def new_slide(title, section, source='', backup=False, cover=False, layout=None):
    slide = prs.slides.add_slide(layout if layout is not None else (cover_layout if cover else body_layout))
    for shape in list(slide.shapes):
        shape._element.getparent().remove(shape._element)
    idx = len(prs.slides)
    if not cover:
        text(slide, .53, .34, 12.2, .73, title, size=34, color=NAVY, font=DISPLAY)
        text(slide, .55, 1.23, 11.9, .32, section.upper(), size=16,
             color=DARKGREEN, bold=True)
        text(slide, 12.20, 7.16, .55, .27,
             str(idx-MAIN_SLIDE_COUNT) if backup else str(idx), size=14,
             color=NAVY, align=PP_ALIGN.RIGHT)
    records.append({'slide': idx, 'title': title, 'backup': backup,
                    'source': source, 'section': section})
    return slide


def note(slide, speaker, seconds, script, cue, transition='', qa='', sources=''):
    rec = records[-1]
    rec.update(speaker=speaker, seconds=seconds, script=script,
               cue=cue, transition=transition, qa=qa, verification=sources)
    slide.notes_slide.notes_text_frame.text = (
        f"SUGGESTED SPEAKER: {speaker}\nTIME: {seconds} seconds\n"
        f"KEY MESSAGE / SPOKEN OUTLINE\n{script}\n\nDELIVERY CUE\n{cue}\n"
        f"\nTRANSITION\n{transition}\n\nQ&A PREPARATION\n{qa}\n"
        f"\nSOURCE AND SCOPE CHECK\n{sources}\n"
    )


def node(slide, x, y, w, h, title, detail='', fill=WHITE, title_size=23,
         detail_size=21, title_color=NAVY, center=False):
    rect(slide, x, y, w, h, fill, stroke=LINE, radius=True)
    align = PP_ALIGN.CENTER if center else PP_ALIGN.LEFT
    text(slide, x+.17, y+.13, w-.34, .45, title, size=title_size,
         color=title_color, bold=True, align=align)
    if detail:
        text(slide, x+.17, y+.66, w-.34, h-.76, detail, size=detail_size,
             color=INK, align=align)


def picture_contain(slide, path, cx, cy, maxw, maxh):
    im = Image.open(path)
    iw, ih = im.size
    bbox = im.getbbox() if im.mode == 'RGBA' else (0, 0, iw, ih)
    x0, y0, x1, y1 = bbox
    vw, vh = x1-x0, y1-y0
    scale = min(maxw/vw, maxh/vh)
    w, h = vw*scale, vh*scale
    pic = slide.shapes.add_picture(str(path), Inches(cx-w/2), Inches(cy-h/2),
                                   Inches(w), Inches(h))
    pic.crop_left, pic.crop_right = x0/iw, (iw-x1)/iw
    pic.crop_top, pic.crop_bottom = y0/ih, (ih-y1)/ih
    return pic


def native_table(slide, x, y, widths, heights, rows, font_size=20, header_size=20):
    table=slide.shapes.add_table(len(rows),len(widths),Inches(x),Inches(y),
                                 Inches(sum(widths)),Inches(sum(heights))).table
    for j,w in enumerate(widths):table.columns[j].width=Inches(w)
    for i,(values,h) in enumerate(zip(rows,heights)):
        table.rows[i].height=Inches(h)
        for j,value in enumerate(values):
            cell=table.cell(i,j)
            cell.text=str(value)
            cell.margin_left=cell.margin_right=Inches(.10)
            cell.margin_top=cell.margin_bottom=Inches(.05)
            cell.vertical_anchor=MSO_ANCHOR.MIDDLE
            cell.fill.solid();cell.fill.fore_color.rgb=rgb(NAVY if i==0 else MINT if i%2 else WHITE)
            for p in cell.text_frame.paragraphs:
                p.font.name=FONT;p.font.size=Pt(header_size if i==0 else font_size)
                p.font.bold=i==0;p.font.color.rgb=rgb(WHITE if i==0 else INK)
                p.space_after=Pt(0);p.space_before=Pt(0);p.line_spacing=1.0
            props=cell._tc.get_or_add_tcPr()
            for side in ['L','R','T','B']:
                ln=OxmlElement('a:ln'+side);ln.set('w','6350')
                fill=OxmlElement('a:solidFill');color=OxmlElement('a:srgbClr');color.set('val',LINE);fill.append(color);ln.append(fill);props.append(ln)
    return table


def route(slide, points, color=GREEN, width=2.5):
    for i,(a,b) in enumerate(zip(points,points[1:])):
        arrow(slide,*a,*b,color=color,width=width,head='med' if i==len(points)-2 else None)


def flow_node(slide,x,y,w,h,label,kind='process',size=21):
    typ={'process':MSO_SHAPE.RECTANGLE,'decision':MSO_SHAPE.DIAMOND,'terminal':MSO_SHAPE.ROUNDED_RECTANGLE}[kind]
    shape=slide.shapes.add_shape(typ,Inches(x),Inches(y),Inches(w),Inches(h))
    if kind=='terminal':shape.adjustments[0]=.45
    shape.fill.solid();shape.fill.fore_color.rgb=rgb(MINT if kind!='process' else WHITE)
    shape.line.color.rgb=rgb(NAVY);shape.line.width=Pt(1.25)
    pad=.30 if kind=='decision' else .12
    text(slide,x+pad,y+(.22 if kind=='decision' else .10),w-2*pad,h-.16,label,
         size=size,color=NAVY,bold=kind!='process',align=PP_ALIGN.CENTER)
    return shape


# 1 — A clean cover using the template's white-and-green body layout.
# Keep the exact native ribbon/bottom rule; keep the content field free of the
# original photograph and watermark so the title and credits share a clear grid.
s = new_slide('Agentic Emergency Tele-Triage & Autonomous Medical Dispatch System',
              'Cover', cover=True, layout=body_layout)
rect(s, 0, 2.05, SW, 5.40, WHITE)
rect(s, 6.00, 1.58, SW-6.00, .47, WHITE)
logos = ['MSA Logo - V.png','CSE Department.png','Engineering1.png','University of Greenwich - Blue.png']
for cx, name in zip([2.285, 5.215, 8.145, 11.075], logos):
    picture_contain(s, LOGOS/name, cx, .73, 2.10, .88)
text(s, .85, 1.28, 11.63, .32, 'GRADUATION PROJECT I  /  MIDTERM',
     size=16, color=DARKGREEN, bold=True)
text(s, .85, 2.28, 11.63, 1.69,
     'Agentic Emergency Tele-Triage\n& Autonomous Medical Dispatch System',
     size=44, color=NAVY, bold=False, font=DISPLAY)
text(s, .88, 4.20, 11.60, .48, 'Three agents. One hospital-reviewed request.',
     size=23, color=DARKGREEN)
rect(s, .85, 5.10, 11.63, .012, LINE)
for x, label, name, detail in [
    (.85, 'STUDENT', 'Omar Mostafa Omar', 'ID 235559'),
    (4.85, 'STUDENT', 'Abdelrahman Mahmoud Ali', 'ID 237343'),
    (8.85, 'SUPERVISOR', 'Dr. Gehad Mohey Rezk', '')]:
    text(s, x, 5.43, 3.63, .30, label, size=14, color=GRAY, bold=True)
    text(s, x, 5.90, 3.63, .44, name, size=21, color=NAVY)
    if detail:
        text(s, x, 6.36, 3.63, .34, detail, size=18, color=GRAY)
text(s, .85, 7.10, 9.10, .29, 'Computer Systems Engineering  •  MSA University', size=16, color=GRAY)
text(s, 10.20, 7.10, 1.70, .29, '2026/2027', size=16, color=GRAY, align=PP_ALIGN.RIGHT)
text(s, 12.20, 7.16, .55, .27, '1', size=14, color=NAVY, align=PP_ALIGN.RIGHT)
note(s, 'Omar', 20,
     'Every emergency call needs clear patient facts, a confirmed location, and a request that someone actually receives. Our project connects these steps through three agents and a hospital-reviewed workflow.',
     'Open with the purpose. Do not read the full title or every logo. Pause after “actually receives.”',
     'First, what makes that connection difficult?',
     'Why does the title say autonomous? The approved title is retained; the current prototype requires staff approval before dispatch notification.',
     'Latest thesis English cover and Sections 1.4–1.5. Logos are the repository originals in MSA → CSE → ENG → Greenwich order.')

# 2 — State the problem in plain language, then show concrete causes and consequences.
s = new_slide('Problem definition', 'From patient information to ambulance coordination',
              'Thesis §§1.1–1.2 and §1.5; no unsupported hospital statistics or achieved benefits.')
problem_statement=('An emergency call may leave staff without enough reliable information to judge urgency, '
                   'locate the patient and arrange a suitable ambulance.')
rect(s,.58,2.14,12.15,1.20,NAVY,radius=True)
text(s,.83,2.34,11.65,.94,problem_statement,size=25,color=WHITE)
problem_rows=[['Main problem','Why it matters'],
              ['Missing details needed to judge urgency',
               'Missing details about symptoms, breathing or consciousness can make a serious case harder to recognise.'],
              ['Unclear location or unsuitable ambulance',
               'An unclear address or an ambulance that is unavailable or lacks the needed equipment can delay help.'],
              ['Incorrect or undelivered dispatch request',
               'The dispatch request may fail to reach the receiving team.']]
t=native_table(s,.58,3.72,[4.02,8.13],[.46]+[.92]*3,problem_rows,font_size=21,header_size=20)
for i in range(1,4):
    for p in t.cell(i,0).text_frame.paragraphs:p.font.bold=True
records[-1]['problem_statement']=problem_statement
records[-1]['problem_rows']=problem_rows[1:]
note(s,'Omar',60,
     'Our main problem is turning an emergency call into enough reliable information for an urgency assessment and an ambulance decision. First, callers may omit symptoms or details about breathing and consciousness. A serious case can therefore be hard to recognise from the description alone. Second, help needs a confirmed location and a suitable available vehicle, with the needed equipment and a reasonable travel time. Third, the dispatch request must reach the receiving team, and the incident must show whether delivery was confirmed. These are the workflow risks our prototype will address and test; they are not claims about failure rates at a particular hospital.',
     'Explain the main statement, then each row as a problem and its consequence. Use one caller example; keep implementation details for the design slides.',
     'Our aim and four objectives show how the prototype will address these problems.',
     'Are you claiming all hospitals have these failures? No. These are the project’s defined information and coordination risks, supported by the reviewed research and translated into testable prototype requirements.',
     'Thesis §§1.1–1.2: incomplete caller facts, uncertain symptom-based urgency, unconfirmed locations, missing resource context, and notification receipts. §1.4 defines availability, travel-time and equipment checks; §§1.4–1.5 define correction handling, staff approval and delivery verification. No measured clinical improvement, mortality reduction or ambulance response-time reduction is claimed.')

# 3 — One aim above four compact objectives; preserve every thesis objective pair.
s = new_slide('Project aim & objectives', 'One aim · four objectives covering the eight thesis objectives',
              'Thesis §1.4. Pair mapping and evaluation details remain in speaker notes and the guide.')
aim=('Develop and evaluate a hospital telephone prototype for preliminary triage and '
     'staff-approved ambulance dispatch in English and Egyptian Arabic.')
rect(s,.55,2.12,12.23,1.13,NAVY,radius=True)
text(s,.80,2.47,1.16,.32,'OUR AIM',size=17,color='C4E2B8',bold=True)
text(s,2.15,2.26,10.27,.88,aim,size=22,color=WHITE)
objectives=[
    (.55,3.48,'01','Bilingual voice service',
     'English, Egyptian Arabic and mixed calls.\nTarget a meaningful reply below 1.5 s.',
     'Measure language performance and cost.',[1,8]),
    (6.78,3.48,'02','Reliable incident record',
     'Collect symptoms, callback details and location.\nPreserve corrections; recover interrupted calls.',
     'Test recovery and rejection of outdated results.',[2,7]),
    (.55,5.25,'03','Urgency, guidance & location',
     'Recommend preliminary urgency and reviewed\nfirst aid; confirm the patient’s location.',
     'Measure urgency errors and location accuracy.',[3,4]),
    (6.78,5.25,'04','Staff-approved dispatch',
     'Match a simulated ambulance. Send approved dispatch requests and record whether delivery was confirmed.',
     'Test failed sends, retries and duplicate prevention.',[5,6]),
]
for x,y,n,title,body,measure,pair in objectives:
    rect(s,x,y,6.0,1.66,WHITE,stroke=LINE,radius=True)
    rect(s,x,y,.065,1.66,GREEN)
    text(s,x+.20,y+.11,.5,.35,n,size=18,color=GREEN,bold=True)
    text(s,x+.82,y+.11,4.95,.41,title,size=22,bold=True)
    text(s,x+(.17 if n=='04' else .20),y+.56,5.66 if n=='04' else 5.60,.71,body,size=18 if n=='04' else 19)
    text(s,x+.20,y+1.30,5.60,.31,measure,size=17,color=DARKGREEN,bold=True)
records[-1]['aim']=aim
records[-1]['objective_pairs']=[row[-1] for row in objectives]
note(s,'Omar',65,
     'Our aim is to develop and evaluate a hospital telephone prototype for preliminary triage and staff-approved ambulance dispatch in English and Egyptian Arabic. Four paired objectives turn that aim into work we can test. First, provide bilingual voice interaction and measure meaningful-reply delay, language performance and cost. Second, preserve patient facts and corrections through interruptions and reject outdated results. Third, recommend preliminary urgency and reviewed first aid, then confirm the caller’s location. Fourth, match a simulated ambulance using availability, travel time and equipment, obtain staff approval, and verify request delivery with failure and duplicate tests. The 1.5-second value remains a target, not a result.',
     'State the aim once, then spend about 12 seconds per objective. Bold blue names the objective, regular blue describes the work, and green identifies its evaluation.',
     'Clinical review and realistic requirements will need input from an industrial partner.',
     'Which objectives were combined? 1+8, 2+7, 3+4, and 5+6. All eight remain represented. The aim is condensed for presentation; its patient-information requirement appears explicitly in objective 2.',
     'Thesis §1.4. The original aim and all eight objectives are preserved through four pairs. Speaker notes and the guide retain language/noise tests, extraction errors, corrections, interruption recovery, median/p95 reply time, reviewed urgency labels, location confirmation, resource constraints, approved requests, receipts, bounded retries, duplicate prevention and operating-cost measurement.')

# 4 — Outreach is not represented as a secured partnership.
s = new_slide('Industrial partner', 'Current status and the support we need', 'Thesis §1.6. Outreach reported in the thesis; no confirmed partnership is claimed.')
tag(s,.58,2.16,4.45,'NO OFFICIAL PARTNER SECURED',fill=PALE,color=GRAY)
text(s,.58,2.85,5.85,.52,'Reported outreach',size=28,bold=True)
text(s,.58,3.58,5.72,2.15,
     'eHealth  •  Khabeer Group  •  paraMIND\nCleopatra Hospitals Group\nEgyptian Ambulance Organization\nITIDA: project support and sponsorship',size=23)
rect(s,6.92,2.16,5.84,4.33,MINT,stroke=LINE,radius=True)
text(s,7.20,2.44,5.24,.52,'Partner input will support',size=27,bold=True)
for y,label in [(3.32,'Requirements and emergency workflow'),(4.23,'Review of urgency and first-aid material'),(5.14,'An authorized telephone test arrangement')]:
    rect(s,7.23,y,.08,.44,GREEN)
    text(s,7.48,y-.01,4.97,.74,label,size=24)
note(s,'Omar',25,
     'The thesis reports outreach to these organizations, but no official partner has been secured. We need practical requirements, qualified review of urgency and first-aid material, and an authorized test telephone arrangement. Outreach is not evidence of a partnership or access to patient records.',
     'Be precise about status. Do not imply that any listed organization endorses the prototype.',
     'Two of the reviewed studies most directly inform our proposed workflow.',
     'Is a hospital already committed? No official partnership is documented in the current thesis.',
     'Thesis §1.6. ITIDA is outreach for support/sponsorship, not a clinical validation partner.')

# 5–6 — Five explicit blocks in reading order: top Goal / Method / Results;
# bottom Limitations / Relevance. Wider method and result panels keep explanations readable.
def literature_panel(slide,x,y,w,h,title,body,fill=WHITE):
    start=len(slide.shapes)
    rect(slide,x,y,w,h,fill,stroke=LINE,radius=True)
    text(slide,x+.20,y+.09,w-.40,.42,title,size=22,
         color=WHITE if fill==NAVY else NAVY,bold=True)
    text(slide,x+.20,y+.53,w-.40,h-.61,body,size=18.5,
         color=WHITE if fill==NAVY else INK)
    group=slide.shapes.add_group_shape(list(slide.shapes)[start:])
    group.name=title+' panel'
    return {'heading':title,'body':body}

s = new_slide('Review of literature — DispatchMAS', 'Emergency caller–dispatcher simulation')
tag(s,.58,2.12,3.25,'PUBLISHED: 2026',size=18)
text(s,4.10,2.14,8.65,.35,'Li et al.  |  BMC Emergency Medicine 26:78  |  [1]',size=19,color=GRAY)
panels=[
    (.58,2.70,2.80,2.56,'Goal',
     'Test an automated dispatcher’s questions and advice in simulated emergency calls.',MINT),
    (3.63,2.70,4.45,2.56,'Method',
     'One agent plays the caller; another asks one focused question at a time. Four doctors review 100 simulated calls from 50 patient records.',WHITE),
    (8.33,2.70,4.45,2.56,'Results',
     'Medical guidance was provided in 91% of simulated scenarios needing advice. Most physician helpfulness ratings were 4 or 5 out of 5.',NAVY),
    (.58,5.39,5.98,1.61,'Limitations',
     'English simulations used one fixed address. No real responders were contacted, and live telephone speech was not tested.',WHITE),
    (6.80,5.39,5.98,1.61,'Relevance to our project',
     'Both focus on emergency-call agents that collect symptoms and provide medical guidance while the caller waits for an ambulance.',MINT),
]
records[-1]['literature_panels']=[literature_panel(s,*panel) for panel in panels]
note(s,'Omar',60,
     'DispatchMAS tests emergency medical conversations. A caller agent describes an emergency; a dispatcher agent asks focused questions and gives advice. Four doctors review 100 simulated calls from 50 patient records. Advice was provided in 91 percent of scenarios where it was needed. This measures whether advice was given, not whether every instruction was medically correct. Most physician ratings of helpfulness were four or five out of five. Tests use English, one fixed address and simulated responders; live telephone speech is not tested. Its relevance is the shared patient-facing function: collecting symptoms during an emergency call and providing medical guidance before an ambulance arrives. TriAgent focuses on the assessment behind that conversation.',
     'Explain 91% as advice provision in simulated scenarios needing advice. Then state the shared function: symptom questioning and medical guidance before ambulance arrival.',
     'TriAgent addresses urgency assessment when the patient description is incomplete.',
     'Does 91% mean the medical advice was correct? No. Results says advice was provided in 91% of scenarios where it was deemed necessary. It is advice coverage, not clinical accuracy. Helpfulness was a separate physician-rated item, with most scores 4 or 5 on a five-point scale. Neither establishes patient outcomes or real ambulance delivery.',
     'Original DispatchMAS PDF: Methods describes 50 adult records, two caller identities per record and 100 simulated dialogues; four physicians rate assigned cases. Evaluation defines pre-arrival advice as non-diagnostic positioning, monitoring and immediate safety instructions. Table 2, PDF p.9, separates advice provision, amount and helpfulness. Results: System performance, PDF p.12, reports advice in 91% of scenarios where deemed necessary and majority scores 4 or 5 for amount/helpfulness. The paper uses English, a fixed address and mocked responder replies; live telephone speech is not validated. Publication year 2026 is printed; exact publication day/month is not. See literature-evidence.json.')

s = new_slide('Review of literature — TriAgent', 'Clinical decision support under incomplete information')
tag(s,.58,2.12,4.15,'PUBLISHED: 18 JUNE 2026',size=18)
text(s,5.12,2.14,7.63,.35,'Ibrahim et al.  |  AI 7:230  |  [2]',size=19,color=GRAY)
panels=[
    (.58,2.70,2.80,2.56,'Goal',
     'Assess urgency and plan care when the patient’s description is incomplete.',MINT),
    (3.63,2.70,4.45,2.56,'Method',
     'Orchestrator Agent: selects tasks.\nSpecialist modules: assess urgency, find similar cases, draft a care plan and check drug/allergy risks.\nCritique Agent: reviews the plan and requests fixes.',WHITE),
    (8.33,2.70,4.45,2.56,'Results',
     '65.7% of 1,000 cases were assigned the correct urgency level.\n\n85.0% of the study’s critical cases were correctly flagged as critical.',NAVY),
    (.58,5.39,5.98,1.61,'Limitations',
     'Used recorded vital signs; typical case processing exceeded one minute. Live calls, caller location and ambulance delivery were not tested.',WHITE),
    (6.80,5.39,5.98,1.61,'Relevance to our project',
     'Both coordinate specialist roles to interpret incomplete patient information and recommend how urgently the patient needs medical attention.',MINT),
]
records[-1]['literature_panels']=[literature_panel(s,*panel) for panel in panels]
note(s,'Omar',65,
     'TriAgent handles incomplete patient information. The Orchestrator Agent selects specialist tasks. A trained urgency model uses symptoms and vital signs; other modules retrieve similar cases, draft a care plan and check drug and allergy risks. The Critique Agent reviews the plan and requests corrections. Critical presentations bypass that review for immediate escalation. Across 1,000 recorded cases, 65.7 percent received the correct urgency level. Among reference-critical cases, 85 percent were identified as critical. These are different denominators. Typical case processing exceeded one minute; live calls were not tested. The shared aspect is coordinated specialist roles that turn incomplete patient information into an urgency recommendation. Our project does not prescribe medication. Abdelrahman will show our design.',
     'Explain the roles in order: Orchestrator selects; specialist modules assess, retrieve, plan and check; Critique reviews. Distinguish overall accuracy from critical-case recall. End with the shared medical assessment function.',
     'Our narrower design uses three language-model roles and a Python controller.',
     'What exactly is 85%? Critical-case recall: of cases whose reference label is critical, 85% were assigned critical by the system. It is not the percentage of all 1,000 cases that were critical, and not the reliability of every predicted critical result. The study maps the nurses’ ESI-1 labels to critical. Its 334 critical, 333 urgent and 333 routine cases are a constructed balanced cohort.',
     'Original TriAgent PDF Sections 3.2–3.4, Figure 2 and Algorithm 1: patient input is parsed into case state; an LLM Orchestrator selects specialist modules for urgency assessment, similar-case retrieval, treatment drafting, drug/allergy checks, policy review and documentation. A Critique Agent reviews continuation outputs and can request a correction pass; critical presentations take an emergency bypass and skip critique. The modules are not all separate LLM agents. Sections 2.1, 3.5 and 4.2–4.3: 1,000 retrospective cases; separate trained gradient-boosted classifier uses complaint features, vital signs and arrival mode. Accuracy 65.7%; reference-critical recall 85.0%. Median runtimes 64 seconds bypass / 186 seconds continuation are case-processing times, not spoken replies. The shared feature is multi-role medical assessment under incomplete information; our ordinary Python controller, three roles and caller inputs differ. Medication prescribing is outside our project. Published 18 June 2026. See literature-evidence.json.')

# 7 — Native editable block diagram; arrows to each agent show controller routing.
s = new_slide('Proposed system — block diagram', 'Three large language model (LLM) agents + a Python software controller')
node(s,.55,2.30,2.10,2.04,'Caller','Test phone\nSpeech ↔ text',fill=PALE,title_size=24,detail_size=20,center=True)
for x,label,title,detail in [
    (3.20,'Agent 1','Conversation','Caller questions\nFacts and corrections'),
    (6.45,'Agent 2','Triage & guidance','Urgency + first aid\nfrom reviewed sources'),
    (9.70,'Agent 3','Coordination','Location and resources\nIncident report')]:
    rect(s,x,2.18,3.05,2.05,MINT,stroke=NAVY,radius=True)
    text(s,x+.16,2.32,2.73,.30,label.upper(),size=17,color=DARKGREEN,bold=True)
    text(s,x+.16,2.79,2.73,.42,title,size=23,bold=True)
    text(s,x+.16,3.37,2.73,.72,detail,size=20)
arrow(s,2.73,3.23,3.12,3.23,both=True,color=NAVY,width=2.5,head='med')
text(s,2.71,2.81,.49,.27,'voice',size=14,color=GRAY,align=PP_ALIGN.CENTER)
for x in [4.725,7.975,11.225]:
    arrow(s,x,4.37,x,4.88,both=True,color=GREEN,width=3.0,head='med')
rect(s,3.20,5.02,9.55,.76,NAVY,radius=True)
text(s,3.40,5.16,9.15,.45,'Python controller  |  routing  |  validation  |  incident record',size=22,color=WHITE,bold=True)
node(s,.55,5.03,2.10,1.46,'Takeover','Staff at any\nstage',title_size=21,detail_size=19,center=True)
for x,title in [(3.20,'Incident record'),(6.65,'Staff approval'),(10.10,'Test receiver')]:
    node(s,x,6.25,2.65,.59,title,title_size=21,center=True,fill=MINT if x==6.65 else WHITE)
arrow(s,5.96,6.55,6.54,6.55,color=NAVY,width=2.8,head='lg')
arrow(s,9.41,6.55,9.99,6.55,color=NAVY,width=2.8,head='lg')
arrow(s,4.525,5.89,4.525,6.14,color=GREEN,width=2.5,head='med')
arrow(s,11.425,6.14,11.425,5.89,color=GREEN,width=2.5,head='med')
text(s,11.69,5.88,1.0,.26,'receipt',size=14,color=DARKGREEN)
note(s,'Abdelrahman',70,
     'The thick voice arrow connects the caller and speech tools to Agent 1, the only speaking agent. Agent 2 recommends preliminary urgency and retrieves reviewed first aid. Agent 3 confirms location, checks simulated vehicle availability, travel time and equipment, and prepares the report. The three vertical double-headed arrows carry tasks and results between the agents and the Python controller. That controller is ordinary software. It maintains one record, rejects outdated results, and runs only the work affected by a change. Along the bottom, a reviewable incident reaches staff approval before transmission. The upward receipt arrow records acceptance at the test receiver. Staff can take over at any stage; receipt is separate from ambulance assignment or departure.',
     'Trace the thick voice arrow, then the three task/result arrows, then the approval and receipt paths. The agents are not a forced sequential chain.',
     'The flowchart shows what happens when information is missing or a delivery fails.',
     'Could all agents use the same model? Yes, different roles can use separate instructions with the same underlying model. Final model/tool selection remains detailed-design work.',
     'Thesis §§3.1–3.1.2. Numbered agents are roles; speech, maps, storage, and retrieval are services. No actual live ambulance control is shown.')

# 8 — Flowchart with explicit approval and recovery rather than a success-only path.
s = new_slide('Proposed system — flowchart', 'A minimal workflow with approval, clarification and delivery outcomes')
flow_node(s,.55,2.22,2.0,.80,'Incoming call',kind='terminal',size=21)
flow_node(s,3.10,2.10,3.20,1.05,'Collect facts\nTriage + first aid',size=22)
flow_node(s,7.00,2.10,3.20,1.05,'Confirm location\nSelect simulated vehicle',size=21)
flow_node(s,10.65,2.00,2.10,1.25,'Staff\napproves?',kind='decision',size=20)
arrow(s,2.65,2.625,3.00,2.625,color=NAVY,width=2.5)
arrow(s,6.40,2.625,6.90,2.625,color=NAVY,width=2.5)
arrow(s,10.30,2.625,10.57,2.625,color=NAVY,width=2.5)
route(s,[(11.70,3.32),(11.70,3.70),(4.70,3.70),(4.70,3.23)],color=GREEN)
text(s,11.17,3.31,.45,.28,'No',size=16,color=DARKGREEN,bold=True)
text(s,5.36,3.27,4.67,.31,'Clarify / staff takeover',size=18,color=DARKGREEN,align=PP_ALIGN.CENTER)
route(s,[(12.84,2.625),(13.03,2.625),(13.03,4.90),(12.83,4.90)],color=NAVY)
text(s,12.30,3.65,.54,.31,'Yes',size=17,color=NAVY,bold=True)
flow_node(s,10.15,4.30,2.60,1.25,'Send approved\nrequest\n≤ 3 attempts',size=19)
flow_node(s,6.50,4.25,2.10,1.25,'Receipt\nreceived?',kind='decision',size=20)
arrow(s,10.05,4.875,8.70,4.875,color=NAVY,width=2.5)
flow_node(s,2.82,4.50,2.70,.75,'Log receipt · End',kind='terminal',size=21)
arrow(s,6.40,4.875,5.62,4.875,color=GREEN,width=2.5)
text(s,5.73,4.51,.54,.29,'Yes',size=17,color=DARKGREEN,bold=True)
flow_node(s,5.50,6.25,4.10,.60,'Alert staff · Unconfirmed delivery',kind='terminal',size=20)
arrow(s,7.55,5.60,7.55,6.16,color=NAVY,width=2.5)
text(s,7.75,5.76,.54,.29,'No',size=17,color=NAVY,bold=True)
note(s,'Abdelrahman',45,
     'The rounded symbol starts the call. The process boxes collect facts, assess preliminary urgency and guidance, and confirm location and simulated resources. The first diamond asks whether staff approve. No returns to clarification or staff takeover; Yes sends the approved request. Delivery can use up to three attempts with the same request ID. The second diamond checks for a receipt. Yes records the receipt; No ends in an alert with unconfirmed delivery. A receipt confirms receiver acceptance, not ambulance departure.',
     'Follow the start/process symbols, explain the staff-approval diamond, then the receipt diamond. Trace the No loops and failure end explicitly.',
     'Here is one fictional call following those steps.',
     'Does a receipt mean an ambulance departed? No. Approval, sending, receipt, simulated assignment, and departure are separate events.',
     'Thesis functional requirements and flowchart. “Up to 3 attempts” is proposed, not a measured reliability result.')

# 9 — Five click-triggered reveals, using a clearly fictional case.
s = new_slide('An example emergency call', 'Proposed workflow · fictional case #042 · simulated ambulance')
text(s,8.89,1.65,3.85,.28,'5 clicks · about 45 seconds',size=15,color=GRAY,align=PP_ALIGN.RIGHT)
groups=[]
start=len(s.shapes)
rect(s,.68,2.16,3.07,4.55,NAVY,radius=True)
rect(s,.84,2.47,2.75,3.98,WHITE,radius=True)
rect(s,1.73,2.29,.97,.045,LINE,radius=True)
rect(s,1.64,6.53,1.15,.04,LINE,radius=True)
rect(s,.84,2.47,2.75,.70,MINT,radius=True)
text(s,1.02,2.66,2.39,.32,'1  CALLER',size=18,color=DARKGREEN,bold=True,align=PP_ALIGN.CENTER)
text(s,1.03,3.31,2.37,.29,'EGYPTIAN ARABIC',size=13,color=GRAY,bold=True)
a=text(s,1.03,3.80,2.36,.95,'بابا دايخ ومحتاج مساعدة.',size=23,color=NAVY,font='Arial',align=PP_ALIGN.RIGHT)
for paragraph in a.text_frame.paragraphs:
    paragraph._p.get_or_add_pPr().set('rtl','1')
    rpr=paragraph._p.get_or_add_pPr().find('{http://schemas.openxmlformats.org/drawingml/2006/main}defRPr')
    if rpr is not None:rpr.set('lang','ar-EG')
text(s,1.03,4.99,2.37,1.06,'“My father is dizzy\nand needs help.”',size=19,color=INK)
text(s,1.03,6.00,2.37,.27,'Illustrative caller statement',size=13,color=GRAY)
g=s.shapes.add_group_shape(list(s.shapes)[start:]);g.name='Scenario step 1 - Caller';groups.append(g)
steps=[
    (2,2.12,'Collect details and confirm location',
     'Awake, breathing normally · Address confirmed: Building 12.',WHITE),
    (3,3.30,'Suggest urgency and a simulated ambulance',
     'Urgency for staff review · Vehicle A available · 8 min (assumed).',WHITE),
    (4,4.48,'Staff review and approve',
     'Check the report and proposed vehicle; approve request #042.',WHITE),
    (5,5.66,'Confirm and record delivery',
     'Test receiver: request #042 received · Delivery confirmed.',MINT),
]
for n,y,title,detail,fill in steps:
    start=len(s.shapes)
    cy=y+.50
    if n>2:arrow(s,4.28,cy-1.18+.24,4.28,cy-.27,color=GREEN,width=2.5)
    circle=s.shapes.add_shape(MSO_SHAPE.OVAL,Inches(4.06),Inches(cy-.22),Inches(.44),Inches(.44))
    circle.fill.solid();circle.fill.fore_color.rgb=rgb(GREEN);circle.line.fill.background()
    text(s,4.06,cy-.16,.44,.31,str(n),size=17,color=WHITE,bold=True,align=PP_ALIGN.CENTER)
    rect(s,4.60,y,8.15,1.00,fill,stroke=LINE,radius=True)
    text(s,4.82,y+.10,7.71,.40,title,size=22,bold=True)
    text(s,4.82,y+.56,7.71,.35,detail,size=18.5,color=DARKGREEN if n==5 else INK)
    g=s.shapes.add_group_shape(list(s.shapes)[start:]);g.name=f'Scenario step {n} - {title}';groups.append(g)
text(s,.68,6.90,11.33,.28,'Staff approval → request sent → delivery confirmed',size=16,color=DARKGREEN,bold=True)
records[-1]['animation']=add_click_fades(s,groups,duration_ms=350)
records[-1]['scenario']={'fictional':True,'caller_language':'Egyptian Arabic',
                        'caller_quote':'بابا دايخ ومحتاج مساعدة.',
                        'assumed_vehicle_travel_minutes':8,'request_id':'042','clicks':5}
note(s,'Abdelrahman',45,
     'This is a proposed example, not a live prototype result. Click one: the caller says in Egyptian Arabic that their father is dizzy and needs help. Click two: the conversation collects symptoms, checks consciousness and breathing, and confirms the address. Click three: the urgency recommendation goes to staff, with an available simulated vehicle; the eight-minute estimate is an assumption. Click four: staff review and approve request 042. Click five: our test receiver confirms arrival of that request, and the incident records delivery. The animation shows the intended workflow. Delivery confirmation is separate from ambulance departure.',
     'Use Slide Show mode. Click once per step and explain the newly revealed panel. Five 350-millisecond fades are controlled by the presenter; the slide never advances automatically.',
     'We will measure these steps against the following system targets.',
     'Are these real patient data or tested clinical decisions? This is a fictional case. The Arabic quote, vehicle data, travel time and delivery state are illustrative; medical criteria still need review. No final diagnosis or first-aid instruction is fabricated.',
     'Illustration based on thesis §§1.4–1.5 and 3.1. Conversation, preliminary assessment, resource recommendation, staff approval and delivery confirmation follow the documented requirements. This slide demonstrates planned behavior, not a running hospital connection or validated triage result.')

# 9 — Clearly distinguish targets from results.
s = new_slide('System specifications', 'Design targets and scope — not measured prototype results', 'Thesis §3.1: functional and non-functional requirements.')
specs=[(.58,2.20,'< 1.5 s','First meaningful audible reply','Report median and p95 delay.'),
       (6.80,2.20,'3 language conditions','English • Egyptian Arabic • mixed','Report each condition separately.'),
       (.58,4.44,'1 hospital','Test telephone line + simulated fleet','A working, authorized test receiver.'),
       (6.80,4.44,'Up to 3 attempts','Proposed notification retry limit','Same request ID; staff alert on failure.')]
for x,y,big,label,small in specs:
    rect(s,x,y,5.96,2.04,WHITE,stroke=LINE,radius=True)
    text(s,x+.20,y+.14,5.56,.55,big,size=31,color=GREEN,bold=True)
    text(s,x+.20,y+.85,5.56,.46,label,size=23,bold=True)
    text(s,x+.20,y+1.49,5.56,.34,small,size=20,color=GRAY)
note(s,'Abdelrahman',30,
     'These are targets and boundaries. The 1.5-second value is the first meaningful audible response after a caller finishes a turn. A filler acknowledgment does not qualify. English, Egyptian Arabic, and mixed-language calls will be measured separately. The prototype represents one hospital and uses simulated ambulance resources. The proposed notification limit is three attempts with duplicate prevention. Urgency labels and first-aid content still require qualified review.',
     'Say “target” before the latency value. Expand p95 as the 95th percentile.',
     'Our contribution is how these requirements connect into one workflow.',
     'Is a full incident report also due within 1.5 seconds? No. Spoken reply, report preparation, and notification have separate clocks.',
     'Thesis §3.1. Proposed prototype constraints are not achieved measurements.')

# 11 — Four thesis contributions, each compared with a verified study boundary.
# All illustrations are editable shapes; each complete card enters on one click.
def contribution_icon(slide,x,y,kind):
    if kind=='correction':
        rect(slide,x+.06,y+.08,.64,.70,WHITE,stroke=NAVY,radius=True)
        rect(slide,x+.23,y+.20,.64,.70,WHITE,stroke=GREEN,radius=True)
        for dy in [.38,.51,.64]:
            arrow(slide,x+.36,y+dy,x+.72,y+dy,color=GREEN,width=1.7,head=None)
        arrow(slide,x+.02,y+.91,x+.92,y+.91,color=GREEN,width=2,head='med')
    elif kind=='language':
        rect(slide,x+.02,y+.08,.68,.48,WHITE,stroke=NAVY,radius=True)
        text(slide,x+.06,y+.14,.60,.30,'EN',size=17,color=NAVY,bold=True,align=PP_ALIGN.CENTER)
        rect(slide,x+.29,y+.48,.68,.48,WHITE,stroke=GREEN,radius=True)
        text(slide,x+.33,y+.53,.60,.32,'ع',size=18,color=DARKGREEN,font='Arial',align=PP_ALIGN.CENTER)
        arrow(slide,x+.04,y+.68,x+.23,y+.68,color=GREEN,width=1.8,head='med')
    elif kind=='location':
        pin=slide.shapes.add_shape(MSO_SHAPE.OVAL,Inches(x+.04),Inches(y+.04),Inches(.36),Inches(.36))
        pin.fill.solid();pin.fill.fore_color.rgb=rgb(WHITE);pin.line.color.rgb=rgb(GREEN);pin.line.width=Pt(1.8)
        point=slide.shapes.add_shape(MSO_SHAPE.ISOSCELES_TRIANGLE,Inches(x+.13),Inches(y+.29),Inches(.18),Inches(.24))
        point.rotation=180;point.fill.solid();point.fill.fore_color.rgb=rgb(GREEN);point.line.fill.background()
        rect(slide,x+.22,y+.55,.68,.32,WHITE,stroke=NAVY,radius=True)
        rect(slide,x+.66,y+.60,.17,.13,MINT,stroke=NAVY)
        for wx in [.37,.76]:
            wheel=slide.shapes.add_shape(MSO_SHAPE.OVAL,Inches(x+wx-.065),Inches(y+.81),Inches(.13),Inches(.13))
            wheel.fill.solid();wheel.fill.fore_color.rgb=rgb(NAVY);wheel.line.fill.background()
        arrow(slide,x+.34,y+.68,x+.52,y+.68,color=GREEN,width=2,head=None)
        arrow(slide,x+.43,y+.59,x+.43,y+.77,color=GREEN,width=2,head=None)
    elif kind=='delivery':
        rect(slide,x+.05,y+.16,.80,.52,WHITE,stroke=NAVY,radius=True)
        arrow(slide,x+.10,y+.23,x+.45,y+.46,color=NAVY,width=1.6,head=None)
        arrow(slide,x+.45,y+.46,x+.80,y+.23,color=NAVY,width=1.6,head=None)
        arrow(slide,x+.48,y+.77,x+.65,y+.93,color=GREEN,width=3,head=None)
        arrow(slide,x+.65,y+.93,x+.98,y+.56,color=GREEN,width=3,head=None)

s = new_slide('Contributions & uniqueness',
              'Four planned contributions compared with the reviewed papers',
              'Thesis §1.5; original DispatchMAS and TriAgent PDFs. These are anticipated prototype contributions.')
text(s,8.90,1.78,3.85,.27,'4 clicks · one contribution at a time',size=14,color=GRAY,align=PP_ALIGN.RIGHT)
contributions=[
    {'number':1,'x':.58,'y':2.12,'title':'Corrections without restarting',
     'paper':'TriAgent [2]: no live-call correction tests.',
     'ours':'Our: update affected tasks when symptoms or the address change.',
     'icon':'correction','thesis_paragraph':'First contribution: corrections update the relevant decision without restarting the interview.'},
    {'number':2,'x':6.80,'y':2.12,'title':'English and Egyptian Arabic',
     'paper':'DispatchMAS [1]: English-only simulations.',
     'ours':'Our: switch languages within a call; separate speech and meaning errors.',
     'icon':'language','thesis_paragraph':'Second contribution: English, Egyptian Arabic and switching within a call; distinguish speech-recognition from interpretation errors.'},
    {'number':3,'x':.58,'y':4.48,'title':'Explain location and ambulance choice',
     'paper':'DispatchMAS [1]: one fixed caller address.',
     'ours':'Our: confirm address; explain ambulance choice; flag missing data.',
     'icon':'location','thesis_paragraph':'Third contribution: supporting location and resource details; alert staff for missing location or unavailable vehicle.'},
    {'number':4,'x':6.80,'y':4.48,'title':'Verify delivery and handle failure',
     'paper':'DispatchMAS [1]: simulated responder contact.',
     'ours':'Our: confirm delivery, prevent duplicate requests and alert staff on failure.',
     'icon':'delivery','thesis_paragraph':'Final contribution: working test receiver; separate approval, sending, receipt and simulated assignment; same identifier across retries.'},
]
groups=[]
for item in contributions:
    start=len(s.shapes);x,y=item['x'],item['y']
    rect(s,x,y,5.98,2.13,WHITE,stroke=LINE,radius=True)
    badge=s.shapes.add_shape(MSO_SHAPE.OVAL,Inches(x+.18),Inches(y+.16),Inches(.36),Inches(.36))
    badge.fill.solid();badge.fill.fore_color.rgb=rgb(GREEN);badge.line.fill.background()
    text(s,x+.18,y+.195,.36,.25,str(item['number']),size=14,color=WHITE,bold=True,align=PP_ALIGN.CENTER)
    text(s,x+.67,y+.13,5.08,.45,item['title'],size=21.5,bold=True)
    text(s,x+.22,y+.68,5.54,.37,item['paper'],size=18.5,color=GRAY)
    rect(s,x+.15,y+1.12,5.68,.84,MINT,radius=True)
    contribution_icon(s,x+.26,y+1.07,item['icon'])
    text(s,x+1.40,y+1.20,4.33,.75,item['ours'],size=18.5,color=INK)
    group=s.shapes.add_group_shape(list(s.shapes)[start:]);group.name=f"Contribution {item['number']} - {item['title']}";groups.append(group)
rect(s,.58,6.78,11.36,.48,NAVY,radius=True)
text(s,.80,6.82,10.92,.40,'Our distinction: one connected hospital-call workflow.',size=21,color=WHITE,bold=True,align=PP_ALIGN.CENTER)
records[-1]['contributions']=[{k:v for k,v in x.items() if k not in ['x','y']} for x in contributions]
records[-1]['animation']=add_click_fades(s,groups,duration_ms=350)
note(s,'Abdelrahman',40,
     'Section 1.5 proposes four contributions. TriAgent has no live-call correction tests; our controller will update affected tasks without restarting the interview. DispatchMAS tests English; we propose English and Egyptian Arabic, separating speech from interpretation errors. Its fixed address leaves varied locations untested; we will explain the confirmed address and simulated ambulance choice, showing missing facts. Its responder contact is simulated; we will verify approved request delivery, prevent duplicates and alert staff on failure. Our distinction is connecting these functions in one prototype. These are planned contributions.',
     'Use four clicks in reading order: top left, top right, bottom left, bottom right. Spend about nine seconds per card, then emphasize the shared workflow. Say planned; do not claim improved clinical outcomes.',
     'We will test these contributions through the following procedures.',
     'Are these four features completely new to all research? No such claim is made. Section 1.5 proposes their working connection in this bilingual hospital-call prototype. TriAgent already coordinates modules and preserves case state; our specific contribution concerns caller corrections and selective updates in our own workflow. A receipt confirms receiver acceptance, not ambulance departure.',
     'Thesis §1.5, PDF pp.12–13: all four anticipated contributions. DispatchMAS Methods/Evaluation and Limitations: synthetic English dialogue, fixed address and mocked auxiliary replies. TriAgent Sections 3–4: retrospective clinical-data evaluation and dynamic orchestration, without a live telephone-correction trial. The diagram represents planned implementation; ambulance resources are simulated. See contributions-evidence.json.')

# 12 — Each test names its input/action and the output to inspect.
# A three-column grid made of editable shapes lets each complete row enter on click.
def testing_icon(slide,x,y,kind):
    if kind=='clinical':
        circle=slide.shapes.add_shape(MSO_SHAPE.OVAL,Inches(x+.04),Inches(y+.01),Inches(.34),Inches(.34))
        circle.fill.solid();circle.fill.fore_color.rgb=rgb(WHITE);circle.line.color.rgb=rgb(GREEN);circle.line.width=Pt(1.7)
        arrow(slide,x+.11,y+.18,x+.31,y+.18,color=GREEN,width=2,head=None)
        arrow(slide,x+.21,y+.08,x+.21,y+.28,color=GREEN,width=2,head=None)
    elif kind=='correction':
        rect(slide,x+.04,y,.27,.31,WHITE,stroke=NAVY,radius=True)
        arrow(slide,x+.11,y+.10,x+.25,y+.10,color=NAVY,width=1.2,head=None)
        arrow(slide,x+.11,y+.18,x+.25,y+.18,color=NAVY,width=1.2,head=None)
        arrow(slide,x+.05,y+.37,x+.40,y+.37,color=GREEN,width=1.8,head='med')
    elif kind=='ambulance':
        rect(slide,x,y+.08,.43,.23,WHITE,stroke=NAVY,radius=True)
        arrow(slide,x+.08,y+.19,x+.22,y+.19,color=GREEN,width=1.8,head=None)
        arrow(slide,x+.15,y+.12,x+.15,y+.26,color=GREEN,width=1.8,head=None)
        rect(slide,x+.29,y+.12,.09,.08,MINT,stroke=NAVY)
        for wx in [.10,.33]:
            wheel=slide.shapes.add_shape(MSO_SHAPE.OVAL,Inches(x+wx-.045),Inches(y+.27),Inches(.09),Inches(.09))
            wheel.fill.solid();wheel.fill.fore_color.rgb=rgb(NAVY);wheel.line.fill.background()
    elif kind=='voice':
        rect(slide,x+.02,y+.02,.37,.27,WHITE,stroke=GREEN,radius=True)
        for dx,h in [(.11,.07),(.20,.15),(.29,.10)]:
            arrow(slide,x+dx,y+.15-h/2,x+dx,y+.15+h/2,color=NAVY,width=1.6,head=None)
        arrow(slide,x+.08,y+.29,x+.08,y+.38,color=GREEN,width=1.5,head=None)
    elif kind=='delivery':
        rect(slide,x+.01,y+.05,.40,.27,WHITE,stroke=NAVY,radius=True)
        arrow(slide,x+.04,y+.09,x+.21,y+.21,color=NAVY,width=1.3,head=None)
        arrow(slide,x+.21,y+.21,x+.38,y+.09,color=NAVY,width=1.3,head=None)
        arrow(slide,x+.14,y+.38,x+.40,y+.38,color=GREEN,width=1.8,head='med')
    elif kind=='approval':
        loop=slide.shapes.add_shape(MSO_SHAPE.OVAL,Inches(x+.10),Inches(y),Inches(.22),Inches(.26))
        loop.fill.background();loop.line.color.rgb=rgb(NAVY);loop.line.width=Pt(1.7)
        rect(slide,x+.04,y+.17,.34,.22,MINT,stroke=GREEN,radius=True)
        arrow(slide,x+.21,y+.23,x+.21,y+.32,color=NAVY,width=1.6,head=None)

s = new_slide('Proposed testing procedures',
              'Six planned tests with specific inputs and expected results',
              'Thesis §§1.4 and 3.1. Examples define planned test inputs and expected checks, not completed results.')
text(s,8.90,1.78,3.85,.27,'6 clicks · one test at a time',size=14,color=GRAY,align=PP_ALIGN.RIGHT)
testing_rows=[
    {'type':'Component','what':'Urgency +\nfirst-aid advice','icon':'clinical',
     'how':'Use clinician-labelled cases; compare urgency and first aid with approved answers. Count Red cases labelled Yellow or Green.'},
    {'type':'Integration','what':'Address change\n+ late map result','icon':'correction',
     'how':'Change the address from Building 12 to Building 21. Delay the Building 12 map response; verify that it cannot overwrite the corrected location.'},
    {'type':'Component','what':'Ambulance\nselection','icon':'ambulance',
     'how':'A = busy; B = missing needed equipment; C = available and equipped. Expect C; remove C → staff alert.'},
    {'type':'System /\nperformance','what':'Bilingual calls\n+ reply delay','icon':'voice',
     'how':'Replay English, Egyptian Arabic and mixed calls; compare facts to script. Time speech end → first meaningful reply (target <1.5 s).'},
    {'type':'Reliability','what':'Request delivery\n+ duplicates','icon':'delivery',
     'how':'Receiver confirms attempt 2 → stop retries. Block 3 sends → staff alert. Lose confirmation → retry same ID; one stored request.'},
    {'type':'Security','what':'Staff approval\nbefore dispatch','icon':'approval',
     'how':'Try sending a dispatch request before the reviewer approves it → no request sent. Obtain reviewer approval → send the approved request.'},
]
cols=[.58,2.38,5.13,12.76]
rect(s,.58,2.06,12.18,.43,NAVY,radius=True)
for j,header in enumerate(['Testing type','What will be tested','How it will be tested']):
    text(s,cols[j]+.14,2.085,cols[j+1]-cols[j]-.28,.38,header,size=20,color=WHITE,bold=True)
groups=[]
for i,row in enumerate(testing_rows):
    y=2.59+i*.76;start=len(s.shapes)
    rect(s,.58,y,12.18,.72,MINT if i%2==0 else WHITE,stroke=LINE,radius=True)
    for xx in cols[1:3]:
        arrow(s,xx,y+.10,xx,y+.62,color=LINE,width=.7,head=None)
    text(s,cols[0]+.14,y+.035,1.52,.65,row['type'],size=18,bold=True)
    testing_icon(s,cols[1]+.12,y+.17,row['icon'])
    text(s,cols[1]+.67,y+.035,1.92,.65,row['what'],size=18,bold=True)
    text(s,cols[2]+.14,y+.035,7.35,.65,row['how'],size=18)
    group=s.shapes.add_group_shape(list(s.shapes)[start:]);group.name=f"Test {i+1} - {row['icon']}";groups.append(group)
records[-1]['testing_rows']=testing_rows
records[-1]['testing_headers']=['Testing type','What will be tested','How it will be tested']
records[-1]['animation']=add_click_fades(s,groups,duration_ms=350)
note(s,'Abdelrahman',55,
     'Each test has a specific input and expected check. First, compare urgency and first aid with clinician-reviewed answers, counting missed Red cases. Second, change Building 12 to 21 and delay the Building 12 map response: it must not overwrite the corrected location. Third, make ambulance A busy, B missing equipment and C suitable: select C, or alert staff when C is removed. Fourth, replay English, Egyptian Arabic and mixed calls, checking facts and measuring the first meaningful reply. Fifth, test a second-attempt confirmation, three failed attempts and a lost confirmation: stop retries, alert staff and prevent duplicates. Finally, try sending before reviewer approval: nothing is sent. Obtain approval, then send the approved request.',
     'Reveal the six rows in order with six clicks. Point to the action and expected output in the last column. Allow about eight seconds per row plus a short introduction. The first meaningful reply has a target below 1.5 seconds, not a measured result.',
     'The following table estimates the cost of running a small test programme.',
     'Are the clinical answers produced by the same model being tested? No. Qualified reviewers must approve the reference urgency labels and first-aid answers before evaluation. Missed Red cases are those with a reviewed Red label that the prototype labels Yellow or Green. The three ambulances are fictional test records. Delivery confirmation and simulated ambulance assignment are checked separately. The approval test checks the single reviewer role; it does not introduce another user role.',
     'Thesis §§1.4 and 3.1, PDF pp.12, 35–36. These six concrete examples cover medical-reference checks, corrected information and late results, availability/equipment constraints, language and reply timing, bounded retries and duplicates, and authorization. Additional cases include noise, unknown addresses, interrupted calls and staff takeover. Check speech transcripts against the known script separately from extracted patient facts; report median and p95 reply time by language. Log model tokens, speech/telephone usage and notification attempts to calculate measured cost. A receipt is generated only after the test receiver accepts the request. The delivery test uses one request ID across attempts, including a delivered request whose return confirmation is lost. No dataset size, achieved accuracy or completed clinical test is claimed. See testing-evidence.json.')

# 12 — Estimated test usage using official prices verified on 24 November 2026.
s = new_slide('Cost analysis — estimated test budget', '100 five-minute test calls · USD before tax · prices checked 24 November 2026')
rows=[['Component / feature','Estimate','Price source / basis'],
      ['Models: 3 agent roles','$1.88','OpenAI GPT-5.4 mini · 1M input + 250k output tokens\nStandard: $0.75/M input; $4.50/M output'],
      ['Live transcription','$8.50','OpenAI GPT-Live-Transcribe · 500 audio minutes\n$0.017 per minute'],
      ['Spoken replies','$0.00','Google Chirp 3: HD · 100,000 characters\nWithin 1M free characters/month; then $30/M'],
      ['Telephone + gateway','$7.40','Twilio US · 500 call min + 500 gateway min + number\n$0.0085/min + $0.004/min + $1.15/month'],
      ['Location + travel time','$0.00','Google Maps · 200 geocodes + 1,000 matrix elements\n10k free events/month per service; first paid tier: $5/1k'],
      ['Backend + storage','$0.00','Self-hosted Python / FastAPI / LiveKit / Chroma\nNo licence charge; existing PC and internet assumed'],
      ['Estimated total','$17.78','Google free caps assumed unused. US route; Egypt quote needed.']]
t=native_table(s,.58,2.12,[3.00,1.25,7.90],[.48]+[.66]*6+[.42],rows,font_size=18,header_size=19)
for cell in t.rows[len(rows)-1].cells:
    cell.fill.solid();cell.fill.fore_color.rgb=rgb(NAVY)
    for p in cell.text_frame.paragraphs:
        p.font.bold=True;p.font.color.rgb=rgb(WHITE);p.font.size=Pt(17)
for row_index,url in [(1,'https://developers.openai.com/api/docs/pricing'),
                      (2,'https://developers.openai.com/api/docs/models/gpt-live-transcribe'),
                      (3,'https://cloud.google.com/text-to-speech/pricing'),
                      (4,'https://www.twilio.com/en-us/voice/pricing/us'),
                      (5,'https://developers.google.com/maps/billing-and-pricing/pricing')]:
    for run in t.cell(row_index,2).text_frame.paragraphs[0].runs:
        run.hyperlink.address=url
        run.font.color.rgb=rgb(INK)
records[-1]['cost_assumptions_file']='pricing-assumptions.json'
records[-1]['cost_status']='Official unit prices verified 24 November 2026; usage and provider choices are estimates'
records[-1]['estimated_scenario_usd']=17.78
note(s,'Abdelrahman',45,
     'This estimate uses official prices checked on 24 November for 100 five-minute test calls. The model-token allowance covers all three roles. We budget live transcription and both the telephone and SIP connection legs. Speech generation and map usage fit within the stated monthly free allowances, assuming those allowances are unused. The total is 17 dollars and 78 cents before tax. Existing equipment and internet are assumed. This is a US test route; an Egyptian hospital line needs its own quote. Providers are costing candidates, and actual usage will be measured.',
     'State the test scenario, total and free-allowance assumption. Explain one row; distinguish a test-route estimate from an Egypt quote.',
     'The remaining design work is scheduled against the confirmed submission date.',
     'Is $17.78 a confirmed bill or production budget? No. Unit prices were checked, but this is a fixed test scenario with unused Google free caps. At the first paid tiers without those free caps, the same usage is about $26.78 before tax. Actual usage, provider selection and local routing change the cost.',
     'Official price pages retrieved successfully on 24 November 2026. OpenAI standard GPT-5.4 mini: $0.75/M input and $4.50/M output; GPT-Live-Transcribe: $0.017/min. Google Chirp 3 HD: 1M free characters/month, then $30/M. Google Geocoding and Route Matrix Essentials: 10k free events/month/SKU, first paid tier $5/1k. Twilio US inbound: $0.0085/min; SIP leg: $0.004/min; local number: $1.15/month. Links in table cells and pricing-assumptions.json identify sources. Model token allowance includes reasoning and all agent roles. Arabic voice availability is not proof of Egyptian-dialect suitability. Self-hosted backend excludes hosting, equipment, internet and electricity. Previous example models were removed after the pricing page marked them deprecated.')

# 13 — Wide editable Gantt, faithfully grouping the original 11 tasks.
s = new_slide('Timetable — responsibilities', 'One proposed accountable lead per task · submission: 17 January 2027')
x0=6.05;cw=.83
for j,label in enumerate(['23 Nov','30 Nov','7 Dec','14 Dec','21 Dec','28 Dec','4 Jan','11 Jan']):
    text(s,x0+j*cw,2.15,cw,.29,label,size=14,color=NAVY,bold=True,align=PP_ALIGN.CENTER)
    rect(s,x0+j*cw,2.57,cw-.025,4.04,WHITE if j%2==0 else PALE)
text(s,.60,2.15,3.65,.30,'Task',size=17,color=NAVY,bold=True)
text(s,4.35,2.15,1.52,.30,'Lead',size=17,color=NAVY,bold=True)
tasks=[('Scope and requirements','Omar',0,1),
       ('Guidance and bilingual cases','Omar',1,2),
       ('Telephone and speech','Abdelrahman',1,2),
       ('Controller and agent interfaces','Omar',3,1),
       ('Location and ambulance rules','Omar',4,1),
       ('Dashboard and test receiver','Abdelrahman',4,1),
       ('Privacy, safety and cost','Abdelrahman',5,1),
       ('Evaluation and test scenarios','Omar',5,1),
       ('Integrated design review','Abdelrahman',6,1),
       ('Final report and submission','Omar',7,1),
       ('Report and decision log','Abdelrahman',0,8)]
for i,(label,lead,start,duration) in enumerate(tasks):
    y=2.66+i*.35
    text(s,.60,y,3.65,.31,label,size=17,bold=True)
    text(s,4.35,y,1.52,.31,lead,size=17,color=GRAY)
    rect(s,x0+start*cw+.055,y+.085,duration*cw-.14,.18,GREEN if lead=='Omar' else DARKGREEN,radius=True)
text(s,.65,6.78,8.0,.29,'Leads own the deliverable; peer review remains shared.',size=17,color=GRAY)
text(s,8.90,6.78,3.78,.29,'14–16 Jan: correction buffer',size=17,color=DARKGREEN,bold=True,align=PP_ALIGN.RIGHT)
records[-1]['task_leads']=[{'task':t,'lead':lead,'start_week':start,'weeks':duration} for t,lead,start,duration in tasks]
note(s,'Abdelrahman',60,
     'The dates retain the thesis schedule through the confirmed 17 January deadline. The proposed presentation allocation gives each deliverable one accountable lead. Omar owns scope, guidance and bilingual cases, controller interfaces, location rules, evaluation scenarios and the final report. Abdelrahman owns telephone and speech, the dashboard and receiver, privacy and costing, integration review and the decision log. This is six deliverables for Omar and five for Abdelrahman; peer review still happens across the team. The parallel rows show work that can happen together. Dates and owners are proposed, with a 14–16 January correction buffer. Omar will finish with the main challenges and conclusion.',
     'Point to the Lead column and two parallel task pairs. Each row has one accountable owner. Handoff back to Omar after the confirmed deadline.',
     'The plan also depends on resolving several technical and clinical constraints.',
     'Does 17 January mean a clinically validated deployed service? No. It is the confirmed Grad I submission deadline for the scheduled work.',
     'Thesis Chapter 4 and time-plan-tasks.json. Source task groups: T1; T2+T3; T4; T5+T6; T7+T8; T9+T10; T11 ongoing. No T-codes appear on the slide.')

# 14 — Planned responses, not claims that problems have already been solved.
s = new_slide('Limitations & challenges', 'Planned controls for the prototype’s main failure cases', 'Thesis §§3.1–3.1.2 and Chapter 5. Qualified review and authorized test access remain prerequisites.')
for x,w,label in [(.60,4.14,'Challenge'),(4.74,8.0,'Planned response')]:
    rect(s,x,2.20,w,.57,NAVY)
    text(s,x+.17,2.31,w-.34,.35,label,size=23,color=WHITE,bold=True)
for i,(challenge,response) in enumerate([
    ('Noisy or mixed-language speech','Separate speech-recognition errors from\nerrors in interpreting a correct transcript.'),
    ('Missing symptoms or location','Ask focused questions; preserve unknowns;\nallow staff takeover.'),
    ('Service failures or outdated results','Reject stale results; limit retries;\nprevent duplicate dispatch requests.')]):
    y=2.77+i*1.02
    rect(s,.60,y,4.14,1.02,MINT,stroke=LINE)
    rect(s,4.74,y,8.0,1.02,WHITE,stroke=LINE)
    text(s,.79,y+.19,3.76,.76,challenge,size=24,bold=True)
    text(s,4.94,y+.16,7.60,.80,response,size=24)
tag(s,.60,6.25,12.13,'Before hospital testing: authorization • reviewed urgency labels • reviewed first-aid sources',size=19)
note(s,'Omar',45,
     'The main risks are misunderstandings in noisy or mixed-language speech, missing facts or an uncertain location, and failures across connected services. The proposed controls are separate speech-versus-interpretation tests, focused clarification, explicit unknown fields, and access to staff. For late or failed service results, the controller checks whether the incident has changed and manages bounded retries with one request identifier. These are design requirements to implement and verify. Before a hospital demonstration, the team still needs authorization and qualified review of urgency criteria, first-aid sources, and test scenarios.',
     'Use “planned response” and “will test”; do not say the prototype has already solved these problems.',
     'Our conclusion is therefore about progress, the proposed approach, and the next steps.',
     'Is the prototype ready for unsupervised emergencies? No. The documented scope is authorized simulation and staff review.',
     'Thesis requirements and initial conclusion; international guidance does not establish local legal compliance.')

# 15 — Mirrors the thesis's three conclusion paragraphs.
s = new_slide('Conclusion', 'Progress so far • proposed approach • next steps', 'Thesis Chapter 5. Prototype performance and clinical benefit have not yet been established.')
for x,title,body in [
    (.60,'Progress so far','Problem and gap defined.\nSix studies reviewed.\nPreliminary design prepared.'),
    (4.80,'Proposed approach','Three agents + controller.\nOne incident record.\nStaff-approved notifications.'),
    (9.00,'Next steps','Detail the design.\nReview guidance and costs.\nBuild and evaluate.')]:
    rect(s,x,2.22,3.73,2.77,MINT,stroke=LINE,radius=True)
    text(s,x+.18,2.46,3.37,.48,title,size=27,bold=True)
    text(s,x+.18,3.18,3.37,1.57,body,size=23)
rect(s,.60,5.49,12.13,.95,NAVY,radius=True)
text(s,.88,5.71,11.57,.58,'From an emergency call to a reviewable, acknowledged request.',size=29,color=WHITE,align=PP_ALIGN.CENTER)
note(s,'Omar',35,
     'We have defined the problem, reviewed six studies, and prepared requirements and preliminary diagrams. Our proposed approach connects three agents, a Python controller, and staff approval. Next come detailed design, tool selection, clinical review, costing, implementation, and simulated-call evaluation. The contribution is a reviewable path from call to acknowledged request. Thank you; we welcome your questions.',
     'Return to the opening purpose. Stop the prepared narrative at or before 12:45.',
     'Questions and discussion.',
     'What have you actually completed? Research review and preliminary design/documentation; implementation and evaluation are future work.',
     'Thesis Chapter 5, preserving its three-part structure without fabricated results.')

# 16 — Reserved within the 15-minute ceiling, not an extra presentation segment.
s = new_slide('Thank you', '', cover=True, layout=body_layout)
rect(s,0,2.05,SW,5.40,WHITE)
rect(s,6.00,1.58,SW-6.00,.47,WHITE)
text(s,.75,2.76,11.83,1.07,'Thank you',size=52,color=NAVY,align=PP_ALIGN.CENTER,font=DISPLAY)
text(s,.75,4.15,11.83,.75,'Any questions?',size=32,color=DARKGREEN,align=PP_ALIGN.CENTER)
text(s,12.20,7.16,.55,.27,str(MAIN_SLIDE_COUNT),size=14,color=NAVY,align=PP_ALIGN.RIGHT)
note(s,'Both',135,
     'This slide starts the question period. The planned talk ends at 12:45, leaving 2:15 inside the 15-minute maximum. Keep answers focused and open the separate appendix only when it helps. If questions are handled separately by the committee, the prepared talk still remains below the limit.',
     'Listen fully. Let the presenter responsible for a topic answer first, then add only missing information. State uncertainty honestly.',
     '',
     'Separate appendix pages: 1 guidance; 2 evaluation definitions; 3 controller and role choice; 4 sources/publication status.',
     'Both presentation rubrics emphasize understanding, concise answers, confidence, and audience engagement. Suggested speaking assignments are editable.')

# 17–20 — Backup, not part of the timed prepared narrative.
s = new_slide('Industrial standards', 'Backup: guidance applied to the proposed requirements', 'Thesis §§2.8 and 3.1.1. Names retained as design guidance; no standards bibliography citations.',backup=True)
rows=[('NIST AI RMF 1.0','Risk records, review responsibilities and failure tests.'),
      ('NIST AI 600-1','Check invented facts, unsupported advice and summaries.'),
      ('WHO health-AI guidance','Medical review, human oversight and language fairness.'),
      ('W3C WebRTC 1.0','Browser media connections in the proposed LiveKit path.'),
      ('NIST Privacy Framework 1.0','Minimize data; define access, consent and retention.')]
rect(s,.60,2.19,4.20,.52,NAVY);rect(s,4.80,2.19,7.93,.52,NAVY)
text(s,.79,2.28,3.82,.34,'Standard',size=23,color=WHITE,bold=True)
text(s,5.00,2.28,7.53,.34,'Use in the proposed design',size=23,color=WHITE,bold=True)
for i,(a,b) in enumerate(rows):
    y=2.71+i*.65
    rect(s,.60,y,4.20,.65,MINT,stroke=LINE)
    rect(s,4.80,y,7.93,.65,WHITE,stroke=LINE)
    text(s,.79,y+.14,3.82,.43,a,size=22,bold=True)
    text(s,5.00,y+.14,7.53,.43,b,size=22)
text(s,.65,6.29,12.0,.36,'These frameworks, guidance and specifications do not establish certification or legal compliance.',size=20,color=GRAY)
note(s,'Both',0,'Use only if asked about industrial standards, ethics, privacy, or professional context.',
     'Web Audio API is intentionally excluded; the thesis keeps WebRTC because the proposal names it.',
     qa='Why these references? They come from the guide’s AI-track or shared personal-data entries and map to actual design decisions.',
     sources='Current thesis standards sections; no numeric standards citations or standards bibliography entries, following the user’s requested format.')

s = new_slide('Evaluation definitions', 'Backup: measure different outcomes with different clocks', 'Thesis objectives and §3.1. Design target <1.5 s applies to meaningful spoken reply.',backup=True)
defs=[('Spoken reply delay','End of caller turn → first meaningful audible reply.'),
      ('Report preparation','Time to a staff-reviewable incident report.'),
      ('Notification delivery','Approved sending → receiver confirmation.'),
      ('Urgency performance','Reviewed labels; confusion matrix and missed urgent cases.'),
      ('Reliability','Interrupted calls, delayed results, failures and duplicate count.')]
for i,(a,b) in enumerate(defs):
    y=2.16+i*.77
    node(s,.60,y,12.13,.64,a,title_size=22,fill=MINT if i%2==0 else WHITE)
    text(s,4.12,y+.14,8.35,.40,b,size=22)
tag(s,.60,6.31,12.13,'A receiver receipt is not evidence of ambulance departure.',size=22)
note(s,'Both',0,'Use to clarify latency, accuracy, and delivery outcomes.',
     'Do not compare DispatchMAS transcript pacing or TriAgent case runtimes directly with our spoken-reply target.',
     qa='Are paper accuracies the benchmark target? They provide context under different labels, inputs and datasets. We will evaluate against reviewed prototype scenarios.',
     sources='Thesis §§1.2–1.4, §3.1 and Chapter 2 summary.')

s = new_slide('Why three agents and a software controller?', 'Backup: roles separate responsibilities; software enforces state and approval', 'Thesis §§1.5 and 3.1. More agents are not assumed to improve every metric.',backup=True)
node(s,.60,2.22,5.86,3.32,'Agent roles',
     'Conversation: speak and collect facts.\nTriage: urgency and reviewed guidance.\nCoordination: location, resources and report.',fill=MINT,title_size=28,detail_size=24)
node(s,6.88,2.22,5.86,3.32,'Python controller',
     'Keep one incident record.\nRun only affected tasks.\nReject outdated results.\nEnforce approval, retries and request IDs.',fill=WHITE,title_size=28,detail_size=24)
tag(s,.60,6.04,12.13,'The same underlying model may serve multiple roles. Final model selection is still planned.',size=21)
note(s,'Both',0,'Use when asked about the agent count, model choices, context, or controller design.',
     'Explain one corrected-address example: a late lookup using the old update must not overwrite the confirmed new address.',
     qa='Is the controller another AI agent? No. It is ordinary Python software. Is a single-agent comparison mandatory? The current committed evaluation does not include an implemented single-agent baseline; no agent-count superiority is claimed.',
     sources='Thesis §§1.4–1.5 and §3.1. Tool choices in the proposal remain preliminary.')

s = new_slide('References & publication status', 'Backup: sources for the two literature slides', 'Research citations use IEEE numeric style. Full research bibliography remains in the thesis.',backup=True)
text(s,.62,2.17,12.05,1.43,
     '[1] X. Li et al., “DispatchMAS: Fusing taxonomy and artificial intelligence agents for emergency medical services,” BMC Emergency Medicine, vol. 26, art. 78, 2026.\nDOI: 10.1186/s12873-026-01540-9',size=23)
text(s,.62,4.04,12.05,1.54,
     '[2] A. Ibrahim, A. AlSanousi, and A. Serag, “TriAgent: An adaptive multi-agent architecture for crisis clinical decision support under incomplete information,” AI, vol. 7, art. 230, 18 June 2026.\nDOI: 10.3390/ai7060230',size=23)
tag(s,.62,6.20,12.05,'Project publication status: no project publication is reported in the current thesis.',size=20)
note(s,'Both',0,'Reference slide and publication-status disclosure; do not narrate unless asked.',
     'The two cited papers are reviewed prior work, not publications by the project team.',
     qa='Why only two papers on the slides? Six are reviewed in the thesis. These two directly support emergency-call simulation and controlled work under incomplete information, allowing depth within 15 minutes.',
     sources='Original supplied paper PDFs and thesis §§2.6–2.7. DispatchMAS publication year is verified; the supplied PDF does not print publication day/month. TriAgent prints Published: 18 June 2026.')


# A manual presentation, with rehearsed timing in notes, not forced auto-advance.
elapsed = 0
for rec,slide in zip(records,prs.slides):
    if not rec['backup']:
        rec['start_seconds']=elapsed
        elapsed += rec['seconds']
        rec['end_seconds']=elapsed
    for shape in slide.shapes:
        if shape.has_text_frame:
            for p in shape.text_frame.paragraphs:
                pPr=p._p.get_or_add_pPr()
                pPr.set('rtl','0')
    # Skip backup slides in an ordinary slide show; they remain available for Q&A.
    slide._element.set('show','0' if rec['backup'] else '1')
assert elapsed == 900
assert sum(r['seconds'] for r in records[:MAIN_SLIDE_COUNT-1]) == 765
assert sorted(n for pair in records[2]['objective_pairs'] for n in pair)==list(range(1,9))
prs.core_properties.title='Agentic Emergency Tele-Triage & Autonomous Medical Dispatch System — Midterm'
prs.core_properties.subject='Graduation Project I presentation based on the current thesis and both supplied rubrics'
prs.core_properties.author='Omar Mostafa Omar; Abdelrahman Mahmoud Ali'
prs.core_properties.keywords='Midterm; MSA; three agents; staff-approved dispatch; proposed prototype'
prs.core_properties.comments='Uploaded template masters retained; main narrative 12:45; Q&A 2:15; separate four-slide appendix.'
prs.core_properties.created=datetime(2026,11,24,12,0,tzinfo=timezone.utc)
prs.core_properties.modified=datetime(2026,11,25,12,0,tzinfo=timezone.utc)

from io import BytesIO
buffer=BytesIO();prs.save(buffer);data=buffer.getvalue()
main=Presentation(BytesIO(data))
for entry in list(main.slides._sldIdLst)[MAIN_SLIDE_COUNT:]:
    main.part.drop_rel(entry.rId);main.slides._sldIdLst.remove(entry)
appendix=Presentation(BytesIO(data))
for entry in list(appendix.slides._sldIdLst)[:MAIN_SLIDE_COUNT]:
    appendix.part.drop_rel(entry.rId);appendix.slides._sldIdLst.remove(entry)
for slide in appendix.slides:slide._element.set('show','1')
appendix.core_properties.title='Uni-Grad — Midterm supporting appendix'
target=OUT/'Uni-Grad - Midterm Presentation.pptx'
main.save(target);appendix.save(OUT/'Uni-Grad - Appendix.pptx')
(ROOT/'slide-content-and-notes.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
print('Saved',target)
print('Main deck: 17 slides ending with Thank you / Any questions; separate 4-slide appendix.')
print('Prepared narrative: 12:45; reserved Q&A: 2:15; total:',elapsed,'seconds')
print('Suggested speaking:',{speaker:sum(r['seconds'] for r in records[:MAIN_SLIDE_COUNT-1] if r['speaker']==speaker) for speaker in ['Omar','Abdelrahman']})
