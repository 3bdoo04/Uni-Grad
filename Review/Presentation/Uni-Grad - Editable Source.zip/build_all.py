"""Rebuild PowerPoint, PDF previews, audits, and rehearsal guide."""
from pathlib import Path
from xml.sax.saxutils import escape
import os
import shutil
import subprocess
import sys
import tempfile

r=Path(__file__).parent
def run(args,env=None):
    subprocess.run(args,cwd=r,env=env,check=True)
run([sys.executable,'build_presentation.py'])
soffice=shutil.which('soffice') or shutil.which('libreoffice')
if not soffice:
    raise SystemExit('PowerPoint created. Export it to PDF in PowerPoint, or install LibreOffice to run the PDF/audit steps.')
env=os.environ.copy()
if Path('/etc/fonts/fonts.conf').exists():
    config=r/'fonts/fonts.conf'
    config.write_text('<?xml version="1.0"?><!DOCTYPE fontconfig SYSTEM "urn:fontconfig:fonts.dtd"><fontconfig>'
        '<include>/etc/fonts/fonts.conf</include><dir>'+escape(str(r/'fonts'))+'</dir>'
        '<cachedir>'+escape(str(r/'font-cache'))+'</cachedir>'
        '<alias><family>Calibri</family><prefer><family>Carlito</family></prefer></alias>'
        '<alias><family>Calibri Light</family><prefer><family>Carlito</family></prefer></alias>'
        '<alias><family>Arial</family><prefer><family>Noto Sans Arabic</family></prefer></alias></fontconfig>')
    env['FONTCONFIG_FILE']=str(config)
with tempfile.TemporaryDirectory(prefix='uni-grad-office-') as profile:
    for name in ['Uni-Grad - Midterm Presentation.pptx','Uni-Grad - Appendix.pptx']:
        run([soffice,'-env:UserInstallation='+Path(profile).as_uri(),'--headless',
             '--convert-to','pdf:impress_pdf_Export:{"ExportHiddenSlides":{"type":"boolean","value":"false"}}',
             '--outdir',str(r/'output'),str(r/'output'/name)],env)
run([sys.executable,'make_animation_preview.py'],env)
run([sys.executable,'make_contributions_preview.py'],env)
run([sys.executable,'make_testing_preview.py'],env)
run([sys.executable,'make_block_diagram_preview.py'],env)
run([sys.executable,'verify_deck_reveals.py'])
run([sys.executable,'validate_presentation.py'])
run([sys.executable,'make_rehearsal_guide.py'])

run([sys.executable,'package_review.py'])
