"""Apply a consistent chrome-first, progressive-body animation policy.

The original background/master, title, green subtitle and page number are never
animated. Logical cards, existing figures, rows and native tables are revealed
as units. Grouping moves existing elements without changing their geometry or
styling; native tables remain intact. Existing authored animation order is kept.
"""
from math import hypot
from copy import deepcopy
from pptx.enum.shapes import MSO_SHAPE_TYPE
from pptx.oxml.ns import qn
from animation_tools import add_click_fades

EMU = 914400
TOL = int(.035 * EMU)


def _bounds(shape):
    return shape.left, shape.top, shape.left + shape.width, shape.top + shape.height


def _contains(outer, inner, tolerance=TOL):
    a, b, c, d = _bounds(outer)
    x, y, z, w = _bounds(inner)
    # Text helpers reserve extra descender room; keep such labels with their
    # visible card when the text frame extends a few pixels beyond its border.
    vertical=max(tolerance,int(.08*EMU))
    return a-tolerance <= x and b-vertical <= y and c+tolerance >= z and d+vertical >= w


def _split_native_tables(slide):
    """Preserve native table cells/styles while revealing one row per event."""
    tree=slide.shapes._spTree
    for shape in list(slide.shapes):
        if not getattr(shape,'has_table',False) or len(shape.table.rows)<=1:
            continue
        original=shape._element
        table=original.find('.//'+qn('a:tbl'))
        rows=list(table.findall(qn('a:tr')))
        heights=[row.height for row in shape.table.rows]
        insertion=list(tree).index(original)
        next_id=max(int(x) for x in slide._element.xpath('.//p:cNvPr/@id'))+1
        offset=shape.top
        for i,(row,height) in enumerate(zip(rows,heights)):
            frame=deepcopy(original)
            props=frame.find('.//'+qn('p:cNvPr'))
            props.set('id',str(shape.shape_id if i==0 else next_id+i-1))
            props.set('name',f'Reveal - {shape.name} row {i+1}')
            transform=frame.find(qn('p:xfrm'))
            transform.find(qn('a:off')).set('y',str(offset))
            transform.find(qn('a:ext')).set('cy',str(height))
            cloned=frame.find('.//'+qn('a:tbl'))
            for old in list(cloned.findall(qn('a:tr'))):cloned.remove(old)
            cloned.append(deepcopy(row))
            cloned.find(qn('a:tblPr')).set('firstRow','1' if i==0 else '0')
            tree.insert(insertion+i,frame)
            offset+=height
        tree.remove(original)


def _group(slide, members, name):
    """Group existing shapes in their original drawing order and z position."""
    members = list({shape.shape_id:shape for shape in members}.values())
    if len(members) == 1:
        return members[0]
    tree = slide.shapes._spTree
    original_order = {id(el): i for i, el in enumerate(tree)}
    members.sort(key=lambda s: original_order[id(s._element)])
    position = original_order[id(members[0]._element)]
    result = slide.shapes.add_group_shape(members)
    result.name = name
    tree.remove(result._element)
    tree.insert(position, result._element)
    return result


def _anchor(shape):
    """A visible card background, not a connector, text box, table or stripe."""
    return (shape.shape_type == MSO_SHAPE_TYPE.AUTO_SHAPE
            and shape.width >= .50 * EMU and shape.height >= .25 * EMU
            and not getattr(shape, 'has_table', False)
            and not (getattr(shape, 'has_text_frame', False) and shape.text.strip()))


def _line(shape):
    return shape.shape_type == MSO_SHAPE_TYPE.LINE


def _line_points(shape):
    x1, y1, x2, y2 = _bounds(shape)
    xfrm = shape._element.spPr.xfrm
    if xfrm is not None:
        if xfrm.get('flipH') in ('1', 'true'):
            x1, x2 = x2, x1
        if xfrm.get('flipV') in ('1', 'true'):
            y1, y2 = y2, y1
    return (x1, y1), (x2, y2)


def _touching(a, b):
    return min(hypot(x-u, y-v) for x, y in _line_points(a)
               for u, v in _line_points(b)) < .045 * EMU


def _timing_off(slide):
    for node in list(slide._element.findall(qn('p:timing'))):
        slide._element.remove(node)


def _timeline_elements(slide, body):
    """Keep the Gantt grid together and reveal each actual task row."""
    unused = list(body)
    grid = [s for s in unused if (s.top < 2.58*EMU or
            (s.left >= 5.9*EMU and s.height > 3.5*EMU))]
    events = []
    if grid:
        events.append(_group(slide, grid, 'Reveal - timetable headings and grid'))
        unused = [s for s in unused if s not in grid]
    for i in range(11):
        y = (2.66+i*.35)*EMU
        row = [s for s in unused if y-.02*EMU <= s.top <= y+.15*EMU]
        if row:
            events.append(_group(slide, row, f'Reveal - timetable task {i+1}'))
            unused = [s for s in unused if s not in row]
    if unused:
        events.append(_group(slide, unused, 'Reveal - timetable notes'))
    return events


def _visual_elements(slide, body, title=''):
    """Find card/row units while preserving geometry and native tables."""
    if not body:
        return []
    if 'Timetable' in title:
        return _timeline_elements(slide, body)
    original_order = {s.shape_id: i for i, s in enumerate(slide.shapes)}
    remaining = list(body)
    elements = []

    # Existing authored groups are already logical units. Tables must remain
    # native top-level graphic frames so later price edits stay straightforward.
    atomic = [s for s in remaining if s.shape_type == MSO_SHAPE_TYPE.GROUP
              or getattr(s, 'has_table', False)]
    elements.extend(atomic)
    remaining = [s for s in remaining if s not in atomic]

    anchors = [s for s in remaining if _anchor(s)]
    # Outer panels own their contained labels/stripes. Disjoint cards cannot
    # obscure each other when grouped back at the earliest original position.
    anchors = [a for a in anchors if not any(a is not b and _contains(b, a)
               and b.width*b.height > a.width*a.height+TOL*TOL for b in anchors)]
    anchors.sort(key=lambda s: original_order[s.shape_id])
    card_records = []
    for anchor in anchors:
        if anchor not in remaining:
            continue
        members = [s for s in remaining if _contains(anchor, s)]
        # A corner marker overlapping a card by a few pixels belongs to it.
        members = members or [anchor]
        result = _group(slide, members, 'Reveal - card')
        card_records.append(result)
        remaining = [s for s in remaining if s not in members]

    # Adjacent cells in a drawn table form one row. Real cards separated by a
    # gutter, such as the literature panels, remain independent.
    row_cards = []
    while card_records:
        first = card_records.pop(0)
        row = [first]
        for other in list(card_records):
            same_y = abs(other.top-first.top) < .025*EMU
            same_h = abs(other.height-first.height) < .04*EMU
            touching = min(abs(first.left+first.width-other.left),
                           abs(other.left+other.width-first.left)) < .025*EMU
            if same_y and same_h and touching:
                row.append(other);card_records.remove(other)
        row_cards.append(_group(slide, row, 'Reveal - table row') if len(row)>1 else first)
    elements.extend(row_cards)

    # Consecutive connected line segments are one polyline arrow, not separate
    # half-arrows. Short branch labels travel with the same connector.
    polylines = []
    i = 0
    while i < len(remaining):
        current = remaining[i]
        if not _line(current):
            i += 1;continue
        members = [current];j = i+1
        while j < len(remaining) and _line(remaining[j]) and _touching(members[-1], remaining[j]):
            members.append(remaining[j]);j += 1
        polylines.append(members);i = j
    used_lines = {s.shape_id for path in polylines for s in path}
    remaining = [s for s in remaining if s.shape_id not in used_lines]
    if 'flowchart' in title.lower():
        for shape in list(remaining):
            label = shape.text.strip() if getattr(shape, 'has_text_frame', False) else ''
            if not label or len(label)>35:
                continue
            sx, sy = shape.left+shape.width/2, shape.top+shape.height/2
            distances = []
            for path in polylines:
                dist = min(hypot(sx-(line.left+line.width/2), sy-(line.top+line.height/2)) for line in path)
                distances.append(dist)
            if distances and min(distances) < 1.1*EMU:
                idx = distances.index(min(distances))
                polylines[idx].append(shape);remaining.remove(shape)
    for index, path in enumerate(polylines):
        elements.append(_group(slide, path, f'Reveal - connector {index+1}'))

    # Publication/date and author metadata share a short horizontal band.
    upper = [s for s in remaining if 1.7*EMU <= s.top < 2.55*EMU and s.height < .6*EMU]
    if len(upper)>1:
        elements.append(_group(slide, upper, 'Reveal - metadata band'))
        remaining = [s for s in remaining if s not in upper]
    elements.extend(remaining)
    # Include the short date tag card as well as the adjacent author text.
    # Neither a full card nor a table is swept into this metadata-band group.
    upper_elements = [s for s in elements if 1.7*EMU <= s.top < 2.55*EMU
                      and s.height < .6*EMU and not getattr(s, 'has_table', False)]
    if len(upper_elements)>1:
        band = _group(slide, upper_elements, 'Reveal - metadata band')
        elements = [s for s in elements if s not in upper_elements]+[band]
    if 'flowchart' in title.lower():
        def words(shape):
            if shape.shape_type==MSO_SHAPE_TYPE.GROUP:
                return ' '.join(words(child) for child in shape.shapes)
            return shape.text.replace('\n',' ') if getattr(shape,'has_text_frame',False) else ''
        def named(fragment):return next(x for x in elements if fragment in words(x))
        def at(x,y):return next(s for s in elements if abs(s.left/EMU-x)<.04 and abs(s.top/EMU-y)<.04)
        # Follow the actual call path and then its approval/receipt branches,
        # rather than revealing the highest diamond before the incoming call.
        ordered=[named('Incoming call'),at(2.65,2.625),named('Collect facts'),at(6.40,2.625),
                 named('Confirm location'),at(10.30,2.625),named('Staff approves?'),
                 named('Clarify / staff takeover'),at(12.30,2.625),named('Send approved'),
                 at(8.70,4.875),named('Receipt received?'),at(5.62,4.51),named('Log receipt'),
                 at(7.55,5.60),named('Alert staff')]
        assert len(ordered)==len(elements) and {s.shape_id for s in ordered}=={s.shape_id for s in elements}
        return ordered
    # Reading order is stable for cards and figures; geometry is untouched.
    return sorted(elements, key=lambda s: (round(s.top/(.12*EMU)), s.left))


def apply_deck_reveals(prs, records):
    """Animate body units after static chrome; return one audit per slide.

    Optional ``record['static_body_shape_ids']`` adds intentional framing to the
    static chrome. Existing authored groups keep their relative order; extras
    above the core precede it, except block diagrams whose legend comes last.
    ``record['extra_reveal_order']`` may explicitly be ``prepend`` or ``append``.
    """
    assert len(prs.slides) == len(records)
    audits = []
    for index, (slide, record) in enumerate(zip(prs.slides, records)):
        whole = index == 0 or record.get('title', '').strip().casefold() in ('thank you', 'timetable — responsibilities')
        if whole:
            _timing_off(slide)
            record.pop('animation', None)
            policy = {'mode':'whole_slide','body_events':0,'title_subtitle_number_together':True}
            record['body_reveal_policy'] = policy
            audits.append({'slide':index+1, **policy})
            continue
        chrome = {s.shape_id for s in list(slide.shapes)[:3]}
        chrome.update(record.get('static_body_shape_ids', []))
        _split_native_tables(slide)
        original = dict(record.get('animation', {}))
        authored_ids = [x['shape_id'] for x in original.get('groups', [])]
        shapes_by_id = {s.shape_id:s for s in slide.shapes}
        assert all(i in shapes_by_id for i in authored_ids), (index+1, authored_ids)
        core = [shapes_by_id[i] for i in authored_ids]
        body = [s for s in slide.shapes if s.shape_id not in chrome and s.shape_id not in authored_ids]
        extras = _visual_elements(slide, body, record.get('title', ''))
        if core:
            if record.get('extra_reveal_order') == 'prepend':
                before, after = extras, []
            elif record.get('extra_reveal_order') == 'append' or 'block_diagram' in record:
                before, after = [], extras
            else:
                top = min(g.top for g in core)
                before = [g for g in extras if g.top+g.height <= top+.035*EMU]
                after = [g for g in extras if g not in before]
            events = before+core+after
        else:
            before, after = [], []
            events = extras
        assert events, ('No animated body elements', index+1)
        current_body = {s.shape_id for s in slide.shapes if s.shape_id not in chrome}
        assert current_body == {s.shape_id for s in events}, (index+1, current_body, [s.shape_id for s in events])
        _timing_off(slide)
        record['animation'] = add_click_fades(slide, events, duration_ms=original.get('duration_ms', 250))
        policy = {'mode':'progressive_body','chrome_shape_ids':sorted(chrome),
                  'title_subtitle_number_together':True,'body_events':len(events),
                  'native_tables':'one native table row per reveal','authored_events_preserved':len(core),
                  'prepended_events':len(before),'appended_events':len(after) if core else 0}
        record['body_reveal_policy'] = policy
        audits.append({'slide':index+1, **policy})
    return audits
