"""Export slide 11's four native click builds and portable review previews."""
from pathlib import Path
from copy import deepcopy
from io import BytesIO
import json, os, shutil, subprocess, tempfile, zipfile
from pptx import Presentation
from PIL import Image
from lxml import etree
import fitz

r=Path(__file__).parent
out=r/'output';work=r/'contributions-preview';work.mkdir(exist_ok=True)
records=json.loads((r/'slide-content-and-notes.json').read_text())
index=next(i for i,x in enumerate(records) if 'contributions' in x)
record=records[index];assert index==10 and len(record['contributions'])==4
prs=Presentation(out/'Uni-Grad - Midterm Presentation.pptx')
for i,entry in reversed(list(enumerate(list(prs.slides._sldIdLst)))):
    if i!=index:
        prs.part.drop_rel(entry.rId);prs.slides._sldIdLst.remove(entry)
prs.core_properties.title='Uni-Grad — contributions and uniqueness — animated slide'
standalone=out/'Uni-Grad - Animated Contributions.pptx';prs.save(standalone)
source=prs.slides[0];layout_name=str(source.slide_layout.part.partname)
groups=[x['shape_id'] for x in record['animation']['groups']]
assert len(groups)==4
buffer=BytesIO();prs.save(buffer);states=Presentation(BytesIO(buffer.getvalue()))
for entry in list(states.slides._sldIdLst):
    states.part.drop_rel(entry.rId);states.slides._sldIdLst.remove(entry)
layout=next(x for x in states.slide_layouts if str(x.part.partname)==layout_name)
for state in range(5):
    slide=states.slides.add_slide(layout)
    for shape in list(slide.shapes):shape._element.getparent().remove(shape._element)
    for shape in source.shapes:
        if shape.shape_id in groups and groups.index(shape.shape_id)>=state:continue
        slide.shapes._spTree.insert_element_before(deepcopy(shape._element),'p:extLst')
states_path=work/'Contribution build states.pptx';states.save(states_path)
soffice=shutil.which('soffice') or shutil.which('libreoffice')
env=os.environ.copy();env['FONTCONFIG_FILE']=str(r/'fonts/fonts.conf')
with tempfile.TemporaryDirectory(prefix='uni-grad-contribution-office-') as profile:
    common=[soffice,'-env:UserInstallation='+Path(profile).as_uri(),'--headless']
    subprocess.run(common+['--convert-to','pdf','--outdir',str(work),str(states_path)],check=True,env=env)
    subprocess.run(common+['--convert-to','odp','--outdir',str(work),str(standalone)],check=True,env=env)
with zipfile.ZipFile(work/'Uni-Grad - Animated Contributions.odp') as z:
    root=etree.fromstring(z.read('content.xml'))
ns={'anim':'urn:oasis:names:tc:opendocument:xmlns:animation:1.0',
    'presentation':'urn:oasis:names:tc:opendocument:xmlns:presentation:1.0',
    'smil':'urn:oasis:names:tc:opendocument:xmlns:smil-compatible:1.0'}
fades=root.xpath('//anim:transitionFilter[@smil:type="fade"]',namespaces=ns)
clicks=root.xpath('//*[@presentation:node-type="on-click"]',namespaces=ns)
assert len(fades)==len(clicks)==4,(len(fades),len(clicks))
audit={'slide_number':11,'native_fade_entrances':4,'on_click_steps':4,'duration_ms':350,
       'libreoffice_imported_fades':len(fades),'libreoffice_imported_clicks':len(clicks),
       'macros':False,'automatic_slide_advance':False,'claims_are_planned':True,
       'thesis_section':'1.5','preview_note':'MP4/GIF automatically demonstrate the four presenter-controlled clicks.'}
(out/'Contributions Animation Checks.json').write_text(json.dumps(audit,indent=2)+'\n')
doc=fitz.open(work/'Contribution build states.pdf');assert len(doc)==5
frames=[]
for i,page in enumerate(doc):
    pix=page.get_pixmap(matrix=fitz.Matrix(4/3,4/3))
    im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples).resize((1280,720),Image.Resampling.LANCZOS)
    im.save(work/f'state-{i}.png');frames.append(im)
fps=25;video=out/'Contributions - Animation Preview.mp4'
cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pixel_format','rgb24',
     '-video_size','1280x720','-framerate',str(fps),'-i','pipe:0','-an',
     '-c:v','libx264','-pix_fmt','yuv420p','-crf','21','-movflags','+faststart',str(video)]
process=subprocess.Popen(cmd,stdin=subprocess.PIPE)
def hold(im,seconds):
    raw=im.tobytes()
    for _ in range(round(seconds*fps)):process.stdin.write(raw)
hold(frames[0],1)
for step in range(1,5):
    for frame in range(1,10):process.stdin.write(Image.blend(frames[step-1],frames[step],frame/9).tobytes())
    hold(frames[step],3.0 if step<4 else 4.0)
process.stdin.close();assert process.wait()==0
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(video),
    '-filter_complex','fps=12,scale=800:-1:flags=lanczos,split[s0][s1];[s0]palettegen=max_colors=192:stats_mode=diff[p];[s1][p]paletteuse=dither=bayer:bayer_scale=3',
    '-loop','0',str(out/'Contributions - Animation Preview.gif')],check=True)
print('PASS: slide 11 has four native on-click fades; independent import and five-state animation previews verified.')
