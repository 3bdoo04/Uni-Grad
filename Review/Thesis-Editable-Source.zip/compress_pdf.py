"""Optimize images while retaining the original text, links, and vector content."""
from pathlib import Path
import subprocess
import fitz
import numpy as np

r = Path(__file__).parent
source = r / 'Revised Thesis - Uncompressed.pdf'
temporary = r / 'build/image-optimization.pdf'
output = r / 'Revised Thesis - Compressed.pdf'
with (r / 'build/compression.log').open('w') as log:
    subprocess.run([
        'gs', '-sDEVICE=pdfwrite', '-dCompatibilityLevel=1.7', '-dPDFSETTINGS=/printer',
        '-dNOPAUSE', '-dBATCH', '-dSAFER', '-dAutoRotatePages=/None',
        '-dDetectDuplicateImages=true', '-dCompressFonts=true', '-dSubsetFonts=true',
        '-dJPEGQ=90', '-sOutputFile=' + str(temporary), str(source),
    ], stdout=log, stderr=subprocess.STDOUT, check=True)

original = fitz.open(source)
optimized = fitz.open(temporary)
mapping = {}
unmatched = set()
for i in range(len(original)):
    candidates = optimized[i].get_image_info(xrefs=True)
    for image in original[i].get_image_info(xrefs=True):
        xref = image['xref']
        if not xref or image['width'] <= 1 or image['height'] <= 1:
            continue
        matches = [item for item in candidates if item['xref'] and
                   max(abs(a-b) for a,b in zip(image['bbox'], item['bbox'])) < .10]
        if len(matches) != 1:
            unmatched.add(xref)
            continue
        match = matches[0]
        pixels = match['width'] * match['height']
        if xref not in mapping or pixels > mapping[xref][2]:
            mapping[xref] = (i, match['xref'], pixels)

for xref, (i, target, _) in mapping.items():
    masks = [image[1] for image in optimized[i].get_images(full=True) if image[0] == target]
    smask = masks[0] if masks else 0
    if smask:
        image = fitz.Pixmap(fitz.Pixmap(optimized, target), fitz.Pixmap(optimized, smask))
        data = image.tobytes('png')
    else:
        data = optimized.extract_image(target)['image']
    original[i].replace_image(xref, stream=data)

original.save(output, garbage=4, deflate=True, use_objstms=0, compression_effort=20)
original.close()
original = fitz.open(source)
result = fitz.open(output)
assert len(original) == len(result)
for i in range(len(original)):
    assert original[i].get_text() == result[i].get_text(), ('text changed', i+1)
    assert original[i].rect == result[i].rect
    a, b = original[i].get_pixmap(), result[i].get_pixmap()
    delta = np.abs(np.frombuffer(a.samples, dtype=np.uint8).astype(np.int16) -
                   np.frombuffer(b.samples, dtype=np.uint8).astype(np.int16))
    assert float(delta.mean()) < 2.0, ('inspect image compression', i+1, float(delta.mean()))
assert source.stat().st_size > output.stat().st_size
print('Pages:', len(result), 'Images optimized:', len(mapping), 'Unmatched retained:', len(unmatched))
print('Uncompressed bytes:', source.stat().st_size, 'Compressed bytes:', output.stat().st_size)
print('Verified identical text and page geometry; image rendering checked on every page.')
