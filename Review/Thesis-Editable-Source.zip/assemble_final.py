"""Retain the five approved original pages without re-typesetting or scaling them."""
from pathlib import Path
import fitz

r = Path(__file__).parent
doc = fitz.open(r / 'build/main.pdf')
front = fitz.open(r / 'assets/retained-front.pdf')
arabic = fitz.open(r / 'assets/retained-arabic.pdf')
toc = doc.get_toc(simple=False)
links = [page.get_links() for page in doc]
def explicit_destination(item):
    item = dict(item)
    item.pop('xref', None)
    item.pop('id', None)
    if item.get('kind') == fitz.LINK_NAMED and item.get('page', -1) >= 0:
        target = doc[item['page']]
        item['to'] = fitz.Point(item['to']) * target.transformation_matrix
        item['kind'] = fitz.LINK_GOTO
        item.pop('nameddest', None)
    return item
for entry in toc:
    entry[3] = explicit_destination(entry[3])
links = [[explicit_destination(link) for link in saved] for saved in links]
replacements = [(0, front, 0), (1, front, 1), (2, front, 2),
                (len(doc)-2, arabic, 0), (len(doc)-1, arabic, 1)]
for index, source, source_index in sorted(replacements, reverse=True, key=lambda item: item[0]):
    doc.delete_page(index)
    doc.insert_pdf(source, from_page=source_index, to_page=source_index, start_at=index, links=False)
doc.set_toc(toc)
for i, saved in enumerate(links):
    page = doc[i]
    for current in page.get_links():
        page.delete_link(current)
    for link in saved:
        link = dict(link)
        link.pop('xref', None)
        link.pop('id', None)
        page.insert_link(link)
output = r / 'Revised Thesis - Uncompressed.pdf'
doc.save(output, garbage=4, deflate=True)
print('Assembled', len(doc), 'pages:', output)
