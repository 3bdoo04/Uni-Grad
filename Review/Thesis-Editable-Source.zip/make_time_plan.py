from pathlib import Path
from datetime import date, timedelta
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

r = Path(__file__).parent
start = date(2026, 11, 23)
deadline = date(2027, 1, 17)
assert start.weekday() == 0 and deadline.weekday() == 6
assert (deadline - start).days == 55
tasks = [
    ('T1', 'Scope and requirements', 1, 1, 'Both', []),
    ('T2', 'Guidance and bilingual cases', 2, 3, 'Omar', ['T1']),
    ('T3', 'Telephone and speech feasibility', 2, 3, 'Abdelrahman', ['T1']),
    ('T4', 'Controller and agent interfaces', 4, 4, 'Omar', ['T2', 'T3']),
    ('T5', 'Location and ambulance rules', 5, 5, 'Omar', ['T4']),
    ('T6', 'Dashboard and receiver design', 5, 5, 'Abdelrahman', ['T4']),
    ('T7', 'Privacy, safety and cost plan', 6, 6, 'Abdelrahman', ['T5', 'T6']),
    ('T8', 'Evaluation and test scenarios', 6, 6, 'Omar', ['T2', 'T5', 'T6']),
    ('T9', 'Integrated design review', 7, 7, 'Both', ['T7', 'T8']),
    ('T10', 'Final report and submission', 8, 8, 'Both', ['T9']),
    ('T11', 'Report and decision log', 1, 8, 'Both', []),
]
task_map = {t[0]: t for t in tasks}
records = []
for code, title, first, last, lead, dependencies in tasks:
    for predecessor in dependencies:
        assert task_map[predecessor][3] < first, (code, predecessor)
    records.append({'code': code, 'task': title, 'start': str(start+timedelta(days=(first-1)*7)),
                    'end': str(start+timedelta(days=last*7-1)), 'weeks': last-first+1,
                    'lead': lead, 'dependencies': dependencies})
(r/'time-plan-tasks.json').write_text(json.dumps(records, indent=2))

# Internal identifiers support dependency validation; none are printed in the chart.
from textwrap import fill
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8.8,
                     'pdf.fonttype': 42, 'svg.fonttype': 'none'})
fig, ax = plt.subplots(figsize=(6.25, 7.65))
fig.subplots_adjust(left=.395, right=.975, top=.81, bottom=.15)
navy, teal, grey, pale = '#22475E', '#007F83', '#667582', '#B6C4CB'
phase_colors = {code: navy if i < 3 else teal if i < 6 else grey
                for i, (code, *_rest) in enumerate(tasks)}
phase_colors['T11'] = pale
labels = []
row_for = {task[0]: i for i, task in enumerate(tasks)}
for i, (code, title, first, last, lead, dependencies) in enumerate(tasks):
    labels.append(fill(title, width=27) + '\n(' + lead + ')')
    # Leave a little space at each weekly boundary for dependency arrows.
    ax.barh(i, last-first+1-.20, left=first-1+.10, height=.46,
            color=phase_colors[code], edgecolor='black', linewidth=.45, zorder=3)
    if code != 'T11':
        ax.scatter([last-.10], [i], marker='D', s=18, color='white',
                   edgecolors='black', linewidths=.6, zorder=6)

# A transitive dependency is already shown through the intervening design tasks.
for code, title, first, last, lead, dependencies in tasks:
    for predecessor in dependencies:
        if (predecessor, code) == ('T2', 'T8'):
            continue
        previous = task_map[predecessor]
        source_y, target_y = row_for[predecessor], row_for[code]
        boundary = first-1
        assert previous[3] == boundary
        ax.plot([boundary-.10, boundary+.015, boundary+.015],
                [source_y, source_y, target_y], color='#303B42', linewidth=.65,
                zorder=4, solid_capstyle='round')
        ax.annotate('', xy=(boundary+.18, target_y), xytext=(boundary+.015, target_y),
                    arrowprops={'arrowstyle': '-|>', 'color': '#303B42',
                                'lw': .65, 'mutation_scale': 6, 'shrinkA': 0, 'shrinkB': 0},
                    zorder=5)

ax.set_yticks(range(len(tasks)), labels, fontsize=8.9, linespacing=1.13)
ax.tick_params(axis='y', length=0, pad=8)
week_labels = ['23–29\nNov', '30 Nov\n–6 Dec', '7–13\nDec', '14–20\nDec',
               '21–27\nDec', '28 Dec\n–3 Jan', '4–10\nJan', '11–17\nJan']
ax.set_xticks([i+.5 for i in range(8)], week_labels, fontsize=7.3)
ax.xaxis.tick_top()
ax.tick_params(axis='x', length=0, pad=8)
for x in range(9):
    ax.axvline(x, color='#C6CED3', linewidth=.55, zorder=0)
for y in range(len(tasks)+1):
    ax.axhline(y-.5, color='#E3E8EB', linewidth=.5, zorder=0)
# Highlight the agreed three-day correction buffer within the final work week.
ax.barh(row_for['T10'], 3/7, left=7+3/7, height=.46,
        color='#E4D6AE', hatch='///', edgecolor='#6B6250', linewidth=.45, zorder=4)
ax.set_xlim(0,8)
ax.set_ylim(len(tasks)-.45, -.55)
ax.spines[['left','right','bottom','top']].set_visible(False)
fig.text(.035,.965,'Graduation Project I schedule', ha='left', fontsize=13.3, weight='bold')
fig.text(.035,.926,'23 November 2026 – 17 January 2027', ha='left', fontsize=9.7)
fig.text(.035,.889,'Task and proposed lead', ha='left', fontsize=8.7, weight='bold')
fig.text(.395,.889,'Planned weeks', ha='left', fontsize=8.7, weight='bold')
legend_items = [Patch(facecolor=c, edgecolor='black', linewidth=.4, label=label)
                for c, label in [(navy,'Preparation'), (teal,'Design'),
                                 (grey,'Review and submission'), (pale,'Documentation')]]
fig.legend(handles=legend_items, loc='lower left', bbox_to_anchor=(.025,.077),
           ncol=2, frameon=False, fontsize=8, handlelength=1.6,
           columnspacing=1.6, labelspacing=.65)
fig.text(.035,.060,'Arrows: dependencies     Diamonds: task completion milestones', fontsize=7.8)
fig.text(.035,.034,'Correction buffer: 14–16 January  |  Confirmed submission: 17 January', fontsize=7.8)
fig.canvas.draw()
renderer = fig.canvas.get_renderer()
for label in list(ax.get_yticklabels()) + list(ax.get_xticklabels()) + list(ax.texts) + list(fig.texts):
    bounds = label.get_window_extent(renderer)
    assert bounds.x0 >= 2 and bounds.x1 <= fig.bbox.width-2, (label.get_text(), bounds)
    assert bounds.y0 >= 2 and bounds.y1 <= fig.bbox.height-2, (label.get_text(), bounds)
assert fig.get_figheight() > fig.get_figwidth()
fig.savefig(r/'assets/grad1-gantt.pdf', facecolor='white')
fig.savefig(r/'preview-gantt-chart.png', dpi=180, facecolor='white')
plt.close(fig)
print('Generated portrait eight-week Gantt chart with task names, leads, milestones, and dependencies.')
