from pathlib import Path
from datetime import date, timedelta
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

r = Path(__file__).parent
start = date(2026, 11, 23)
deadline = date(2027, 1, 17)
assert start.weekday() == 0 and deadline.weekday() == 6
assert (deadline - start).days == 55
tasks = [
    ('T1', 'Scope and requirements', 1, 1, 'Both', []),
    ('T2', 'Guidance and bilingual cases', 2, 3, 'Omar', ['T1']),
    ('T3', 'Telephone and speech feasibility', 2, 3, 'Abdelrahman', ['T1']),
    ('T4', 'Controller and agent interfaces', 4, 4, 'Omar', ['T2', 'T3']),
    ('T5', 'Location and ambulance rules', 5, 5, 'Omar', ['T4']),
    ('T6', 'Dashboard and receiver design', 5, 5, 'Abdelrahman', ['T4']),
    ('T7', 'Privacy, safety and cost plan', 6, 6, 'Abdelrahman', ['T5', 'T6']),
    ('T8', 'Evaluation and test scenarios', 6, 6, 'Omar', ['T2', 'T5', 'T6']),
    ('T9', 'Integrated design review', 7, 7, 'Both', ['T7', 'T8']),
    ('T10', 'Final report and submission', 8, 8, 'Both', ['T9']),
    ('T11', 'Report and decision log', 1, 8, 'Both', []),
]
task_map = {t[0]: t for t in tasks}
records = []
for code, title, first, last, lead, dependencies in tasks:
    for predecessor in dependencies:
        assert task_map[predecessor][3] < first, (code, predecessor)
    records.append({'code': code, 'task': title, 'start': str(start+timedelta(days=(first-1)*7)),
                    'end': str(start+timedelta(days=last*7-1)), 'weeks': last-first+1,
                    'lead': lead, 'dependencies': dependencies})
(r/'time-plan-tasks.json').write_text(json.dumps(records, indent=2))

plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10.5,
                     'pdf.fonttype': 42, 'svg.fonttype': 'none'})
fig, ax = plt.subplots(figsize=(12, 6.7))
fig.subplots_adjust(left=.34, right=.985, top=.80, bottom=.13)
navy, teal, grey = '#22475E', '#007F83', '#667582'
short = {'T1':'Scope baseline', 'T2':'Guidance and cases', 'T3':'Voice feasibility',
         'T4':'Agent/controller design', 'T5':'Location/resource rules',
         'T6':'Dashboard/receiver design', 'T7':'Risk and cost plan',
         'T8':'Evaluation plan', 'T9':'Integrated review',
         'T10':'Final report/submission', 'T11':'Documentation'}
labels = []
for i, (code, title, first, last, lead, dependencies) in enumerate(tasks):
    labels.append(f'{code}  {short[code]}  ({lead})')
    color = navy if code in ['T1','T2','T3'] else teal if code in ['T4','T5','T6'] else grey
    if code == 'T11': color = '#B6C4CB'
    ax.barh(i, last-first+1, left=first-1, height=.52, color=color, edgecolor='black', linewidth=.5, zorder=3)
ax.set_yticks(range(len(tasks)), labels, fontsize=11.5)
ax.tick_params(axis='y', length=0, pad=9)
week_labels = ['W1\n23–29 Nov', 'W2\n30 Nov–6 Dec', 'W3\n7–13 Dec', 'W4\n14–20 Dec',
               'W5\n21–27 Dec', 'W6\n28 Dec–3 Jan', 'W7\n4–10 Jan', 'W8\n11–17 Jan']
ax.set_xticks([i+.5 for i in range(8)], week_labels, fontsize=10.2)
ax.xaxis.tick_top()
ax.tick_params(axis='x', length=0, pad=9)
for x in range(9): ax.axvline(x, color='#C6CED3', linewidth=.65, zorder=0)
for y in range(len(tasks)+1): ax.axhline(y-.5, color='#E3E8EB', linewidth=.5, zorder=0)
milestones = [('M1',1),('M2',3),('M3',4),('M4',5),('M5',6),('M6',7),('M7',8)]
my = len(tasks)+.25
for name, week in milestones:
    x = week-.08
    ax.scatter([x], [my], marker='D', s=42, color=navy, edgecolors='black', linewidths=.4, zorder=4)
    ax.text(x, my+.52, name, ha='center', va='center', fontsize=11)
ax.text(-.18, my, 'Milestones', ha='right', va='center', fontsize=11)
ax.set_xlim(0,8.12)
ax.set_ylim(my+1.0, -.65)
ax.spines[['left','right','bottom','top']].set_visible(False)
fig.text(.34,.94,'Proposed Grad I work schedule', ha='left', fontsize=15, weight='bold')
fig.text(.34,.885,'23 Nov 2026 – 17 Jan 2027  |  Submission deadline confirmed', ha='left', fontsize=11)
fig.text(.34,.045,'Bars: planned work   •   Diamonds: milestone deadlines   •   Internal dates and leads are proposed', fontsize=10)
fig.canvas.draw()
renderer = fig.canvas.get_renderer()
for label in list(ax.get_yticklabels()) + list(ax.get_xticklabels()) + list(ax.texts) + list(fig.texts):
    bounds = label.get_window_extent(renderer)
    assert bounds.x0 >= 2 and bounds.x1 <= fig.bbox.width-2, (label.get_text(), bounds)
fig.savefig(r/'assets/grad1-gantt.pdf', facecolor='white')
fig.savefig(r/'preview-gantt-chart.png', dpi=150, facecolor='white')
plt.close(fig)
print('Generated eight-week Gantt chart and validated task dependencies.')
