"""Replace Arabic cover placeholders while preserving the original logos and layout."""
from pathlib import Path
import fitz
r=Path(__file__).parent
p=fitz.open(r/'assets/arabic-cover-template.pdf')
page=p[-1]
for rect in [(250,328,345,361),(250,550,345,586),(260,660,335,679),(260,726,338,752)]:
 page.add_redact_annot(fitz.Rect(rect),fill=(1,1,1))
page.apply_redactions(images=0,graphics=0)
fontdir='/usr/share/fonts/truetype/noto'
css="""@font-face {font-family: cover; src: url(NotoNaskhArabic-Regular.ttf);} * {font-family:cover;} body {margin:0; padding:0;} .line {direction:rtl; text-align:center; font-size:14.35pt; line-height:1.4;} table {width:100%; border-collapse:collapse; direction:rtl;} td {font-size:13pt; text-align:center; padding:0; line-height:1.7;}"""
def put(rect,html):
 spare,scale=page.insert_htmlbox(fitz.Rect(rect),html,css=css,archive=fitz.Archive(fontdir),scale_low=1)
 assert spare>=0,(rect,spare,scale)
put((85,325,510,377),'<div class="line" dir="rtl">نظام الفرز الطبي الطارئ عن بُعد والإرسال الطبي المستقل<br>القائم على وكلاء الذكاء الاصطناعي</div>')
put((235,551,490,608),'<table><tr><td dir="rtl">عبدالرحمن محمود علي عبدالحليم</td></tr><tr><td dir="rtl">عمر مصطفى عمر علي عمر</td></tr></table>')
put((135,551,220,608),'<table><tr><td dir="ltr">٢٣٧٣٤٣</td></tr><tr><td dir="ltr">٢٣٥٥٥٩</td></tr></table>')
put((140,658,455,692),'<div class="line" dir="rtl">الدكتوره جيهاد محي رزق</div>')
put((250,731,345,761),'<table dir="rtl"><tr><td>٢٠٢٧</td><td>–</td><td>٢٠٢٦</td></tr></table>')
p.save(r/'assets/retained-arabic.pdf',garbage=4,deflate=True)
p=fitz.open(r/'assets/retained-arabic.pdf')
page=p[-1]
page.get_pixmap(matrix=fitz.Matrix(1.5,1.5)).save(r/'build/arabic-cover-preview.png')
print(page.get_text())
