"""Package the current thesis and focused PDF excerpts for the review branch."""
from pathlib import Path
import json
import re
import shutil
import zipfile
import fitz

r = Path(__file__).parent
repo = Path('/workspace/Uni-Grad')
review = repo / 'Review'
doc = fitz.open(r / 'Revised Thesis - Uncompressed.pdf')
compressed = fitz.open(r / 'Revised Thesis - Compressed.pdf')
assert len(doc) == len(compressed)
assert all(a.get_text() == b.get_text() for a, b in zip(doc, compressed))
toc = doc.get_toc()
chapters = {title: page-1 for level, title, page in toc if level == 1}

for title, filename in [('Proposed System Design', 'Chapters-3-to-5.pdf'),
                        ('Graduation Project I Time Plan', 'Chapters-4-and-5.pdf')]:
    first, last = chapters[title], chapters['References']-1
    part = fitz.open()
    part.insert_pdf(doc, from_page=first, to_page=last)
    part.set_toc([[level, name, page-first] for level, name, page in toc
                  if first <= page-1 <= last])
    part.set_metadata({'title': filename.removesuffix('.pdf')+' — thesis review',
                       'author': 'Uni-Grad project team'})
    part.save(r / filename, garbage=4, deflate=True)
    shutil.copy2(r / filename, review / filename)

first = next(page-1 for _, title, page in toc
             if title == 'History and Evolution of Emergency Medical Dispatch')
last = next(page-1 for _, title, page in toc
            if title == 'Collaborative Medical Triage under Uncertainty')
part = fitz.open()
part.insert_pdf(doc, from_page=first, to_page=last)
page = part[-1]
headings = [b for b in page.get_text('blocks')
            if re.match(r'2\.2\s+Collaborative Medical Triage', b[4].strip())]
assert len(headings) == 1
# End the focused review excerpt at Section 2.1 without changing the full thesis.
page.add_redact_annot(fitz.Rect(36, headings[0][1]-5, page.rect.width-36,
                               page.rect.height-56), fill=(1, 1, 1))
page.apply_redactions(images=0, graphics=0)
assert 'Methodology' not in page.get_text()
part.insert_pdf(doc, from_page=chapters['Graduation Project I Time Plan'],
                to_page=chapters['Graduation Project I Time Plan'])
part.set_toc([[1, 'Section 2.1 — history and evolution', 1],
              [1, 'Vibrant Gantt chart', len(part)]])
part.set_metadata({'title': 'Section 2.1 and Gantt chart — review draft',
                   'author': 'Uni-Grad project team'})
assert all(p.rect.height > p.rect.width and p.rotation == 0 for p in part)
part.save(r / 'Section-2.1-and-Gantt.pdf', garbage=4, deflate=True)
part[-2].get_pixmap(matrix=fitz.Matrix(1.25, 1.25)).save(r / 'history-excerpt-last-page.png')
shutil.copy2(r / 'Section-2.1-and-Gantt.pdf', review / 'Section-2.1-and-Gantt.pdf')

# Provide a focused review copy of the two new standards sections.
selected = []
for first_title, next_title in [
    ('Industrial Standards Related to the Reviewed Research', 'Summary'),
    ('Industrial Standards Applied to the Proposed Requirements', 'Proposed System Block Diagram and Flowchart'),
]:
    first_entry = next(i for i, (_, title, _) in enumerate(toc) if title == first_title)
    first_page = toc[first_entry][2]-1
    next_entry = next(i for i in range(first_entry+1, len(toc)) if toc[i][1] == next_title)
    next_page = toc[next_entry][2]-1
    # Both revised standards sections occupy dedicated portrait pages.
    assert first_page < next_page
    selected.append((first_title, first_page, next_page-1))
standards = fitz.open()
standards_toc = []
for title, first_page, last_page in selected:
    offset = len(standards)
    standards.insert_pdf(doc, from_page=first_page, to_page=last_page)
    standards_toc.append([1, title, offset+1])
standards.set_toc(standards_toc)
standards.set_metadata({'title': 'Industrial standards and planned application — review',
                        'author': 'Uni-Grad project team'})
standards.save(r / 'Industrial-Standards-Review.pdf', garbage=4, deflate=True)
shutil.copy2(r / 'Industrial-Standards-Review.pdf', review / 'Industrial-Standards-Review.pdf')

source_files = [
    'main.tex', 'chapter1.tex', 'chapter2.tex', 'chapter2b.tex', 'chapter3.tex',
    'chapter4.tex', 'chapter5.tex', 'references.bib', 'ieeetr.bst', '.latexmkrc',
    'assemble_final.py', 'compress_pdf.py', 'validate_revision.py', 'package_review.py',
    'update_arabic_cover.py', 'make_time_plan.py', 'time-plan-config.json', 'time-plan-tasks.json',
    'Evidence-and-review-notes.md', 'paper-manifest.json', 'history911-verification-status.txt',
    'history911-page.txt', 'history911-source.json',
]
source_files += [str(p.relative_to(r)) for p in sorted((r / 'assets').rglob('*')) if p.is_file()]
standards_manifest = json.loads((r / 'genai-standards-sources/manifest.json').read_text())
source_files += ['genai-standards-sources/manifest.json']
source_files += ['genai-standards-sources/'+item['file'] for item in standards_manifest['sources']]
with zipfile.ZipFile(r / 'Thesis editable source.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for filename in source_files:
        archive.write(r / filename, arcname=filename)
with zipfile.ZipFile(r / 'Thesis editable source.zip') as archive:
    assert archive.testzip() is None
    for filename in source_files:
        assert archive.read(filename) == (r / filename).read_bytes()

for source, target in [
    ('Revised Thesis - Uncompressed.pdf', 'Modified PreMid Thesis - Uncompressed.pdf'),
    ('Revised Thesis - Compressed.pdf', 'Modified PreMid Thesis.pdf'),
    ('Thesis editable source.zip', 'Review/Thesis-Editable-Source.zip'),
    ('preview-gantt-chart.png', 'Review/Time-Plan.png'),
    ('Evidence-and-review-notes.md', 'Review/Review-Notes.md'),
]:
    shutil.copy2(r / source, repo / target)

cover = fitz.open()
cover.insert_pdf(doc, from_page=len(doc)-1, to_page=len(doc)-1)
cover.set_metadata({'title': 'Arabic cover — centered review copy',
                    'author': 'Uni-Grad project team'})
cover.save(review / 'Arabic-Cover-Review.pdf', garbage=4, deflate=True)
cover[0].get_pixmap(matrix=fitz.Matrix(1.5, 1.5)).save(review / 'Arabic-Cover-Preview.png')

print('Packaged', len(doc), 'portrait thesis pages and', len(part), 'focused review pages.')
print('Editable source contains', len(source_files), 'files.')
print('Standards review excerpt contains', len(standards), 'pages.')
