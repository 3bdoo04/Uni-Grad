from pathlib import Path
import fitz
import hashlib
import json
import re
import unicodedata

r = Path(__file__).parent
repo = Path('/workspace/Uni-Grad')
pdf = fitz.open(r / 'Revised Thesis - Uncompressed.pdf')
text = '\n'.join(page.get_text() for page in pdf)
normalize = lambda value: re.sub(r'\s+', ' ', unicodedata.normalize('NFKC', value)).strip()

removed = [
    'CONNECT-AI', '58177', 'NEDIS',
    'A Novel Artificial Intelligence', 'Community Intervention Study',
    'This chapter should', '12-15 pages',
    'Detailed Use Case Diagram', 'Detailed Sequence Diagram',
    'Detailed Activity Diagram', 'Detailed Class Diagram',
    'System design wireframe', 'Pseudo Code/Algorithms',
    'Component 1', 'Component 2',
]
for phrase in removed:
    assert phrase.casefold() not in text.casefold(), phrase

c1 = (r / 'chapter1.tex').read_text()
for first, last in [('Aim and Objectives', 'Contributions and Uniqueness'),
                    ('Contributions and Uniqueness', 'Industrial Partner')]:
    region = c1.split('\\section{' + first + '}')[1].split('\\section{' + last + '}')[0]
    assert '\\cite' not in region, first

c2 = (r / 'chapter2.tex').read_text() + (r / 'chapter2b.tex').read_text()
sections = re.split(r'\\section(?:\[[^\]]*\])?\{', c2)[1:]
papers = [section for section in sections if '\\subsection{' in section]
assert len(papers) == 6
expected = ['Methodology', 'Results', 'Strengths', 'Limitations', 'Summary']
for section in papers:
    assert re.findall(r'\\subsection\{([^}]+)\}', section) == expected

c3 = (r / 'chapter3.tex').read_text()
assert re.findall(r'\\section\{([^}]+)\}', c3) == ['Requirement Analysis']
assert re.findall(r'\\subsection\{([^}]+)\}', c3) == ['Industrial Standards Applied to the Proposed Requirements',
                                                       'Proposed System Block Diagram and Flowchart']
requirements = c3.split('\\subsection{Industrial Standards Applied to the Proposed Requirements}', 1)[0]
assert '\\begin{longtable}' not in requirements and '\\begin{table}' not in requirements
assert c3.count('\\begin{itemize}') == 2
assert c3.count('\\item \\textbf{') == 20
assert '\\subsubsection*{Functional requirements}' in c3
assert '\\subsubsection*{Non-functional requirements}' in c3
assert 'software development life cycle (SDLC)' in c3
assert 'SDLC & Software development life cycle' in (r / 'main.tex').read_text()
assert len(re.findall(r'\\bibitem\{', (r / 'build/main.bbl').read_text())) == 15
assert '\\label{sec:industrial-standards}' in c2
assert c2.index('\\label{sec:triagent}') < c2.index('\\label{sec:industrial-standards}') < c2.index('\\label{sec:review-summary}')
assert c3.index('\\subsubsection*{Non-functional requirements}') < c3.index('\\label{sec:standards-application}') < c3.index('\\label{sec:system-diagrams}')
assert '\\label{tab:standards-checks}' not in c3
assert '\\begin{longtable}' not in c3
assert '\\subsubsection*' not in c2.split('\\label{sec:industrial-standards}', 1)[1].split('\\section{Summary}', 1)[0]
history = c2.split('\\label{sec:history}', 1)[1].split('\\section[Collaborative Medical Triage', 1)[0]
for key in ['nrc1966', 'history911', 'zachariah1995', 'slovis1985', 'gardett2013']:
    assert '\\cite{' + key + '}' in history, key
assert 'historical evidence' in history and '1966' in history and '2013' in history
assert len(re.findall(r'\\label\{fig:', c3)) == 3
assert len(re.findall(r'\}\{fig:', c2)) == 5

c4 = (r / 'chapter4.tex').read_text()
c5 = (r / 'chapter5.tex').read_text()
assert '\\chapter{Graduation Project I Time Plan}' in c4
assert '\\chapter{Initial Conclusion}' in c5
assert '17 January 2027' in c4
assert '\\label{fig:grad1-gantt}' in c4
assert '\\section' not in c4 and '\\begin{table}' not in c4 and '\\begin{longtable}' not in c4
assert c4.count('\\begin{figure}') == 1
outside_chart = re.sub(r'\\chapter\{[^}]+\}\\label\{[^}]+\}', '', c4)
outside_chart = re.sub(r'\\begin\{figure\}.*?\\end\{figure\}', '', outside_chart, flags=re.S)
assert not outside_chart.strip(), outside_chart
chart = fitz.open(r / 'assets/grad1-gantt.pdf')
assert chart[0].rect.height > chart[0].rect.width
chart_text = chart[0].get_text()
assert not re.search(r'\b[TMW]\d+\b', chart_text), chart_text
for phrase in ['Arrows: dependencies', 'task completion milestones', 'Omar', 'Abdelrahman',
               '17 January', 'Preparation', 'Design', 'Review and submission']:
    assert phrase in chart_text, phrase
assert not re.search(r'\\(?:section|subsection|subsubsection|paragraph|begin)\b', c5)
conclusion_paragraphs = re.split(r'\n\s*\n', c5.split('\n', 1)[1].strip())
assert len(conclusion_paragraphs) == 3, len(conclusion_paragraphs)
assert conclusion_paragraphs[0].startswith('The work completed so far')
assert conclusion_paragraphs[1].startswith('The proposed approach')
assert conclusion_paragraphs[2].startswith('The next steps')
tasks = json.loads((r / 'time-plan-tasks.json').read_text())
assert len(tasks) == 11
task_map = {task['code']: task for task in tasks}
for task in tasks:
    assert task['start'] <= task['end'] <= '2027-01-17'
    assert task['lead'] in ['Omar', 'Abdelrahman', 'Both']
    for predecessor in task['dependencies']:
        assert task_map[predecessor]['end'] < task['start']
assert task_map['T10']['end'] == '2027-01-17'
assert task_map['T11']['weeks'] == 8
assert 'Initial Conclusion' in text and 'Graduation Project I Time Plan' in text

baseline = fitz.open(r / 'Before revision - Modified PreMid Thesis - Uncompressed.pdf')
for old_index, new_index in [(0, 0), (1, 1), (2, 2), (45, len(pdf)-2), (46, len(pdf)-1)]:
    assert normalize(baseline[old_index].get_text()) == normalize(pdf[new_index].get_text()), ('retained text', old_index)
    a = baseline[old_index].get_pixmap()
    b = pdf[new_index].get_pixmap()
    assert (a.width, a.height) == (b.width, b.height)
    assert a.samples == b.samples, ('retained appearance', old_index)

for page in pdf:
    assert page.rotation == 0 and page.rect.height > page.rect.width, ('non-portrait page', page.number+1)
    for link in page.get_links():
        if link['kind'] == fitz.LINK_GOTO:
            assert 0 <= link['page'] < len(pdf), link
for level, title, page in pdf.get_toc():
    assert 1 <= page <= len(pdf), (title, page)

files = json.loads((r / 'input-files.json').read_text())
research = ['uncertainty', 'ed', 'eca', 'llm_dispatch', 'dispatchmas', 'triagent',
            'accidental_death', 'history911', 'emd_development', 'priority_dispatch', 'dispatch_research']
manifest = []
for key in research:
    uploaded = Path(files[key])
    saved = repo / 'Papers' / uploaded.name
    assert uploaded.read_bytes() == saved.read_bytes()
    manifest.append({'file': saved.name, 'pages': len(fitz.open(saved)) if saved.suffix.lower() == '.pdf' else None,
                     'type': 'pdf' if saved.suffix.lower() == '.pdf' else 'source-link', 'bytes': saved.stat().st_size,
                     'sha256': hashlib.sha256(saved.read_bytes()).hexdigest()})
assert sorted(p.name for p in (repo / 'Papers').iterdir()) == sorted(item['file'] for item in manifest)
(r / 'paper-manifest.json').write_text(json.dumps(manifest, indent=2))
(r / 'revised-full-text.txt').write_text(text)
print('PASS: six detailed study reviews, 30 paper subsections, 15 references, five source architectures, three project diagrams.')
print('PASS: Chapter 2 standards section follows the study reviews; Chapter 3 maps standards after the requirements.')
print('PASS: Section 2.1 cites all five historical sources and justifies the use of older historical evidence.')
print('PASS: no removed-paper material or deleted Chapter 3 sections; no citations in Sections 1.4 or 1.5.')
print('PASS: retained covers, abstracts, and acknowledgment; valid internal links; exact uploaded research PDFs.')
print('PASS: every page portrait; 20 bold-label requirement bullets; Chapter 4 contains only the Gantt chart.')
print('PASS: chart uses plain task names, leads, milestones and dependencies; deadline 17 January 2027.')
print('PASS: Chapter 5 contains exactly three paragraphs and no section headings.')
print('PDF pages:', len(pdf), 'bytes:', (r / 'Revised Thesis - Uncompressed.pdf').stat().st_size)
