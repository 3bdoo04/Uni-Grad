$xdvipdfmx = 'xdvipdfmx -V 7 -E -o %D %O %S';
