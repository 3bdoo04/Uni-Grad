# W3C media reference selection

- The guide's AI “Classical or Generative” track, p. 3, Real-time audio and media processing row lists Web Audio API 1.1 and WebRTC 1.0. It explicitly limits applicability to browser media, and distinguishes Web Audio 1.1 Working Draft from WebRTC Recommendation status.
- The repository proposal was read in full (two pages). Page 1, Phase 2 names WebRTC/LiveKit; page 2, Real-Time Audio names LiveKit/WebRTC. This is the direct basis for replacing the removed OWASP item. Telephone caller entry remains the current project scope; the provider-to-media bridge is separate from browser APIs.
- WebRTC is relevant to the proposed LiveKit media path. Web Audio API 1.1 is excluded from the thesis and references because the proposal does not explicitly require browser-side audio processing.
- Direct W3C publisher URLs returned proxy 403. Official W3C/WebAudio GitHub source abstracts and introductions were retrieved and read for technical purpose/scope. These are editor-source documents, not claims that the published Recommendation/Working Draft pages were fetched.
- Only WebRTC 1.0 is cited, as the dated January 26, 2021 Recommendation. Edition status also follows the uploaded guide. No certification or implemented conformance is claimed.
- OWASP and Web Audio source caches remain outside the curated evidence package and are not selected or cited.
